"""AI app widgets on real phones: a flat lay of iPhones in drifting columns, each showing a live lock screen,
camera starting tight on the hero phone and pulling back (Cycles).

Run with Blender's Python (bpy):
  python film.py -- --glb iphone.glb --hdri studio.hdr --screens screens/ --out frames/ [--frames 1-495] [--samples 96]
  python film.py -- ... --static a.png,b.png        # benchmark with still screens
  python film.py -- ... --save film.blend           # also save the .blend
Screens: screens/p<i>/<frame:05d>.(png|jpg), frame 0 = t 0, 30 fps, one folder per lock screen config (phone/phones.js).
"""
import bpy, sys, math, time, os, mathutils, argparse
from mathutils import Matrix, Vector

ap = argparse.ArgumentParser()
ap.add_argument('--glb'); ap.add_argument('--hdri'); ap.add_argument('--screens'); ap.add_argument('--static')
ap.add_argument('--out', default='frames/'); ap.add_argument('--frames', default='')
ap.add_argument('--samples', type=int, default=96); ap.add_argument('--noise', type=float, default=0.025)
ap.add_argument('--res', default='1600x1200'); ap.add_argument('--pct', type=int, default=100)
ap.add_argument('--save', default=''); ap.add_argument('--nseq', type=int, default=18); ap.add_argument('--seqlen', type=int, default=675)
ap.add_argument('--hero-dir', default=''); ap.add_argument('--threads', type=int, default=0)
a = ap.parse_args(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else [])

FPS, DUR = 30, 16.5
NF = round(FPS * DUR)                       # 495 frames
ease3 = lambda p: 4*p*p*p if p < .5 else 1 - (-2*p + 2)**3 / 2
smooth = lambda p: p*p*(3 - 2*p)
mix = lambda x, y, p: x + (y - x) * p
clamp = lambda x, lo=0., hi=1.: max(lo, min(hi, x))

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
sc.render.fps = FPS; sc.frame_start = 1; sc.frame_end = NF

# ---------- the phone model, normalised: centre at origin, lying face up, top towards +Y, back resting on z = 0
bpy.ops.import_scene.gltf(filepath=a.glb)
parts = [o for o in sc.objects if o.type == 'MESH']
FIX = Matrix.Translation((0, 0, 0.0072)) @ Matrix.Rotation(math.radians(-90), 4, 'X') @ Matrix.Translation((0, 0, -0.0817))
base = {}
for o in parts:
    base[o.name] = (o.data, FIX @ o.matrix_world.copy(), [s.material for s in o.material_slots])
for o in parts: bpy.data.objects.remove(o)
for o in list(sc.objects): bpy.data.objects.remove(o)

# screen: emissive lock screen under a glossy cover glass
def screen_mat(name, img, offset):
    m = bpy.data.materials.new(name); m.use_nodes = True; nt = m.node_tree; N = nt.nodes; N.clear()
    tex = N.new('ShaderNodeTexImage'); tex.image = img; tex.interpolation = 'Cubic'; tex.extension = 'EXTEND'
    if img.source == 'SEQUENCE':
        u = tex.image_user; u.frame_duration = a.seqlen; u.frame_start = 1; u.frame_offset = offset; u.use_auto_refresh = True; u.use_cyclic = False
    bs = N.new('ShaderNodeBsdfPrincipled')
    bs.inputs['Base Color'].default_value = (0, 0, 0, 1); bs.inputs['Roughness'].default_value = 0.035
    bs.inputs['Specular IOR Level'].default_value = 0.3
    bs.inputs['Emission Strength'].default_value = 1.12
    nt.links.new(tex.outputs['Color'], bs.inputs['Emission Color'])
    o = N.new('ShaderNodeOutputMaterial'); nt.links.new(bs.outputs['BSDF'], o.inputs['Surface'])
    return m

def load_seq(i):
    if a.static:
        files = a.static.split(','); return bpy.data.images.load(os.path.abspath(files[i % len(files)]), check_existing=True)
    d = a.hero_dir if (i == 0 and a.hero_dir) else os.path.join(a.screens, f'p{i}')
    first = sorted(f for f in os.listdir(d) if f[0].isdigit())[0]
    img = bpy.data.images.load(os.path.abspath(os.path.join(d, first))); img.source = 'SEQUENCE'
    return img

SEQ = [load_seq(i) for i in range(a.nseq)]

col_root = bpy.data.collections.new('phones'); sc.collection.children.link(col_root)
def make_phone(name, seq_i, offset):
    root = bpy.data.objects.new(name, None); col_root.objects.link(root); root.empty_display_size = 0.05
    for pname, (mesh, M, mats) in base.items():
        o = bpy.data.objects.new(f'{name}.{pname}', mesh); col_root.objects.link(o)
        o.parent = root; o.matrix_parent_inverse = Matrix.Identity(4); o.matrix_basis = M
        if pname == 'Front_Screen':
            o.material_slots[0].link = 'OBJECT'
            o.material_slots[0].material = screen_mat(f'scr.{name}', SEQ[seq_i], offset)
    return root

# ---------- the field: columns like the original video, alternating drift
PW, PH = 0.0790, 0.1634
GX, GY = 0.020, 0.020                    # gaps between phones
COLS = range(-6, 7); ROWS = range(-4, 6)
DRIFT = 0.0062                           # m/s, odd columns up, even down
STAG = [0.00, 0.62, 0.21, 0.83, 0.40, 0.07, 0.71, 0.33, 0.95, 0.52, 0.16, 0.77, 0.45]
phones = []
k = 0
for ci, c in enumerate(COLS):
    for r in ROWS:
        hero = (c == 0 and r == 0)
        idx = 0 if hero else 1 + (k % (a.nseq - 1)); off = 0 if hero else ((k // (a.nseq - 1)) * 37) % 181
        if not hero: k += 1
        root = make_phone(f'ph_{c}_{r}', idx, off)
        x = c * (PW + GX); y0 = r * (PH + GY) + (0 if c == 0 else STAG[ci] * (PH + GY))
        d = (1 if c % 2 else -1) * DRIFT
        phones.append((root, x, y0, d, hero))
hero_root = [p[0] for p in phones if p[4]][0]

bpy.context.preferences.edit.keyframe_new_interpolation_type = 'LINEAR'
for root, x, y0, d, hero in phones:              # constant drift: two linear keys per phone
    root.location = (x, y0, 0); root.keyframe_insert('location', frame=1)
    root.location = (x, y0 + d * (NF - 1) / FPS, 0); root.keyframe_insert('location', frame=NF)

# ---------- stage
bpy.ops.mesh.primitive_plane_add(size=12, location=(0, 0, -0.0005)); floor = bpy.context.active_object; floor.name = 'floor'
fm = bpy.data.materials.new('floor'); fm.use_nodes = True; b = fm.node_tree.nodes['Principled BSDF']
b.inputs['Base Color'].default_value = (0.0105, 0.0105, 0.0122, 1); b.inputs['Roughness'].default_value = 0.62
b.inputs['Specular IOR Level'].default_value = 0.3
floor.data.materials.append(fm)

w = bpy.data.worlds.new('W'); sc.world = w; w.use_nodes = True; wn = w.node_tree.nodes
env = wn.new('ShaderNodeTexEnvironment'); env.image = bpy.data.images.load(os.path.abspath(a.hdri))
w.node_tree.links.new(env.outputs['Color'], wn['Background'].inputs['Color']); wn['Background'].inputs['Strength'].default_value = 0.3

def area(name, loc, size, power, color=(1, 1, 1), target=(0, 0, 0)):
    L = bpy.data.lights.new(name, 'AREA'); L.shape = 'RECTANGLE'; L.size, L.size_y = size; L.energy = power; L.color = color
    o = bpy.data.objects.new(name, L); sc.collection.objects.link(o); o.location = loc
    o.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler(); return o
area('key', (-1.1, 1.3, 1.5), (3.0, 1.4), 34, (1.0, 0.97, 0.94))
area('fill', (1.3, -0.8, 1.0), (1.6, 1.6), 7, (0.92, 0.95, 1.0))
area('rim', (0.2, 2.0, 0.32), (3.2, 0.35), 26, (0.95, 0.96, 1.0), target=(0, 0, 0.05))

# ---------- camera: tight on the hero phone's Live Activities, pulling back and up into the field
cd = bpy.data.cameras.new('cam'); cam = bpy.data.objects.new('cam', cd); sc.collection.objects.link(cam); sc.camera = cam
cd.lens = 50; cd.sensor_fit = 'HORIZONTAL'; cd.sensor_width = 36; cd.clip_start = 0.01
focus = bpy.data.objects.new('focus', None); sc.collection.objects.link(focus)
cd.dof.use_dof = True; cd.dof.focus_object = focus; cd.dof.aperture_blades = 7; cd.dof.aperture_rotation = math.radians(10)
for f in range(1, NF + 1):
    t = (f - 1) / FPS; p = (1 - math.cos(math.pi * clamp(t / DUR))) / 2; q = smooth(clamp(t / DUR))   # sine in-out: still moving at the end
    hx, hy = 0, 0 + (-DRIFT) * t                                    # hero column (c=0) drifts down
    dist = mix(0.215, 0.93, p)
    elev = math.radians(mix(60, 63, q)); az = math.radians(mix(-14, 0, p) + 3.0 * t / DUR)
    tgt = Vector((hx + mix(0.002, 0.0, p), hy + mix(-0.030, 0.010, p), 0.004))
    eye = tgt + Vector((math.sin(az) * math.cos(elev), -math.cos(az) * math.cos(elev), math.sin(elev))) * dist
    cam.location = eye; cam.rotation_euler = (tgt - eye).to_track_quat('-Z', 'Y').to_euler()
    cam.rotation_euler.rotate_axis('Z', math.radians(mix(-3.0, 0.0, q)))   # a slight roll that settles
    cd.dof.aperture_fstop = math.exp(mix(math.log(13.0), math.log(2.8), smooth(clamp(t / 11.0))))
    focus.location = tgt + Vector((0, 0, 0.0005)); focus.keyframe_insert('location', frame=f)
    cam.keyframe_insert('location', frame=f); cam.keyframe_insert('rotation_euler', frame=f); cd.dof.keyframe_insert('aperture_fstop', frame=f)

# ---------- cull phones the camera never sees (fewer objects and fewer screen textures to load per frame)
from bpy_extras.object_utils import world_to_camera_view
seen = set()
for f in range(1, NF + 1, 6):
    sc.frame_set(f)
    for root, x, y0, d, hero in phones:
        y = y0 + d * (f - 1) / FPS
        for cx in (-PW / 2, PW / 2):
            for cy in (-PH / 2, PH / 2):
                v = world_to_camera_view(sc, cam, Vector((x + cx, y + cy, 0.005)))
                if v.z > 0 and -0.08 < v.x < 1.08 and -0.08 < v.y < 1.08: seen.add(root.name)
culled = 0
for root, *_ in phones:
    if root.name not in seen:
        for ch in list(root.children): bpy.data.objects.remove(ch)
        bpy.data.objects.remove(root); culled += 1
print(f'phones: {len(phones)} placed, {culled} never in view, {len(phones) - culled} kept', flush=True)

# ---------- render settings
rx, ry = map(int, a.res.split('x'))
R = sc.render; R.engine = 'CYCLES'; R.resolution_x = rx; R.resolution_y = ry; R.resolution_percentage = a.pct
R.use_persistent_data = True; R.film_transparent = False
R.image_settings.file_format = 'PNG'; R.image_settings.color_depth = '8'; R.image_settings.compression = 15
C = sc.cycles; C.device = 'CPU'; C.samples = a.samples; C.use_adaptive_sampling = True; C.adaptive_threshold = a.noise
C.adaptive_min_samples = min(16, max(4, a.samples // 2)); C.use_denoising = True; C.denoiser = 'OPENIMAGEDENOISE'
ap2 = os.environ.get('PREFILTER', 'ACCURATE'); C.denoising_prefilter = ap2
C.max_bounces = 4; C.diffuse_bounces = 1; C.glossy_bounces = 2; C.transmission_bounces = 2; C.transparent_max_bounces = 4
C.caustics_reflective = False; C.caustics_refractive = False; C.blur_glossy = 1.0
sc.view_settings.view_transform = 'Standard'; sc.view_settings.look = 'None'; sc.view_settings.exposure = 0.0
sc.render.threads_mode = 'FIXED' if a.threads else 'AUTO'
if a.threads: sc.render.threads = a.threads
if a.save: bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(a.save))

frames = []
if a.frames:
    for part in a.frames.split(','):
        if '-' in part: s, e = map(int, part.split('-')); frames += list(range(s, e + 1))
        else: frames.append(int(part))
os.makedirs(a.out, exist_ok=True)
for f in frames:
    path = os.path.join(a.out, f'{f:05d}.png')
    if os.path.exists(path): continue
    t0 = time.time(); sc.frame_set(f); R.filepath = path; bpy.ops.render.render(write_still=True)
    print(f'frame {f} {time.time() - t0:.1f}s', flush=True)
