// Strip EXT_meshopt_compression from a GLB so Blender can import it: node decode-glb.mjs in.glb out.glb
// npm i @gltf-transform/core @gltf-transform/extensions meshoptimizer
import { NodeIO } from '@gltf-transform/core';
import { ALL_EXTENSIONS } from '@gltf-transform/extensions';
import { MeshoptDecoder } from 'meshoptimizer';
await MeshoptDecoder.ready;
const io = new NodeIO().registerExtensions(ALL_EXTENSIONS).registerDependencies({ 'meshopt.decoder': MeshoptDecoder });
const doc = await io.read(process.argv[2]);
const root = doc.getRoot();
console.log('extensions used:', root.listExtensionsUsed().map(e => e.extensionName));
for (const e of root.listExtensionsUsed()) if (e.extensionName === 'EXT_meshopt_compression') e.dispose();
for (const m of root.listMeshes()) for (const p of m.listPrimitives()) {
  const pos = p.getAttribute('POSITION'); const mat = p.getMaterial();
  console.log(m.getName().padEnd(34), 'verts', pos.getCount(), 'mat', mat && mat.getName(), 'uv', !!p.getAttribute('TEXCOORD_0'), 'min', pos.getMin([]).map(v=>+v.toFixed(4)), 'max', pos.getMax([]).map(v=>+v.toFixed(4)));
}
for (const n of root.listNodes()) console.log('node', n.getName(), 's', n.getScale().map(v=>+v.toFixed(4)), 't', n.getTranslation().map(v=>+v.toFixed(4)), 'mesh', n.getMesh()?.getName());
for (const mt of root.listMaterials()) console.log('MAT', mt.getName(), 'base', mt.getBaseColorFactor().map(v=>+v.toFixed(3)), 'metal', mt.getMetallicFactor(), 'rough', mt.getRoughnessFactor(), 'tex', !!mt.getBaseColorTexture(), 'emis', mt.getEmissiveFactor());
await io.write(process.argv[3], doc);
console.log('wrote', process.argv[3]);
