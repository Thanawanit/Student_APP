#!/usr/bin/env python3
"""Smoothness check: frame to frame difference on a 16x12 tile grid; flags spikes (snaps, pops).
Usage: python3 scripts/tiles.py frames   -> prints spike count and the worst (frame, tile, size)."""
import sys, os, numpy as np
from PIL import Image
from concurrent.futures import ProcessPoolExecutor
D = sys.argv[1]; F = sorted(f for f in os.listdir(D) if f.endswith('.png'))
def load(f): return np.asarray(Image.open(os.path.join(D, f)).convert('L').resize((400, 300)), dtype=np.float32)
def diff(i):
    a, b = load(F[i]), load(F[i + 1]); d = np.abs(a - b); return d.reshape(12, 25, 16, 25).mean(axis=(1, 3)).ravel()
if __name__ == '__main__':
    with ProcessPoolExecutor(max(1, (os.cpu_count() or 4) - 1)) as ex: M = np.array(list(ex.map(diff, range(len(F) - 1), chunksize=30)))
    sp = []
    for j in range(M.shape[1]):
        c = M[:, j]
        for i in range(int(len(c) * .12), len(c)):
            nb = np.concatenate([c[max(0, i - 6):i], c[i + 1:i + 7]])
            if c[i] > 2.0 and c[i] > 4 * np.median(nb) + .3: sp.append((i, j, round(float(c[i]), 2)))
    print('spikes', len(sp)); print(sorted(sp, key=lambda x: -x[2])[:40])
