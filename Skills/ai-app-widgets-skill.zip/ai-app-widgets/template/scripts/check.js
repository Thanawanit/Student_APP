// Fast sanity scan without a browser: node scripts/check.js [id,id,...]
// Steps every widget through T = 0..29 at 120 steps per second and reports: thrown errors, NaN / undefined / Infinity in
// the html, height outside the allowed range, and height jumps between consecutive steps (a jump means a snap, not a morph).
const fs = require('fs'), vm = require('vm'), path = require('path');
const files = ['core.js', 'kit.js', ...fs.readdirSync('widgets').filter(f => f.endsWith('.js')).sort().map(f => 'widgets/' + f)];
const ctx = { console, Math, JSON, Array, Object, String, Number, parseInt, parseFloat, isFinite };
vm.createContext(ctx);
for (const f of files) vm.runInContext(fs.readFileSync(f, 'utf8'), ctx, { filename: f });
vm.runInContext('globalThis.W=W;globalThis.MK=MK;', ctx);
const W = ctx.W; const want = process.argv[2] ? process.argv[2].split(',') : Object.keys(W);
let bad = 0;
for (const k of want) {
  if (!W[k]) { console.log(`${k}: MISSING`); bad++; continue; }
  const w = k.startsWith('p_') ? 150 : 236; const issues = []; let prevH = null, maxJump = 0, minH = 1e9, maxH = 0, lenMax = 0;
  for (let i = 0; i <= 29 * 120; i++) {
    const T = i / 120; let r;
    try { r = W[k](T, w); } catch (e) { issues.push(`throws at T=${T}: ${e.message}`); break; }
    if (!r || typeof r.html !== 'string' || !isFinite(r.h)) { issues.push(`bad result at T=${T}`); break; }
    const m = r.html.match(/NaN|undefined|Infinity|\[object/); if (m) { issues.push(`"${m[0]}" in html at T=${T}`); break; }
    minH = Math.min(minH, r.h); maxH = Math.max(maxH, r.h); lenMax = Math.max(lenMax, r.html.length);
    if (prevH != null) maxJump = Math.max(maxJump, Math.abs(r.h - prevH)); prevH = r.h;
  }
  if (w === 150 && (minH !== 50 || maxH !== 50)) issues.push(`pill height must be 50 (got ${minH}..${maxH})`);
  if (w === 236 && (minH < 56 || maxH > 176)) issues.push(`height out of 56..176 (got ${minH.toFixed(1)}..${maxH.toFixed(1)})`);
  if (maxJump > 4) issues.push(`height jumps ${maxJump.toFixed(1)}px between 1/120 s steps (snap)`);
  if (lenMax > 60000) issues.push(`html is very large (${lenMax} chars), simplify`);
  console.log(`${issues.length ? '✗' : '✓'} ${k.padEnd(14)} h ${minH.toFixed(0)}..${maxH.toFixed(0)}  max step ${maxJump.toFixed(2)}px  html<=${lenMax}${issues.length ? '\n    ' + issues.join('\n    ') : ''}`);
  if (issues.length) bad++;
}
process.exitCode = bad ? 1 : 0;
