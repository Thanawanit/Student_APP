// Filmstrip of one widget to catch pops between frames: node scripts/strip.js --id claude_chat --from 3 --to 5 --step 0.05 [--cols 8] [--out out/strip.png]
// Rows of consecutive T values; a state change should look like a smooth progression across neighbouring cells.
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : d; };
(async () => {
  const id = arg('id'), from = +arg('from', 0), to = +arg('to', 2), step = +arg('step', .05), out = arg('out', `out/strip_${id}.png`);
  const ts = []; for (let t = from; t <= to + 1e-9; t += step) ts.push(+t.toFixed(4));
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  const pg = await b.newPage({ viewport: { width: 1400, height: 400 }, deviceScaleFactor: 1.5 });
  await pg.goto('file://' + path.resolve('gallery.html') + '?ids=' + id + '&ts=' + ts.join(','));
  await pg.evaluate(() => document.fonts.ready);
  const cols = +arg('cols', id.startsWith('p_') ? 8 : 6);
  await pg.evaluate(cols => { const row = document.querySelector('.g-row'); row.style.flexWrap = 'wrap'; row.style.width = (cols * (row.querySelector('.g-cell').offsetWidth + 16) + 110) + 'px'; }, cols);
  const el = await pg.$('body'); await el.screenshot({ path: out });
  console.log(out); await b.close();
})();
