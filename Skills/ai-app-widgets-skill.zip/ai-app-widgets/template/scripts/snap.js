// Scene stills for review: node scripts/snap.js 0.5 4 8 16 [--prefix name]  ->  out/<name>still_<t>.png (1600x1200). Run from the template folder.
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs'), { execFileSync } = require('child_process');
(async () => {
  fs.mkdirSync('out', { recursive: true });
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  const pg = await b.newPage({ viewport: { width: 1200, height: 900 }, deviceScaleFactor: 2 });
  const errs = []; pg.on('pageerror', e => errs.push(String(e)));
  await pg.goto('file://' + path.resolve('index.html')); await pg.evaluate(() => document.fonts.ready);
  const av = process.argv.slice(2); const pi = av.indexOf('--prefix'); const pre = pi >= 0 ? av[pi + 1] + '-' : ''; if (pi >= 0) av.splice(pi, 2);
  for (const t of av) {
    await pg.evaluate(t => draw(t), +t);
    const raw = `out/.raw_${pre}${t}.png`; await pg.screenshot({ path: raw });
    execFileSync('ffmpeg', ['-v', 'error', '-y', '-i', raw, '-vf', 'scale=1600:1200:flags=lanczos', `out/${pre}still_${t}.png`]); fs.unlinkSync(raw);
    console.log(`out/${pre}still_${t}.png`);
  }
  console.log('page errors:', errs.slice(0, 3)); await b.close();
})();
