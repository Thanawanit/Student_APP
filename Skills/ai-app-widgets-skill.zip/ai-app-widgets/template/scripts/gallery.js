// Widget review sheet: node scripts/gallery.js --ids claude_chat,p_claude --ts 0,2,4,6 [--out out/gallery.png] [--scale 2]
// One row per widget, one card per T. Prints any card where visible content spills outside the card.
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : d; };
(async () => {
  const ids = arg('ids', ''), ts = arg('ts', '0,2,4,6,8,10'), out = arg('out', 'out/gallery.png'), scale = +arg('scale', 2);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  const pg = await b.newPage({ viewport: { width: 1400, height: 400 }, deviceScaleFactor: scale });
  const errs = []; pg.on('pageerror', e => errs.push(String(e))); pg.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await pg.goto('file://' + path.resolve('gallery.html') + '?ids=' + encodeURIComponent(ids) + '&ts=' + encodeURIComponent(ts));
  await pg.evaluate(() => document.fonts.ready);
  const el = await pg.$('body'); await el.screenshot({ path: out });
  const over = await pg.evaluate(() => window.overflow);
  console.log(out); console.log('overflow:', over.length ? over : 'none'); console.log('page errors:', errs.length ? errs.slice(0, 5) : 'none');
  await b.close();
})();
