#!/usr/bin/env bash
# frames (2400x1800 PNG) -> out/video.mp4 (1600x1200, for X / LinkedIn / Instagram) + out/video_web.mp4 (1200x900, light, for a web page).
# Usage: bash scripts/encode.sh [frames_dir] [out_dir] [fps]
set -e; F=${1:-frames}; O=${2:-out}; R=${3:-60}; mkdir -p "$O"
ffmpeg -v error -y -framerate "$R" -i "$F/%05d.png" -vf "scale=1600:1200:flags=lanczos" -c:v libx264 -preset slow -crf 14 -pix_fmt yuv420p -profile:v high -level 5.1 -movflags +faststart -an "$O/video.mp4"
ffmpeg -v error -y -framerate "$R" -i "$F/%05d.png" -vf "scale=1200:900:flags=lanczos" -c:v libx264 -preset slow -crf 21 -pix_fmt yuv420p -profile:v high -level 4.2 -movflags +faststart -an "$O/video_web.mp4"
for f in "$O/video.mp4" "$O/video_web.mp4"; do ffprobe -v error -count_frames -show_entries stream=width,height,r_frame_rate,nb_read_frames:format=duration,size -of compact "$f"; done
