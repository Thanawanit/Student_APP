// Deterministic frame render: frame i -> draw(i / fps) -> screenshot at device scale 2 (2400x1800 PNG).
// Usage: node scripts/render.js [--fps 60] [--seconds 16.5] [--workers 3] [--out frames]   (run from the template folder)
// encode.sh downscales to 1600x1200 with Lanczos. Workers split the frame range; each runs its own Chromium.
const { chromium } = require('playwright');
const path = require('path'), fs = require('fs');
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : d; };
const fps = +arg('fps', 60), seconds = +arg('seconds', 16.5), workers = +arg('workers', Math.max(1, require('os').cpus().length - 1)), out = arg('out', 'frames');
const N = Math.round(fps * seconds);
fs.mkdirSync(out, { recursive: true });
async function worker(w) {
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  const pg = await b.newPage({ viewport: { width: 1200, height: 900 }, deviceScaleFactor: 2 });
  const errs = []; pg.on('pageerror', e => errs.push(String(e)));
  await pg.goto('file://' + path.resolve('index.html')); await pg.evaluate(() => document.fonts.ready);
  for (let i = Math.floor(w * N / workers); i < Math.floor((w + 1) * N / workers); i++) {
    const f = path.join(out, String(i).padStart(5, '0') + '.png');
    if (fs.existsSync(f)) continue;                       // resumable
    await pg.evaluate(t => draw(t), i / fps);
    await pg.screenshot({ path: f + '.tmp', type: 'png' }); fs.renameSync(f + '.tmp', f);
    if (i % 60 === 0) console.log(`worker ${w}: frame ${i}/${N}`);
  }
  if (errs.length) console.log(`worker ${w} page errors:`, errs.slice(0, 3));
  await b.close();
}
(async () => {
  const t0 = Date.now();
  await Promise.all(Array.from({ length: workers }, (_, w) => worker(w)));
  console.log(`frames: ${fs.readdirSync(out).filter(f => f.endsWith('.png')).length}/${N} in ${((Date.now() - t0) / 1000).toFixed(0)} s`);
})();
