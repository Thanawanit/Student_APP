// Stills of phone screens for review: node phone/shot.js <phone,phone,...> <t> [dsf]  -> out/phone-<p>-<t>.png (run from template/)
const { chromium } = require('playwright'); const path = require('path'), fs = require('fs');
(async () => {
  const [ps, t, dsf] = [process.argv[2].split(','), +process.argv[3], +(process.argv[4] || 1.5)];
  fs.mkdirSync('out', { recursive: true });
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  const pg = await b.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: dsf });
  const errs = []; pg.on('pageerror', e => errs.push(String(e)));
  for (const p of ps) { await pg.goto('file://' + path.resolve('phone/lockscreen.html') + '?p=' + p); await pg.evaluate(() => document.fonts.ready);
    await pg.evaluate(t => draw(t), t); const f = `out/phone-${p}-${t}.png`; await pg.screenshot({ path: f }); console.log(f); }
  console.log('errors', errs.slice(0, 3)); await b.close();
})();
