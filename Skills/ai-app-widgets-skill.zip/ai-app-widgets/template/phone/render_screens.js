// Lock screen image sequences for the Blender film: node phone/render_screens.js [--fps 30] [--frames 675] [--hero-frames 495]
//   [--phones 0-17] [--dsf 1.5] [--hero-dsf 3] [--workers 2] [--out film/screens]      (run from template/)
// Writes <out>/p<i>/00001.jpg ... (frame 1 = t 0). The hero (phone 0) is PNG at hero-dsf; the rest JPEG q94. Resumable.
const { chromium } = require('playwright'); const path = require('path'), fs = require('fs');
const arg = (k, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : d; };
const fps = +arg('fps', 30), NF = +arg('frames', 675), NH = +arg('hero-frames', 495), dsf = +arg('dsf', 1.5), hdsf = +arg('hero-dsf', 3);
const out = path.resolve(arg('out', 'film/screens')), workers = +arg('workers', 2);
const [p0, p1] = arg('phones', '0-17').split('-').map(Number); const phones = []; for (let p = p0; p <= p1; p++) phones.push(p);
async function run(list, w) {
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  for (const p of list) {
    const hero = p === 0; const pg = await b.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: hero ? hdsf : dsf });
    const errs = []; pg.on('pageerror', e => errs.push(String(e)));
    await pg.goto('file://' + path.resolve('phone/lockscreen.html') + '?p=' + p); await pg.evaluate(() => document.fonts.ready);
    const dir = path.join(out, 'p' + p); fs.mkdirSync(dir, { recursive: true }); const n = hero ? NH : NF; const t0 = Date.now();
    for (let f = 1; f <= n; f++) {
      const file = path.join(dir, String(f).padStart(5, '0') + (hero ? '.png' : '.jpg')); if (fs.existsSync(file)) continue;
      await pg.evaluate(t => draw(t), (f - 1) / fps);
      await pg.screenshot(hero ? { path: file + '.tmp.png', type: 'png' } : { path: file + '.tmp.jpg', type: 'jpeg', quality: 94 });
      fs.renameSync(file + (hero ? '.tmp.png' : '.tmp.jpg'), file);
    }
    console.log(`worker ${w}: phone ${p} done (${n} frames, ${((Date.now() - t0) / 1000).toFixed(0)} s)${errs.length ? ' errors: ' + errs.slice(0, 2) : ''}`);
    await pg.close();
  }
  await b.close();
}
(async () => { const lists = Array.from({ length: workers }, () => []); phones.forEach((p, i) => lists[i % workers].push(p));
  await Promise.all(lists.map((l, w) => run(l, w))); console.log('screens done'); })();
