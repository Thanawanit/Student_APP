// One entry per phone screen: island pill, Live Activity stack (top to bottom), wallpaper tint, clock offset (seed).
// Phone 0 is the hero the camera starts on.
const PHONES=[
 {pill:'p_claude',      wides:['claude_code','claude_chat'],   tint:['#D97757','#8A4A32'], time:'9:41', seed:0.6},
 {pill:'p_gpt',         wides:['gpt_voice','gpt_research'],    tint:['#2F7BF6','#10A37F'], time:'10:24', seed:3.1},
 {pill:'p_gemini',      wides:['gemini_image','notebooklm'],   tint:['#4796E3','#D96570'], time:'8:15', seed:5.4},
 {pill:'p_pplx',        wides:['perplexity','linear'],         tint:['#20B8CD','#5E6AD2'], time:'11:02', seed:1.9},
 {pill:'p_grok',        wides:['grok','suno'],                 tint:['#5AA9FF','#FF4FA3'], time:'7:58', seed:7.2},
 {pill:'p_mj',          wides:['midjourney','figma'],          tint:['#A259FF','#1ABCFE'], time:'9:12', seed:4.4},
 {pill:'p_cursor',      wides:['cursor','slack'],              tint:['#3FB950','#ECB22E'], time:'12:30', seed:9.0},
 {pill:'p_notion',      wides:['notion','eleven'],             tint:['#FF453A','#9E8CFF'], time:'6:47', seed:2.7},
 {pill:'p_linear',      wides:['linear','claude_chat'],        tint:['#5E6AD2','#D97757'], time:'10:09', seed:6.3},
 {pill:'p_slack',       wides:['slack','gpt_voice'],           tint:['#2BAC76','#6EB6FF'], time:'9:56', seed:8.1},
 {pill:'p_eleven',      wides:['eleven','perplexity'],         tint:['#B49CFF','#20B8CD'], time:'8:33', seed:0.2},
 {pill:'p_claude_code', wides:['claude_chat','cursor'],        tint:['#D97757','#3FB950'], time:'11:48', seed:10.4},
 {pill:'p_gpt',         wides:['gpt_research','gemini_image'], tint:['#10A37F','#4796E3'], time:'7:21', seed:11.3},
 {pill:'p_grok',        wides:['notebooklm','grok'],           tint:['#8AB4F8','#5AA9FF'], time:'10:37', seed:3.8},
 {pill:'p_mj',          wides:['figma','midjourney'],          tint:['#F24E1E','#A259FF'], time:'9:05', seed:5.9},
 {pill:'p_gemini',      wides:['notion','gemini_image'],       tint:['#9177C7','#4796E3'], time:'8:52', seed:1.2},
 {pill:'p_pplx',        wides:['eleven','linear'],             tint:['#20B8CD','#9E8CFF'], time:'12:14', seed:7.7},
 {pill:'p_claude',      wides:['claude_chat','gpt_voice'],     tint:['#D97757','#2F7BF6'], time:'9:27', seed:9.6},
];
