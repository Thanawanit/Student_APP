// Contact sheet of every lock screen at time t, with the clock zone and the stack top reported:
// node phone/sheet.js <t> [out]   (run from template/)
const { chromium } = require('playwright'); const path = require('path');
(async () => {
  const t = +process.argv[2], out = process.argv[3] || `out/phones-sheet-${t}.png`;
  const b = await chromium.launch({ args: ['--force-color-profile=srgb', '--font-render-hinting=none'] });
  const pg = await b.newPage({ viewport: { width: 402, height: 874 }, deviceScaleFactor: 1 });
  const shots = []; const tops = [];
  for (let p = 0; p < 18; p++) {
    await pg.goto('file://' + path.resolve('phone/lockscreen.html') + '?p=' + p); await pg.evaluate(() => document.fonts.ready);
    await pg.evaluate(t => draw(t), t);
    tops.push(await pg.evaluate(() => Math.min(...[...document.querySelectorAll('#scr > .w')].map(e => e.getBoundingClientRect().top))));
    shots.push(await pg.screenshot());
  }
  const sheet = await b.newPage({ viewport: { width: 9 * 210, height: 2 * 450 } });
  await sheet.setContent(`<body style="margin:0;background:#333;display:flex;flex-wrap:wrap;gap:6px;padding:6px">${shots.map((s, i) => `<div style="position:relative"><img src="data:image/png;base64,${s.toString('base64')}" style="width:201px;height:437px;border-radius:24px;display:block"><span style="position:absolute;left:8px;bottom:6px;color:#ff0;font:11px monospace">p${i} top ${tops[i].toFixed(0)}</span></div>`).join('')}</body>`);
  await sheet.screenshot({ path: out, fullPage: true }); console.log(out); console.log('stack tops (clock ends near 206):', tops.map(v => Math.round(v)).join(' '));
  await b.close();
})();
