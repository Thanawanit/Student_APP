const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const mix=(a,b,p)=>a+(b-a)*p;
const expo=p=>p<=0?0:p>=1?1:(1-Math.pow(2,-10*p))/(1-Math.pow(2,-10));
const sprRaw=p=>1-Math.exp(-6.5*p)*(Math.cos(9.86*p)+(6.5/9.86)*Math.sin(9.86*p));const spring=p=>p<=0?0:p>=1?1:sprRaw(p)/sprRaw(1);
const soft=p=>{const f=q=>1-Math.exp(-7*q)*(1+7*q);return p<=0?0:p>=1?1:f(p)/f(1)};
const io=p=>{p=clamp(p);return p<.5?16*p**5:1-Math.pow(-2*p+2,5)/2};
const md=(k,n)=>((k%n)+n)%n;
function st(t,P,o){const x=t-o;if(x<0)return {k:0,l:0,pre:1};const k=Math.floor(x/P);return {k,l:x-k*P}}
function st2(t,P,o){const x=t-o;if(x<0)return {k:0,l:99};const k=Math.floor(x/P)+1;return {k,l:x-(k-1)*P}}
function tw(t,P,o,vals,dur,e=spring){const {k,l}=st2(t,P,o);const a=vals[md(k-1,vals.length)],b=vals[md(k,vals.length)];return mix(a,b,e(clamp(l/dur)))}
function hexmix(a,b,p){const pa=[1,3,5].map(i=>parseInt(a.substr(i,2),16)),pb=[1,3,5].map(i=>parseInt(b.substr(i,2),16));return `rgb(${pa.map((v,i)=>Math.round(mix(v,pb[i],p))).join(',')})`}
// rolling digits: from string -> to string, l = seconds since change
function roll(f,to,l,dur=.7,stg=.045){const n=Math.max(f.length,to.length);f=f.padStart(n,' ');to=to.padStart(n,' ');let s='';
for(let i=0;i<n;i++){const a=f[i],b=to[i];const p=spring(clamp((l-i*stg)/dur));const da=/\d/.test(a),db=/\d/.test(b);
 if(da&&db){const y=mix(+a,+b,p);s+=`<span class="rc"><span style="display:block;transform:translateY(${-y*1.2}em)">${[0,1,2,3,4,5,6,7,8,9].map(d=>`<b style="height:1.2em">${d}</b>`).join('')}</span></span>`}
 else if(a===b){s+=a===' '?'':`<span class="rc">${a}</span>`}
 else{const pe=expo(clamp((l-i*stg)/(dur*.6)));if(a===' '&&!db){s+=`<span class="rc" style="opacity:${pe}">${b}</span>`;continue}
  const w=a===' '?pe:b===' '?1-pe:1;s+=`<span class="rc" style="max-width:${w*0.7}em"><span style="display:block;transform:translateY(${-pe*1.2}em)"><b style="height:1.2em;opacity:${1-pe}">${a===' '?'&nbsp;':a}</b><b style="height:1.2em;opacity:${pe}">${b===' '?'&nbsp;':b}</b></span></span>`}}
return `<span class="rl">${s}</span>`}
function rollV(t,P,o,vals,fmt,dur,stg){const {k,l}=st2(t,P,o);const a=vals[md(k-1,vals.length)],b=vals[md(k,vals.length)];return roll(fmt(a),fmt(b),l,dur,stg)}
const chkPath=(p,c='#fff',s=10,w=3.2)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" pathLength="1" stroke-dasharray="1 1" stroke-dashoffset="${1-p}"/></svg>`;
function noise(x){return .5*Math.sin(x*.9)+.32*Math.sin(x*2.3+1.3)+.18*Math.sin(x*4.1+2.1)+.1*Math.sin(x*7.3)}
const fmtC=v=>v.toLocaleString('en-US');
// generic draw with staggered spring intro. L rows: [id,x,y,w,h,cls]
function makeDraw(L,W,SW,SH,extra){return function(t){let h='';for(const [k,x,y,w,hh,cls] of L){const d=.12+(x/SW)*.55+(y/SH)*.38;const p=clamp((t-d)/.75);const sc=.86+.14*spring(p);const op=expo(clamp((t-d)/.3));const ci=expo(clamp((t-d-.12)/.45));
 const ctx={};const body=W[k](t,ctx,w,hh);const bg=ctx.bg?`background:${ctx.bg};`:'';
 h+=`<div class="t ${cls}" style="left:${x}px;top:${y}px;width:${w}px;height:${hh}px;${bg}opacity:${op};transform:scale(${sc})"><div class="in" style="opacity:${ci};transform:translateY(${(1-ci)*6}px)">${body}</div></div>`}
 document.getElementById('root').innerHTML=h;if(extra)extra(t)}}
// counter that ticks by `step` at `rate` units/s and rolls each change
function cnt(v,step,rate,fmt,dur=.55){const n=Math.floor(v/step+1e-9);const secs=(v-n*step)/rate;return roll(fmt((n-1)*step),fmt(n*step),secs,dur)}
// per-char typed reveal (fade + rise) instead of hard char pops
function typeIn(s,l,cps=22,fade=.12){return [...s].map((ch,i)=>{const p=clamp((l-i/cps)/fade);return `<span style="opacity:${p};display:inline-block;transform:translateY(${(1-p)*3}px);white-space:pre">${ch}</span>`}).join('')}
const seg=(t,a,b)=>clamp((t-a)/(b-a));
const win=(t,a,b,fi=.6,fo=.6)=>soft(seg(t,a,a+fi))*(1-soft(seg(t,b-fo,b)));
// keyframes [[time,value],...] eased with soft between keys
function kf(t,K,e=soft){if(t<=K[0][0])return K[0][1];for(let i=1;i<K.length;i++){if(t<=K[i][0]){const p=e(seg(t,K[i-1][0],K[i][0]));return mix(K[i-1][1],K[i][1],p)}}return K[K.length-1][1]}
// cyclic odometer: digits roll the short way (9->0 is one step)
function roll2(f,to,l,dur=.5,stg=.035){const n=Math.max(f.length,to.length);f=f.padStart(n,' ');to=to.padStart(n,' ');let s='';
for(let i=0;i<n;i++){const a=f[i],b=to[i];const p=spring(clamp((l-(n-1-i)*stg)/dur));const da=/\d/.test(a),db=/\d/.test(b);
 if(da&&db){let d=((+b-+a)%10+10)%10;if(d>5)d-=10;const pos=+a+d*p+10;s+=`<span class="rc"><span style="display:block;transform:translateY(${-pos*1.2}em)">${[...Array(30)].map((_,j)=>`<b>${j%10}</b>`).join('')}</span></span>`}
 else if(a===b){s+=a===' '?'':`<span class="rc">${a}</span>`}
 else{const pe=soft(clamp((l-(n-1-i)*stg)/(dur*.7)));const w=a===' '?pe:b===' '?1-pe:1;s+=`<span class="rc" style="max-width:${w*.72}em"><span style="display:block;transform:translateY(${-pe*1.2}em)"><b style="opacity:${1-pe}">${a===' '?'&nbsp;':a}</b><b style="opacity:${pe}">${b===' '?'&nbsp;':b}</b></span></span>`}}
return `<span class="rl">${s}</span>`}
const tickUp=(x,fmt,dur=.45)=>{const n=Math.floor(x);return roll2(fmt(n-1),fmt(n),x-n,dur)};
const tickDn=(x,T0,fmt,dur=.45)=>{const n=Math.floor(x);return roll2(fmt(T0-n+1),fmt(T0-n),x-n,dur)};
const mmss=s=>`${Math.floor(s/60)}:${String(((s%60)+60)%60).padStart(2,'0')}`;
const rollL=(t,P,o,vals,fmt,dur=.6)=>{const {k,l}=st2(t,P,o);return roll2(fmt(vals[md(k-1,vals.length)]),fmt(vals[md(k,vals.length)]),l,dur)};
const ease3=p=>{p=clamp(p);return p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2};
