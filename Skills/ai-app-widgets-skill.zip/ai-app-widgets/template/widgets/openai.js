// widgets/openai.js: ChatGPT Voice, ChatGPT Deep research, and the voice pill. Every top-level name is prefixed oa_.
const oa_B='#6EB6FF',oa_BD='#2F7BF6',oa_GR='#10A37F';

// Brand mark: an original rounded hexagon ring with a centre dot (not the official knot).
MK.chatgpt=(s=16,T=0,c='#FFFFFF')=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" style="flex:none"><path d="M12 3.4l7.45 4.3v8.6L12 20.6l-7.45-4.3V7.7z" stroke="${c}" stroke-width="2.4" stroke-linejoin="round"/><circle cx="12" cy="12" r="2.7" fill="${c}"/></svg>`;

// ---------- the voice orb: layered radial gradients, clouds drift on rotating layers, swells with speech
// D sphere diameter. spk 0..1 speaking weight, amp 0..1 speech amplitude, thk 0..1 thinking weight.
// The glow reaches about 0.2*D outside the sphere: leave that much room around it.
// Clouds live on a slowly turning globe: [latitude, longitude at T=0, size (fraction of D), turn speed rad/s, alpha, kind]
// kind 0 white cloud, 1 deep blue weather, 2 pale cyan haze. Foreshortened toward the limb, hidden on the far side.
const oa_CL=[[.4,.2,.78,.5,.95,0],[.52,.75,.5,.5,.9,0],[-.05,2.2,.86,.5,.92,0],[.08,2.75,.5,.5,.85,0],[-.5,4.1,.74,.5,.88,0],[-.38,4.6,.46,.5,.8,0],[.6,3.4,.6,.5,.82,0],[.15,5.3,.7,.5,.9,0],
 [-.25,.6,1.05,.3,.72,1],[.3,3.6,.95,.3,.62,1],[-.62,5.4,.8,.3,.6,2],[.05,2.4,.75,.3,.45,2]];
const oa_CLL=[0,2,4,8,9];
function oa_orb(T,D,spk=0,amp=0,thk=0,lite=false){
 const calm=1-spk;
 const sc=1+.025*Math.sin(T*1.6)*calm*(1-thk)+spk*(.02+.1*amp)-.05*thk;
 const wob=spk*(.35+.65*amp);
 const g=(.2+.08*Math.sin(T*1.6)*calm+.4*spk*amp+.1*spk).toFixed(3);
 const R=D/2;const COL=['255,255,255','26,88,232','150,222,255'];
 let blobs='';
 (lite?oa_CLL.map(i=>oa_CL[i]):oa_CL).forEach((c,i)=>{const lon=c[1]+T*c[3]+wob*.35*Math.sin(T*2.1+i*1.7);const cl=Math.cos(lon);const o=c[4]*smooth(clamp((cl+.12)*2.4));if(o<.01)return;
  const lat=c[0]+wob*.08*Math.sin(T*2.6+i);const x=R*.95*Math.sin(lon)*Math.cos(lat),y=-R*.95*Math.sin(lat);
  const sw=c[2]*D*(1+.12*wob),sh=sw*.56;const fx=.35+.65*Math.max(0,cl);
  blobs+=`<i style="position:absolute;left:0;top:0;width:${sw.toFixed(2)}px;height:${sh.toFixed(2)}px;border-radius:50%;transform:translate(${(R+x-sw/2).toFixed(3)}px,${(R+y-sh/2).toFixed(3)}px) scaleX(${fx.toFixed(3)});opacity:${o.toFixed(3)};background:radial-gradient(closest-side,rgba(${COL[c[5]]},1),rgba(${COL[c[5]]},.8) 32%,rgba(${COL[c[5]]},.32) 64%,rgba(${COL[c[5]]},0))"></i>`});
 return `<div style="position:relative;width:${D}px;height:${D}px;flex:none">
<div style="position:absolute;left:${-D*.15}px;top:${-D*.15}px;width:${D*1.3}px;height:${D*1.3}px;border-radius:50%;background:radial-gradient(closest-side,rgba(110,182,255,${g}),rgba(47,123,246,${(g*.3).toFixed(3)}) 70%,rgba(47,123,246,0));transform:scale(${sc.toFixed(4)})"></div>
<div style="position:absolute;inset:0;border-radius:50%;overflow:hidden;transform:scale(${sc.toFixed(4)});background:radial-gradient(150% 120% at 50% 0%,#E4F3FF 0%,#9DD0FF 26%,#62AEFF 50%,#2F7BF6 76%,#1E4FCB 100%)">
<div style="position:absolute;inset:0;transform:rotate(-16deg)">${blobs}</div>
<i style="position:absolute;inset:0;border-radius:50%;background:radial-gradient(70% 38% at 50% 104%,rgba(160,228,255,.5),rgba(160,228,255,0))"></i>
<i style="position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle at 50% 42%,rgba(16,50,170,0) 55%,rgba(16,56,190,.3) 79%,rgba(10,34,130,.62) 100%)"></i>
<i style="position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle at 33% 23%,rgba(255,255,255,.95),rgba(255,255,255,.35) 11%,rgba(255,255,255,0) 26%)"></i>
</div></div>`}

// ---------- gpt_voice: ChatGPT Voice mode live activity
const oa_VP=12;
const oa_TX=[
 ['Why is my sourdough so flat?','Your starter may be a bit sleepy.'],
 ['Plan a rainy Saturday for me?','Museum at ten, then hot ramen.'],
 ['How do I say no to a meeting?','Offer a quick written update.']];
W.gpt_voice=(T,w)=>{
 const l=md(T,oa_VP),k=Math.floor(T/oa_VP);
 // 0 Listening, 1 Thinking, 2 Speaking, 3 Listening again (same as 0, so the wrap is seamless)
 const x=kf(l,[[0,0],[3.1,0],[3.7,1],[4.5,1],[5.1,2],[10.3,2],[11,3],[12,3]]);
 const thk=clamp(1-Math.abs(x-1)*1.4), spk=clamp(1-Math.abs(x-2)*1.6);
 const amp=clamp(.5+.55*noise(T*3.3)*(.7+.3*Math.sin(T*1.1)));
 const lis=clamp(1-x*1.6)+clamp(1-(3-x)*1.6); const lvl=lis*clamp(.5+.6*noise(T*2.6+4));
 // two springy expands: the live transcript row opens while it listens, the answer row when it speaks
 const e1=morph(T,oa_VP,.35,10.4),e2=morph(T,oa_VP,4.9,10.4); const h=100+32*e1+18*e2;
 const tx=oa_TX[md(k,3)];
 // what the user says is transcribed live (bright), then dims to history once the answer starts
 const ql=l-.6,qn=tx[0].length,qdone=qn/16;
 const qTxt=typeIn(tx[0].slice(0,clamp(Math.ceil(ql*16),0,qn)),ql,16);
 const qc=hexmix('#D8D8DC','#6E6E76',soft(seg(l,4.7,5.5)));
 const qcar=clamp(ql/.3)*(1-soft(clamp((ql-qdone-.35)/.4)));
 const lab=['Listening',shimmer('Thinking',T,'#6E6E76','#FFFFFF',.9),'Speaking','Listening'];
 const btn=(inner,extra='')=>`<div style="width:28px;height:28px;border-radius:50%;background:#1C1C20;display:flex;align-items:center;justify-content:center;flex:none;${extra}">${inner}</div>`;
 const r1=clamp((e1-.7)/.25),y1=(1-e1)*6,r2=clamp((e2-.7)/.25),y2=(1-e2)*6; const tl=l-5.3,tdone=tx[1].length/13;
 return {h,html:`<div class="in" style="padding:14px 16px">
<div style="position:absolute;left:22px;top:20px">${oa_orb(T,60,spk,amp,thk)}</div>
<div style="position:absolute;left:100px;right:16px;top:16px">
 <div class="row m" style="gap:5px">${MK.chatgpt(11,T,'#8E8E93')}ChatGPT Voice</div>
 <div style="position:relative;height:22px;margin-top:3px;font-size:16px;font-weight:600;letter-spacing:-.2px">${xstack(lab,x,8)}</div>
</div>
<div class="row" style="position:absolute;left:100px;right:16px;top:60px;gap:6px">${btn(ico('mic','#FFFFFF',13,2.1),`box-shadow:0 0 0 ${(lvl*3.5).toFixed(2)}px ${rgba(oa_B,.28)}`)}${btn(ico('x','#FFFFFF',12,2.4))}<span class="sp"></span><span style="font-size:15px;font-weight:600;color:${oa_B};letter-spacing:-.3px">${tickUp(134.6+T,mmss)}</span></div>
<div style="position:absolute;left:16px;right:16px;top:98px;height:23px;opacity:${r1.toFixed(3)};transform:translateY(${y1.toFixed(3)}px)">
 <div style="height:1px;background:#1A1A1E"></div>
 <div style="position:absolute;left:0;top:9px;font-size:10.5px;font-weight:500;line-height:13px;color:${qc}">${qTxt}<span style="opacity:${qcar.toFixed(3)}">${caret(T,'#8E8E93',10)}</span></div>
</div>
<div style="position:absolute;left:16px;right:16px;top:124px;font-size:11.5px;font-weight:500;line-height:15px;color:#FFFFFF;opacity:${r2.toFixed(3)};transform:translateY(${y2.toFixed(3)}px)">${typeIn(tx[1].slice(0,clamp(Math.ceil(tl*13),0,tx[1].length)),tl,13)}<span style="opacity:${(clamp(tl/.3)*(1-soft(clamp((tl-tdone-.6)/.5)))).toFixed(3)}">${caret(T,oa_B,11)}</span></div>
</div>`}};

// ---------- gpt_research: Deep research in progress
const oa_RD=[2.8,2.8,2.6,2.8,2.2];
const oa_SRC=[['V','#7CE3B4','#1FA37A'],['A','#FFC27A','#FF8A3D'],['G','#8FB8FF','#4F7BFF'],['L','#D3A6FF','#9B5CFF'],['R','#FF9FB8','#FF5A7E'],['C','#8EE6F0','#2FB5C9'],['M','#FFE38A','#F2B92B'],['N','#B7C0FF','#6B74F5'],['E','#FFB0A0','#F06548'],['K','#C2F08C','#7CC23A']];
const oa_ARR=oa_SRC.map((_,j)=>1+j*.72);
const oa_CNT=[3,6,9,13,16,20,24,27,31,35,38];
const oa_TOP=['EV battery recycling','Heat pump savings','Four-day work weeks'];
// reset crossfade for a right-aligned value (old rises out, new rises in), always wrapped so nothing shifts
const oa_xf=(a,b,k,dy=6)=>{const lay=(s,o,y)=>o<=.001?'':`<span style="grid-area:1/1;justify-self:end;opacity:${o.toFixed(3)};transform:translateY(${y.toFixed(2)}px)">${s}</span>`;
 const oa=k<=0?1:clamp(1-k*2),ob=k>=1?1:clamp(k*2-1);return `<span style="display:inline-grid;vertical-align:top">${lay(a,oa,-clamp(k)*dy)}${lay(b,ob,(1-clamp(k))*dy)}</span>`};
const oa_PROP="font-feature-settings:'cv11','ss01'";
const oa_chev=c=>`<svg width="7" height="9" viewBox="0 0 7 9" style="flex:none"><path d="M1.6 1.2L5 4.5 1.6 7.8" stroke="${c}" stroke-width="1.7" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const oa_disc=(s,x,sc,o)=>`<div style="position:absolute;left:0;top:0;transform:translateX(${x.toFixed(3)}px) scale(${sc.toFixed(3)});opacity:${o.toFixed(3)};width:20px;height:20px;border-radius:50%;background:linear-gradient(135deg,${s[1]},${s[2]});box-shadow:0 0 0 2px #050506;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#0B0B10">${s[0]}</div>`;
W.gpt_research=(T,w)=>{
 const A=oa_GR;const ph=phases(T,oa_RD);const l=md(T,ph.P);
 // a cycle opens with the finished previous run fading away (old 1 -> 0) while the new run starts
 const old=ph.i==0?1-soft(clamp(l/.9)):0;
 const sp=ph.i<4?ph.i+ph.p:4;
 // step text
 const steps=[`Searching the web`,`Reading 12 pages`,`Comparing sources`,`Writing report`];
 const items=steps.map(s=>shimmer(s,T,'#7A7A82','#FFFFFF',.8)).concat([`<span class="row" style="gap:5px;color:${A}">${tick(ph.i==4?clamp(ph.l/.5):1,A,11,3.4)}Report ready</span>`]);
 const sk=spring(clamp(ph.l/.75));
 // time left rolls down at each step, then crossfades to Done
 const N=[8,6,4,2,2];const tl=ph.i==0?roll2('8','8',9):roll2(String(N[ph.i-1]),String(N[ph.i]),ph.l,.6);
 const tItems=[`~<b style="color:#fff;font-weight:600">${tl}</b> min left`,`<span style="color:${A};font-weight:600">Done</span>`];
 const tsel=ph.i==4?soft(clamp(ph.l/.6)):(ph.i==0?1-soft(clamp(ph.l/.6)):0);
 // sources counter rolls up as each source lands
 let idx=0;for(let j=0;j<oa_ARR.length;j++)if(l>=oa_ARR[j])idx=j+1;
 const z=v=>roll2(String(v),String(v),9);
 const count=idx==0?oa_xf(z(oa_CNT[10]),z(oa_CNT[0]),soft(clamp(l/.6))):oa_xf(roll2(String(oa_CNT[idx-1]),String(oa_CNT[idx]),l-oa_ARR[idx-1],.55),'',0);
 // done: the discs gather into a stack, an Open report pill slides in, a sheen runs over the finished bar
 const gat=ph.i==4?spring(clamp((ph.l-.15)/.85)):0, gp=mix(16.5,10.5,gat);
 const rp=ph.i==4?spring(clamp((ph.l-.4)/.8)):1, rpO=ph.i==4?soft(clamp((ph.l-.4)/.35)):old;
 const shx=ph.i==4?mix(-46,214,io(clamp((ph.l-.55)/1.25))):-99;
 // source discs: appended left to right, each springs in from the right and pings as it lands
 let discs='';
 if(rpO>.001)discs+=`<div class="row" style="position:absolute;right:0;top:0;height:20px;padding:0 7px 0 9px;gap:3px;border-radius:10px;background:${rgba(A,.16)};color:${A};font-size:9.5px;font-weight:600;${oa_PROP};opacity:${rpO.toFixed(3)};transform:translateX(${((1-rp)*16).toFixed(2)}px)">Open report${oa_chev(A)}</div>`;
 if(old>.001)oa_SRC.forEach((s,j)=>{discs+=oa_disc(s,j*10.5-(1-old)*6,.9+.1*old,old)});
 oa_SRC.forEach((s,j)=>{const u=clamp((l-oa_ARR[j])/.8);if(u<=0)return;const p=spring(u);const x=j*gp+(1-p)*34;const o=clamp(u*3.2);
  const q=clamp((l-oa_ARR[j]-.3)/.75);if(q>0&&q<1)discs+=`<i style="position:absolute;left:0;top:0;width:20px;height:20px;border-radius:50%;box-shadow:0 0 0 1.4px ${s[2]};transform:translateX(${x.toFixed(3)}px) scale(${(1+.75*soft(q)).toFixed(3)});opacity:${(.75*(1-q)).toFixed(3)}"></i>`;
  discs+=oa_disc(s,x,.7+.3*p,o)});
 // ring: overall progress; the finished ring fades out on reset
 const done=ph.i==4?soft(clamp(ph.l/.5)):old;
 const segW=(204-9)/4;
 const segs=[0,1,2,3].map(i=>`<div style="position:relative;width:${segW}px;height:4px;border-radius:2px;background:#1C1F1E;overflow:hidden;flex:none"><div style="position:absolute;inset:0;border-radius:2px;background:${A};transform:translateX(${((clamp(sp-i)-1)*segW).toFixed(3)}px)"></div>${old>.001?`<div style="position:absolute;inset:0;border-radius:2px;background:${A};opacity:${old.toFixed(3)}"></div>`:''}${shx>-60&&shx<210?`<i style="position:absolute;top:0;bottom:0;left:0;width:46px;background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,.6),rgba(255,255,255,0));transform:translateX(${(shx-i*(segW+3)).toFixed(2)}px)"></i>`:''}</div>`).join('');
 const ctr=`position:absolute;inset:0;display:flex;align-items:center;justify-content:center`;
 return {h:130,html:`<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px"><div style="position:relative;width:32px;height:32px;flex:none">${ring(sp/4,32,3,A,'#1F2A26')}${old>.001?`<div style="position:absolute;inset:0;opacity:${old.toFixed(3)}">${ring(1,32,3,A,'#1F2A26')}</div>`:''}<div style="${ctr};opacity:${(1-done).toFixed(3)}">${MK.chatgpt(14,T)}</div><div style="${ctr};opacity:${done.toFixed(3)}">${tick(ph.i==4?done:1,A,14,3.2)}</div></div>
<div style="line-height:1.25;flex:1"><div class="row m"><span>Deep research</span><span class="sp"></span><span style="position:relative;width:70px;height:13px">${xstack(tItems,tsel,6,'text-align:right')}</span></div><div style="position:relative;height:16px;font-size:13px;font-weight:600">${xswap(oa_TOP,Math.floor(T/ph.P),ph.i==0?spring(clamp(ph.l/.75)):1,7,oa_PROP)}</div></div></div>
<div class="row" style="position:absolute;left:16px;right:16px;top:58px"><div style="position:relative;flex:1;height:16px;font-size:11.5px;font-weight:500">${xswap(items,ph.i,sk,7)}</div><span style="font-size:15px;font-weight:600;color:${A};letter-spacing:-.3px">${count}</span><span class="m" style="margin-left:4px">sources</span></div>
<div style="position:absolute;left:16px;right:16px;top:82px;height:20px">${discs}</div>
<div class="row" style="position:absolute;left:16px;right:16px;top:112px;gap:3px">${segs}</div>
</div>`}};

// ---------- p_gpt: tiny breathing orb + elapsed voice timer
W.p_gpt=T=>{const spk=clamp(.5+.5*Math.sin(T*.7));const amp=clamp(.5+.55*noise(T*3.3));const br=1+.07*Math.sin(T*2.1)+.05*spk*amp;
 return {h:50,html:pill(`<div style="width:20px;height:20px;position:relative;flex:none"><div style="position:absolute;left:1px;top:1px;transform:scale(${br.toFixed(4)})">${oa_orb(T,18,spk*.8,amp,0,true)}</div></div>`,oa_B,tickUp(134.6+T,mmss))}};
