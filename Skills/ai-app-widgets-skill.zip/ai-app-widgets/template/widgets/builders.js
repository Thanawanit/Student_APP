// widgets/builders.js: Cursor (agent diff), Linear (issue workflow), Figma (multiplayer canvas). Every top-level name here starts with bd_.
const bd_G = '#3FB950', bd_RD = '#F85149', bd_IND = '#5E6AD2', bd_INDL = '#7A84EA', bd_FB = '#0D99FF';
const bd_MONO = "font-family:'JetBrains Mono',ui-monospace,monospace";

// ---------- helpers (bd_ prefix)
// color mix that returns #RRGGBB, so it can be nested
const bd_hx = (a, b, p) => '#' + [1, 3, 5].map(i => Math.round(mix(parseInt(a.substr(i, 2), 16), parseInt(b.substr(i, 2), 16), clamp(p))).toString(16).padStart(2, '0')).join('');
// stepped value that rolls at each key: K = [[time, value], ...] sorted, K[0][0] = 0
function bd_steps(l, K, fmt, dur = .5) {
  let i = 0; while (i < K.length - 1 && l >= K[i + 1][0]) i++;
  if (i === 0) return roll2(fmt(K[0][1]), fmt(K[0][1]), 9, dur);
  return roll2(fmt(K[i - 1][1]), fmt(K[i][1]), l - K[i][0], dur);
}
// crossfade weight split: v 0..1 between an old and a new layer with a dead zone in the middle, so texts never overlap
const bd_oOld = v => clamp((.45 - v) * 2.2), bd_oNew = v => clamp((v - .55) * 2.2);
// a gentle bump 0 -> 1 -> 0 that starts and ends at rest
const bd_bump = p => Math.sin(Math.PI * smooth(p));

// ---------- brand marks (own simple glyphs)
// Cursor: an outlined isometric cube, top face lit
MK.cursor = (s, T) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" style="flex:none"><path d="M12 3.2L19.6 7.6L12 12L4.4 7.6Z" fill="rgba(255,255,255,.92)"/><path d="M12 12L19.6 7.6V16.4L12 20.8Z" fill="rgba(255,255,255,.32)"/><path d="M12 3.2L19.6 7.6V16.4L12 20.8L4.4 16.4V7.6Z M12 12V20.8" stroke="#fff" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"/></svg>`;
// Linear: an indigo disc cut by three diagonal gaps (bands computed as chords, no clip ids)
const bd_LINP = (() => {
  const r = 9.6, c = 12, q = Math.SQRT1_2; const f = p => `${p[0].toFixed(2)} ${p[1].toFixed(2)}`;
  const P = (d, s) => { const h = Math.sqrt(Math.max(0, r * r - d * d)) * s; return [c + q * d + q * h, c + q * d - q * h]; };
  const arc = (a, b) => { let D = Math.atan2(b[1] - c, b[0] - c) - Math.atan2(a[1] - c, a[0] - c); while (D > Math.PI) D -= 2 * Math.PI; while (D <= -Math.PI) D += 2 * Math.PI; return `A${r} ${r} 0 0 ${D > 0 ? 1 : 0} ${f(b)}`; };
  const E = [-r]; [[-4.7, 1.9], [-.5, 1.9], [3.7, 1.9]].forEach(([g, w]) => E.push(g - w / 2, g + w / 2)); E.push(r);
  let d = ''; for (let j = 0; j < E.length; j += 2) { const a = P(E[j], -1), b = P(E[j], 1), cc = P(E[j + 1], 1), e = P(E[j + 1], -1); d += `M${f(a)}L${f(b)}${arc(b, cc)}L${f(e)}${arc(e, a)}Z`; }
  return d;
})();
MK.linear = (s, T) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none"><path d="${bd_LINP}" fill="${bd_IND}"/></svg>`;
// Figma: five stacked coloured dots
const bd_FDOT = [[8.7, 5, '#F24E1E'], [15.3, 5, '#FF7262'], [8.7, 12, '#A259FF'], [15.3, 12, '#1ABCFE'], [8.7, 19, '#0ACF83']];
MK.figma = (s, T) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none">${bd_FDOT.map(([x, y, c]) => `<circle cx="${x}" cy="${y}" r="3.25" fill="${c}"/>`).join('')}</svg>`;

// ---------- Linear status icon, continuous state x: 0 Backlog, 1 Todo, 2 In Progress, 3 In Review, 4 Done
const bd_SN = ['Backlog', 'Todo', 'In Progress', 'In Review', 'Done'];
const bd_SC = ['#8A8A93', '#D2D2D8', '#F2C94C', '#4CB782', '#5E6AD2'];
const bd_PIE = [0, 0, .5, .75, 1];
function bd_stat(x, s, T, o) {
  o = o || {}; const xc = clamp(x, 0, 4); const i = Math.min(3, Math.floor(xc)), f = xc - i;
  const c = bd_hx(bd_SC[i], bd_SC[i + 1], f); const pie = mix(bd_PIE[i], bd_PIE[i + 1], f);
  const solid = clamp(xc); const dsh = mix(1.15, 2, solid); const C = 2 * Math.PI * 2.6;
  const fill = clamp((xc - 3.15) / .6); const chk = o.chk == null ? clamp((xc - 3.5) * 2) : o.chk;
  const ring = solid < .995 ? `stroke-dasharray="${dsh.toFixed(3)} ${(2 - dsh).toFixed(3)}" stroke-dashoffset="${(-T * .35).toFixed(3)}" pathLength="24"` : '';
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none;overflow:visible;transform:rotate(${(o.rot || 0).toFixed(2)}deg) scale(${(o.sc || 1).toFixed(4)})"><circle cx="12" cy="12" r="8.5" fill="none" stroke="${c}" stroke-width="2" ${ring}/>`
    + (pie > .002 ? `<circle cx="12" cy="12" r="2.6" fill="none" stroke="${c}" stroke-width="5.2" stroke-dasharray="${(C * pie).toFixed(3)} ${C.toFixed(3)}" transform="rotate(-90 12 12)"/>` : '')
    + (fill > .001 ? `<circle cx="12" cy="12" r="9.5" fill="${c}" opacity="${fill.toFixed(3)}"/>` : '')
    + (chk > .001 ? `<path d="M8 12.4l2.8 2.8L16.2 9.6" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" pathLength="1" stroke-dasharray="1 1" stroke-dashoffset="${(1 - chk).toFixed(3)}"/>` : '')
    + `</svg>`;
}

// ---------- Cursor: the agent edits three files (lines removed in red collapse, lines added in green spring in),
// then the card expands into a review list with checks and an Accept all button that glows and is pressed.
// code skeleton lines: [indent, [segment widths]]
const bd_GR = ['#424249', '#5C5C64', '#34343A', '#4D4D55'];
const bd_GA = [rgba(bd_G, .62), rgba(bd_G, .38), rgba(bd_G, .8)];
const bd_FILES = [
  { n: 'auth.ts', base: [[0, [20, 44]], [0, [30, 16, 40]], [8, [26, 52]], [8, [18, 30, 22]], [0, [8]]], del: 2, add: [[2, [8, [24, 36, 18]]], [2, [8, [34, 58]]]] },
  { n: 'session.ts', base: [[0, [24, 50]], [0, [14, 34]], [8, [40, 22, 18]], [8, [28, 44]], [0, [8]]], del: 3, add: [[1, [8, [30, 26]]], [3, [8, [20, 48, 14]]]] },
  { n: 'middleware.ts', base: [[0, [18, 26, 30]], [0, [44]], [8, [24, 18, 40]], [8, [36, 20]], [0, [8]]], del: 1, add: [[2, [16, [28, 34]]], [2, [16, [20, 46]]]] }
];
const bd_CLIST = [['auth.ts', 34, 5], ['session.ts', 21, 4], ['middleware.ts', 24, 3], ['auth.test.ts', 8, 0]];
function bd_codeRows(fi, u) {
  const F = bd_FILES[fi]; const rows = [];
  F.base.forEach((b, j) => { rows.push({ sp: b, ty: j === F.del ? 'del' : 'ctx' }); F.add.forEach((a, q) => { if (a[0] === j) rows.push({ sp: a[1], ty: 'add', q }); }); });
  let y = 1.5, s = '';
  for (const r of rows) {
    let hf = 1, sc = 1, o = 1, tint = 0, dx = 0, grow = 1, cO = 0, t0 = 0;
    if (r.ty === 'del') { tint = soft(seg(u, .5, .78)); const p = spring(seg(u, .95, 1.5)); hf = 1 - p; sc = clamp(1 - p); o = 1 - soft(seg(u, 1.0, 1.32)); }
    else if (r.ty === 'add') { t0 = 1.25 + .5 * r.q; const p = spring(seg(u, t0, t0 + .6)); hf = p; sc = clamp(p); o = soft(seg(u, t0, t0 + .28)); dx = (1 - p) * -10; grow = soft(seg(u, t0 + .1, t0 + .62)); tint = 1; cO = win(u, t0 + .08, t0 + .95, .12, .25); }
    if (r.ty !== 'ctx' && (o <= .002 || sc <= .002)) { y += 10 * hf; continue; }
    const ind = r.sp[0], ws = r.sp[1]; const tot = ws.reduce((a, b) => a + b, 0) + 3 * (ws.length - 1); let acc = 0;
    const segs = ws.map((sw, j) => {
      const st0 = acc; acc += sw + 3; const g = clamp((grow * tot - st0) / sw);
      const c = r.ty === 'add' ? bd_GA[j % 3] : r.ty === 'del' ? bd_hx(bd_GR[j % 4], j % 2 ? '#7A3532' : '#A2443F', tint) : bd_GR[j % 4];
      return `<i style="display:block;flex:none;width:${sw}px;height:4px;border-radius:2px;background:${c};transform:scaleX(${g.toFixed(3)});transform-origin:0 50%"></i>`;
    }).join('');
    const bg = r.ty === 'add' ? rgba(bd_G, .12) : r.ty === 'del' ? rgba(bd_RD, (.14 * tint).toFixed(3)) : 'transparent';
    const sign = r.ty === 'add' ? `<span style="position:absolute;left:5px;top:0;line-height:10px;font-size:8.5px;font-weight:600;color:${bd_G};${bd_MONO}">+</span>`
      : r.ty === 'del' ? `<span style="position:absolute;left:5px;top:0;line-height:10px;font-size:8.5px;font-weight:600;color:${bd_RD};opacity:${tint.toFixed(3)};${bd_MONO}">&minus;</span>` : '';
    const caret = cO > .002 ? `<i style="position:absolute;left:0;top:1.5px;width:1.5px;height:7px;border-radius:1px;background:#fff;opacity:${(cO * (.55 + .45 * Math.cos(u * 9))).toFixed(3)};transform:translateX(${(16 + ind + grow * tot + dx).toFixed(2)}px)"></i>` : '';
    s += `<div style="position:absolute;left:0;right:0;top:0;height:10px;transform:translateY(${y.toFixed(3)}px) scaleY(${sc.toFixed(4)});transform-origin:0 0;opacity:${o.toFixed(3)};background:${bg}">${sign}<div style="position:absolute;left:${15 + ind}px;top:3px;display:flex;gap:3px;transform:translateX(${dx.toFixed(3)}px)">${segs}</div>${caret}</div>`;
    y += 10 * hf;
  }
  return s;
}
W.cursor = (T, w) => {
  const P = 12.4, F0 = -.1, FD = 2.8; /* F0 < 0: the first edit lands soon after the wrap, no idle start */ const { l } = st(T, P, 0); const iw = w - 32;
  const e = spring(seg(l, 8.62, 9.5)) - spring(seg(l, 11.4, 12.25)); const h = mix(132, 166, e);
  const fi = l < F0 ? 0 : Math.min(3, Math.floor((l - F0) / FD)); const u = l - F0 - FD * Math.min(fi, 2);
  // ---- code panel
  const codeO = (1 - soft(seg(l, 8.6, 8.95))) + soft(seg(l, 11.45, 12.05));
  let code = '';
  if (codeO > .002) {
    if (l >= 11.4) code = `<div style="position:absolute;inset:0;opacity:${soft(seg(l, 11.45, 12.05)).toFixed(3)};transform:translateY(${((1 - soft(seg(l, 11.45, 12.05))) * 6).toFixed(2)}px)">${bd_codeRows(0, 0)}</div>`;
    else if (fi >= 1 && fi <= 2 && u < .85) { const q = spring(clamp(u / .85)), sy = 66 * q; code = `<div style="position:absolute;inset:0;transform:translateY(${(-sy).toFixed(3)}px)">${bd_codeRows(fi - 1, 99)}</div><div style="position:absolute;inset:0;transform:translateY(${(66 - sy).toFixed(3)}px)">${bd_codeRows(fi, u)}</div>`; }
    else code = `<div style="position:absolute;inset:0;opacity:${(1 - soft(seg(l, 8.6, 8.95))).toFixed(3)}">${bd_codeRows(Math.min(fi, 2), fi >= 3 ? 99 : u)}</div>`;
  }
  // ---- review list (changed files with checks)
  let list = '';
  const lOut = soft(seg(l, 11.2, 11.55));
  if (l > 8.7 && lOut < .999) {
    list = bd_CLIST.map(([n, a, d], j) => {
      const p = soft(seg(l, 8.78 + j * .08, 9.2 + j * .08)); const cp = seg(l, 9.15 + j * .2, 9.55 + j * .2); const cs = spring(cp);
      return `<div class="row" style="position:absolute;left:8px;right:8px;top:0;height:14px;transform:translateY(${(4 + j * 14.4 + (1 - p) * 6).toFixed(2)}px);opacity:${(p * (1 - lOut)).toFixed(3)};gap:5px">${ico('file', '#6A6A72', 10, 2)}<span style="font-size:9.5px;font-weight:500;color:#D6D6DC">${n}</span><span class="sp"></span><span style="font-size:8.5px;font-weight:600;color:${bd_G};${bd_MONO}">+${a}</span>${d ? `<span style="font-size:8.5px;font-weight:600;color:${bd_RD};${bd_MONO}">&minus;${d}</span>` : `<span style="font-size:8px;font-weight:600;color:#8E8E93;background:#1E1E22;border-radius:4px;padding:0 4px;line-height:11px">new</span>`}<div style="width:11px;height:11px;border-radius:50%;background:${bd_hx('#232327', bd_G, clamp(cp * 3))};display:flex;align-items:center;justify-content:center;transform:scale(${(.7 + .3 * cs).toFixed(4)});flex:none">${tick(soft(seg(l, 9.25 + j * .2, 9.6 + j * .2)), '#050506', 8, 3.6)}</div></div>`;
    }).join('');
  }
  // ---- header subtitle: file being edited (shimmering) -> review -> applied
  let sx; if (l < F0 + FD) sx = 0; else if (l < F0 + 2 * FD) sx = soft(clamp((l - F0 - FD) / .45)); else if (l < 8.6) sx = 1 + soft(clamp((l - F0 - 2 * FD) / .45)); else sx = 2 + soft(seg(l, 8.6, 9.05)) + soft(seg(l, 10.8, 11.2));
  const subO = l < 11.35 ? 1 : (1 - soft(seg(l, 11.35, 11.65))) + soft(seg(l, 11.7, 12.15)); if (l >= 11.67) sx = 0;
  const fnm = n => `<span style="${bd_MONO};font-size:10px">${shimmer(n, T, '#6E6E76', '#E8E8EC', .9, 3)}</span>`;
  const sub = xstack([fnm('auth.ts'), fnm('session.ts'), fnm('middleware.ts'), 'Ready for review', `<span style="color:${bd_G}">Changes applied</span>`], sx, 7, 'font-size:10.5px');
  // ---- hero diff counter
  // the counters roll up as edits land, then crossfade back to zero at the reset (no backwards roll through stray digits)
  const bd_rk = soft(seg(l, 11.45, 11.9));
  const bd_xf = (a, b, k) => { const lay = (t, o, y) => o <= .001 ? '' : `<span style="grid-area:1/1;justify-self:end;opacity:${o.toFixed(3)};transform:translateY(${y.toFixed(2)}px)">${t}</span>`; return `<span style="display:inline-grid;vertical-align:top">${lay(a, bd_oOld(k), -k * 6)}${lay(b, bd_oNew(k), (1 - k) * 6)}</span>`; };
  const plus = bd_xf('+' + bd_steps(l, [[0, 0], [1.25, 18], [1.75, 34], [4.05, 46], [4.55, 55], [6.85, 68], [7.35, 79], [9.95, 87]], String, .55), '+' + roll2('0', '0', 9), bd_rk);
  const minus = bd_xf('&minus;' + bd_steps(l, [[0, 0], [.85, 5], [3.65, 9], [6.45, 12]], String, .55), '&minus;' + roll2('0', '0', 9), bd_rk);
  // ---- buttons (expanded)
  const rv = { o: soft(seg(l, 8.78, 9.2)) * (1 - soft(seg(l, 11.12, 11.44))), y: (1 - clamp(e)) * 8 }; /* buttons show only once the card is tall enough to hold them */ const glow = soft(seg(l, 9.95, 10.4)) * (1 - soft(seg(l, 10.8, 11.1))) * (.6 + .4 * Math.sin((l - 9.95) * 6.5));
  const press = bd_bump(seg(l, 10.68, 11.0)); const acc = soft(seg(l, 10.8, 11.15));
  const accBg = bd_hx('#F2F2F4', '#163A1F', acc), accFg = bd_hx('#050506', bd_G, acc);
  const btnLab = xstack([`<span class="row" style="justify-content:center;gap:5px">Accept all<span style="opacity:.45;font-weight:500;font-size:9.5px">&#8984;&#9166;</span></span>`, `<span class="row" style="justify-content:center;gap:4px">${ico('check', bd_G, 11, 3)}Accepted</span>`], acc, 6, 'text-align:center');
  const tileGlow = (l < 8.6 ? 1 : 1 - soft(seg(l, 8.6, 9))) * (.5 + .5 * Math.sin(T * 3.4));
  return {
    h, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px"><div style="border-radius:9.6px;box-shadow:0 0 0 ${(1.2 * tileGlow).toFixed(2)}px rgba(255,255,255,${(.12 * tileGlow).toFixed(3)});flex:none">${tile(MK.cursor(18, T), 'rgba(255,255,255,.1)', 30)}</div><div style="line-height:1.25"><div class="row" style="gap:6px"><span style="font-size:13px;font-weight:600">Agent</span>${tag('4 files', '#A1A1AA', .16)}</div><div style="position:relative;height:14px;width:104px;margin-top:2px;color:#8E8E93;font-weight:500;opacity:${clamp(subO).toFixed(3)}">${sub}</div></div><span class="sp"></span><div style="text-align:right;line-height:1.12"><div style="font-size:22px;font-weight:600;color:${bd_G};letter-spacing:-.6px">${plus}</div><div style="font-size:10.5px;font-weight:600;color:${bd_RD}">${minus}</div></div></div>
<div style="position:absolute;left:16px;top:56px;width:${iw}px;height:62px;border-radius:9px;background:#0F0F11;box-shadow:inset 0 0 0 .6px rgba(255,255,255,.05);overflow:hidden">${code}${list}</div>
<div class="row" style="position:absolute;left:16px;right:16px;top:128px;gap:8px;opacity:${rv.o.toFixed(3)};transform:translateY(${rv.y.toFixed(2)}px)"><div class="row" style="width:70px;height:24px;border-radius:12px;background:#1C1C20;justify-content:center;font-size:11px;font-weight:600;color:#C8C8CE;opacity:${(1 - .55 * acc).toFixed(3)};flex:none">Reject</div><div style="position:relative;flex:1;height:24px;border-radius:12px;background:${accBg};color:${accFg};font-size:11px;font-weight:600;line-height:24px;box-shadow:0 0 ${(4 + 10 * glow).toFixed(2)}px ${(1 + 2 * glow).toFixed(2)}px rgba(255,255,255,${(.3 * glow).toFixed(3)});transform:scale(${(1 - .06 * press).toFixed(4)})">${btnLab}</div></div>
</div>`
  };
};

// ---------- Linear: ENG-2817 walks the workflow. Status icon morphs and spins, label crossfades, activity line,
// priority bars rise, assignee pops in, cycle progress glides with a rolling percent.
const bd_ACT = [['user', 'Created by Ava'], ['user', 'Assigned to Mia'], ['branch', ''], ['branch', ''], ['check', 'PR #412 merged']];
// shared workflow clock: i phase, l seconds in phase, x continuous status, r reset progress (Done -> Backlog), k cycle index
function bd_flow(T, D, o, dur) {
  const ph = phases(T, D, o); const { i, l } = ph; const k = Math.floor((T - o) / ph.P); const D4 = D[4];
  const x = i === 0 ? 0 : (i - 1) + spring(clamp(l / dur));
  const r = i === 4 ? smooth(clamp((l - D4 + .36) / .72)) : i === 0 ? smooth(clamp((l + .36) / .72)) : 1;
  return { i, l, k, x, r: (i === 4 && l > D4 - .36) || (i === 0 && l < .36) ? r : 0 };
}
// status icon with the Done -> Backlog reset as an overlapping scale crossfade
function bd_flowIcon(F, s, T, rotDur) {
  const { i, l, x, r } = F;
  const rot = i === 0 ? 0 : -360 * (1 - spring(clamp(l / rotDur))); const sc = i === 0 ? 1 : 1 + .14 * bd_bump(clamp(l / .6));
  const chk = i === 4 ? soft(seg(l, .3, .7)) : 0;
  if (r <= 0) return bd_stat(x, s, T, { rot, sc, chk });
  const a = smooth(seg(r, .22, .66)), b = smooth(seg(r, .34, .78));
  return `<div style="position:relative;width:${s}px;height:${s}px">` + (a < .999 ? `<div style="position:absolute;inset:0;opacity:${(1 - a).toFixed(3)};transform:scale(${(1 - .4 * a).toFixed(4)})">${bd_stat(4, s, T, { chk: 1 })}</div>` : '')
    + (b > .001 ? `<div style="position:absolute;inset:0;opacity:${b.toFixed(3)};transform:scale(${(.6 + .4 * b).toFixed(4)})">${bd_stat(0, s, T)}</div>` : '') + `</div>`;
}
W.linear = (T, w) => {
  const D = [2.0, 2.0, 2.4, 2.2, 2.6]; const F = bd_flow(T, D, -.6, .85); const { i, l, k, x, r } = F; const iw = w - 32;
  const xl = r > 0 ? 4 + r : x; // label position, index 5 repeats Backlog
  const burst = i === 4 && l > .4 && l < 1.25 ? (() => { const p = seg(l, .4, 1.2); return `<i style="position:absolute;left:0;top:0;width:22px;height:22px;border-radius:50%;box-shadow:0 0 0 1.5px ${bd_IND};opacity:${(.8 * (1 - soft(p))).toFixed(3)};transform:scale(${(1 + .55 * expo(p)).toFixed(4)})"></i>`; })() : '';
  const lab = xstack([...bd_SN, bd_SN[0]].map(s => `<span style="font-size:16px;font-weight:600">${s}</span>`), xl, 9);
  // live counts inside a state: commits land while In Progress, approvals while In Review
  const cm = i < 2 ? roll2('1', '1', 9) : i > 2 ? roll2('3', '3', 9) : bd_steps(l, [[0, 1], [.95, 2], [1.65, 3]], String, .5);
  const ap = i < 3 ? roll2('0', '0', 9) : i > 3 ? roll2('2', '2', 9) : bd_steps(l, [[0, 0], [.8, 1], [1.45, 2]], String, .5);
  const txt = [0, 0, `<span style="${bd_MONO};font-size:9.5px">mia/eng-2817</span>&nbsp;&middot; ${cm} commits`, `PR #412 &middot; ${ap}/2 approvals`];
  const act = xstack([...bd_ACT, bd_ACT[0]].map(([n, s], j) => `<span class="row" style="gap:5px">${ico(n, j === 4 ? bd_INDL : '#6E6E76', 11, 2.2)}<span>${txt[j] || s}</span></span>`), xl, 7);
  // priority (set during Backlog) and assignee (Todo); both clear during the reset
  const out = i === 4 ? smooth(seg(l, D[4] - .55, D[4] - .05)) : 0;
  const prio = [4, 7, 10].map((hh, j) => { const p = (i === 0 ? spring(seg(l, .95 + j * .09, 1.55 + j * .09)) : 1) * (1 - out); return `<i style="display:block;width:3px;height:${hh}px;border-radius:1px;background:${bd_hx('#3A3A40', '#C9C9D0', p)};transform:scaleY(${mix(2 / hh, 1, clamp(p, 0, 1.2)).toFixed(4)});transform-origin:50% 100%"></i>`; }).join('');
  const as = (i === 0 ? 0 : i === 1 ? spring(seg(l, .3, .95)) : 1) * (1 - out);
  const avatar = `<div style="position:relative;width:20px;height:20px;flex:none"><div style="position:absolute;inset:0;border-radius:50%;border:1.3px dashed #4A4A52;opacity:${clamp(1 - as * 2).toFixed(3)}"></div><div style="position:absolute;inset:0;opacity:${clamp(as * 2).toFixed(3)};transform:scale(${(.4 + .6 * clamp(as, 0, 1.1)).toFixed(4)})">${av('M', '#C9B8FF', '#6C7BFF', 20)}</div></div>`;
  // cycle progress: one step per status change across the clip, monotonic
  const n = k * 5 + i; const pct = 60 + n; const lp = n === 0 ? 9 : l;
  const pctS = roll2(String(n === 0 ? pct : pct - 1), String(pct), lp, .6);
  const f = mix((n === 0 ? pct : pct - 1) / 100, pct / 100, spring(clamp(lp / .9)));
  const track = `<div style="position:relative;width:${iw}px;height:4px;border-radius:2px;background:#1F1F23;overflow:hidden"><div style="position:absolute;inset:0;border-radius:2px;background:${rgba('#F2C94C', .45)};transform:translateX(${((f + .11 - 1) * iw).toFixed(3)}px)"></div><div style="position:absolute;inset:0;border-radius:2px;background:${bd_IND};transform:translateX(${((f - 1) * iw).toFixed(3)}px)"></div></div>`;
  return {
    h: 126, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:6px;height:20px">${MK.linear(14, T)}<span class="m" style="margin-left:1px">ENG-2817</span><span style="font-size:11.5px;font-weight:600">Onboarding v2</span><span class="sp"></span><div class="row" style="gap:1.5px;align-items:flex-end;height:10px;margin-right:4px">${prio}</div>${avatar}</div>
<div class="row" style="position:absolute;left:16px;right:16px;top:44px;gap:9px;height:24px"><div style="position:relative;width:22px;height:22px;flex:none">${burst}${bd_flowIcon(F, 22, T, 1.0)}</div><div style="position:relative;flex:1;height:20px;line-height:20px">${lab}</div></div>
<div style="position:absolute;left:47px;right:16px;top:71px;height:14px;font-size:10px;font-weight:500;color:#8E8E93;line-height:14px">${act}</div>
<div class="row m" style="position:absolute;left:16px;right:16px;top:93px;font-size:9.5px"><span>Cycle 24 &middot; <b style="color:#fff;font-weight:600">${pctS}%</b></span><span class="sp"></span><span>4 days left</span></div>
<div style="position:absolute;left:16px;top:108px">${track}</div>
</div>`
  };
};

// ---------- Figma: live multiplayer on a small canvas. Mia drags the frame's corner handle (size badge rolls),
// Ava drops a sticky note, Leo wanders; three cursors with name labels glide on Lissajous paths.
const bd_FR = [[92, 40], [128, 48], [110, 44]], bd_FLB = [['1024', '640'], ['1440', '800'], ['1280', '720']], bd_FDR = [1.0, 5.6, 8.2];
const bd_PPL = [['Mia', bd_FB, '#5CC0FF'], ['Leo', '#0ACF83', '#6BE6B4'], ['Ava', '#FF7262', '#FFA899']];
function bd_fcur(x, y, c, name, rs) {
  rs = rs || 0;
  const arrow = `<svg width="11" height="11" viewBox="0 0 24 24" style="position:absolute;left:-1.3px;top:-1px;overflow:visible;opacity:${(1 - rs).toFixed(3)}"><path d="M3 2l16.5 7.6-7 2.2-2.3 7z" fill="${c}" stroke="#fff" stroke-width="1.8" stroke-linejoin="round"/></svg>`;
  const rsz = rs > .002 ? `<svg width="12" height="12" viewBox="0 0 24 24" style="position:absolute;left:-6px;top:-6px;overflow:visible;opacity:${rs.toFixed(3)}"><path d="M6 6l12 12M6 6h6M6 6v6M18 18h-6M18 18v-6" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none"/><path d="M6 6l12 12M6 6h6M6 6v6M18 18h-6M18 18v-6" stroke="#111" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>` : '';
  return `<div style="position:absolute;left:0;top:0;transform:translate(${x.toFixed(3)}px,${y.toFixed(3)}px)">${arrow}${rsz}<div style="position:absolute;left:7px;top:10px;height:11px;line-height:11px;padding:0 4px;border-radius:2px 5px 5px 5px;background:${c};font-size:7.5px;font-weight:600;color:#fff">${name}</div></div>`;
}
W.figma = (T, w) => {
  const P = 10.4; const { l } = st(T, P, 0); const cw = w - 32, ch = 86; const X0 = 12, Y0 = 14;
  // frame size: three drags cycle through the sizes
  let fw = bd_FR[0][0], fh = bd_FR[0][1], dj = -1, dl = 0;
  for (let j = 0; j < 3; j++) { if (l >= bd_FDR[j]) { const a = bd_FR[j], b = bd_FR[(j + 1) % 3]; const p = spring(seg(l, bd_FDR[j], bd_FDR[j] + 1.0)); fw = mix(a[0], b[0], p); fh = mix(a[1], b[1], p); dj = j; dl = l - bd_FDR[j]; } }
  // cursors: free Lissajous paths, blended onto their task while they act
  const liss = [[40 + 16 * Math.sin(T * .93 + .4), 61 + 2 * Math.sin(T * 1.41 + 1.9)], [42 + 20 * Math.sin(T * .61 + 2.2), 33 + 4 * Math.sin(T * .97 + .3)], [88 + 26 * Math.sin(T * .74 + 4.1), 10 + 6 * Math.sin(T * 1.18 + .6)]];
  let wM = 0, sM = 0; for (const d of bd_FDR) { wM = Math.max(wM, win(l, d - .6, d + 1.9, .6, .7)); sM = Math.max(sM, win(l, d - .25, d + 1.4, .3, .35)); }
  const mia = [mix(liss[0][0], X0 + fw + .5, wM), mix(liss[0][1], Y0 + fh + .5, wM)];
  const SX = 146, SY = 10; const wA = win(l, 3.0, 5.0, .6, .6), sA = win(l, 3.5, 4.9, .3, .4);
  const ava = [mix(liss[2][0], SX - 2, wA), mix(liss[2][1], SY + 31, wA)];
  const leo = liss[1];
  const rs = smooth(clamp((wM - .5) * 2));
  // sticky note, dropped by Ava
  const sIn = spring(seg(l, 3.5, 4.1)), sOut = soft(seg(l, 9.75, 10.2)); const sO = soft(seg(l, 3.5, 3.7)) * (1 - sOut);
  const sticky = sO > .002 ? `<div style="position:absolute;left:${SX}px;top:${SY}px;width:36px;height:30px;border-radius:2px;background:#FFD45C;box-shadow:0 2px 6px rgba(0,0,0,.45);transform-origin:0 100%;transform:rotate(${mix(-16, -4, sIn).toFixed(2)}deg) scale(${(sIn * (1 - .25 * sOut)).toFixed(4)});opacity:${sO.toFixed(3)};padding:4px 5px;font-size:7.5px;font-weight:700;color:#3A2C00;line-height:9px;white-space:pre">${typeIn('Bigger', l - 3.9, 16, .1)}<br>${typeIn('CTA?', l - 4.3, 16, .1)}</div>` : '';
  // size badge while dragging
  let badge = '';
  if (dj >= 0) { const bO = win(dl, .02, 1.35, .2, .35); if (bO > .002) { const a = bd_FLB[dj], b = bd_FLB[(dj + 1) % 3]; badge = `<div style="position:absolute;left:0;top:0;transform:translate(${(X0 + fw / 2).toFixed(3)}px,${(Y0 + fh + 4).toFixed(3)}px) translateX(-50%);opacity:${bO.toFixed(3)};height:11px;line-height:11px;padding:0 4px;border-radius:3px;background:${bd_FB};font-size:7px;font-weight:600;color:#fff">${roll2(a[0], b[0], dl - .05, .7)} &times; ${roll2(a[1], b[1], dl - .05, .7)}</div>`; } }
  // frame (svg: fractional geometry glides without pixel snapping)
  const hd = (x, y) => `<rect x="${(x - 2).toFixed(2)}" y="${(y - 2).toFixed(2)}" width="4" height="4" fill="#fff" stroke="${bd_FB}" stroke-width="1"/>`;
  const svg = `<svg width="${cw}" height="${ch}" style="position:absolute;left:0;top:0;overflow:visible"><defs><linearGradient id="bdFigImg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#A259FF"/><stop offset="1" stop-color="#FF7262"/></linearGradient></defs>
<g transform="translate(${X0} ${Y0})"><rect width="${fw.toFixed(3)}" height="${fh.toFixed(3)}" fill="#0E0E10"/>
<circle cx="6" cy="6" r="2" fill="#5A5A62"/><rect x="${(fw - 26).toFixed(3)}" y="5" width="6" height="2" rx="1" fill="#3A3A40"/><rect x="${(fw - 17).toFixed(3)}" y="5" width="6" height="2" rx="1" fill="#3A3A40"/><rect x="${(fw - 8).toFixed(3)}" y="5" width="3" height="2" rx="1" fill="#3A3A40"/>
<rect x="5" y="13" width="${(fw * .44).toFixed(3)}" height="4" rx="1.5" fill="#E9E9EC"/><rect x="5" y="19.5" width="${(fw * .3).toFixed(3)}" height="4" rx="1.5" fill="#E9E9EC"/><rect x="5" y="27" width="${(fw * .38).toFixed(3)}" height="2.4" rx="1.2" fill="#4A4A52"/>
<rect x="5" y="${(fh - 10.5).toFixed(3)}" width="20" height="6.5" rx="3.25" fill="${bd_FB}"/>
<rect x="${(fw * .58).toFixed(3)}" y="12" width="${(fw * .42 - 5).toFixed(3)}" height="${(fh - 17).toFixed(3)}" rx="3" fill="url(#bdFigImg)" opacity=".9"/>
<rect x="0" y="0" width="${fw.toFixed(3)}" height="${fh.toFixed(3)}" fill="none" stroke="${bd_FB}" stroke-width="1"/>${hd(0, 0)}${hd(fw, 0)}${hd(0, fh)}${hd(fw, fh)}</g></svg>`;
  const curs = bd_fcur(leo[0], leo[1], bd_PPL[1][1], 'Leo') + bd_fcur(ava[0], ava[1], bd_PPL[2][1], 'Ava') + bd_fcur(mia[0], mia[1], bd_PPL[0][1], 'Mia', rs);
  // header: avatar stack, the active collaborator lifts with a ring in their color
  const actv = [sM, 0, sA];
  const stack = bd_PPL.map(([n, c, c2], j) => { const a = smooth(actv[j]); return `<div style="margin-left:${j ? -6 : 0}px;border-radius:50%;box-shadow:0 0 0 1.6px #050506${a > .01 ? `,0 0 0 ${(1.6 + 1.4 * a).toFixed(2)}px ${rgba(c, (.9 * a).toFixed(3))}` : ''};transform:translateY(${(-2 * a).toFixed(3)}px);position:relative;z-index:${3 - j}">${av(n[0], c2, c, 20, '#050506')}</div>`; }).join('');
  const subA = `<span class="row" style="gap:5px"><i style="width:6px;height:6px;border-radius:50%;background:#0ACF83;opacity:${(.55 + .45 * Math.abs(Math.cos(T * 2))).toFixed(3)}"></i>3 editing</span>`;
  const lay = (s, o, y) => o <= .002 ? '' : `<div style="position:absolute;left:0;top:0;opacity:${o.toFixed(3)};transform:translateY(${y.toFixed(2)}px)">${s}</div>`;
  const vM = smooth(sM), vA = smooth(sA);
  const sub = lay(subA, Math.min(bd_oOld(vM), bd_oOld(vA)), -6 * Math.max(vM, vA)) + lay(`<span style="color:#4DB5FF">Mia</span> resizing Hero`, bd_oNew(vM), 6 * (1 - vM)) + lay(`<span style="color:#FF8A7D">Ava</span> added a sticky`, bd_oNew(vA), 6 * (1 - vA));
  return {
    h: 154, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${tile(MK.figma(19, T), 'rgba(255,255,255,.08)', 30)}<div style="line-height:1.25"><div style="font-size:13px;font-weight:600">Landing v3</div><div class="m" style="position:relative;height:14px;width:100px">${sub}</div></div><span class="sp"></span><div class="row">${stack}</div></div>
<div style="position:absolute;left:16px;top:54px;width:${cw}px;height:${ch}px;border-radius:10px;background:#1E1E1E radial-gradient(circle,#2C2C2C .7px,transparent 1.1px) 0 0/8px 8px;overflow:hidden">
<div style="position:absolute;left:${X0}px;top:${Y0 - 10}px;font-size:7px;font-weight:600;color:${bd_FB}">Hero</div>${svg}${badge}${sticky}${curs}</div>
</div>`
  };
};

// ---------- pills
W.p_cursor = T => {
  const S = st2(T, 2.3, .6); const v = k => 118 + Math.floor(k * 7.3 + 3 * Math.sin(k * 1.7));
  const pu = S.l < .6 ? bd_bump(clamp(S.l / .55)) : 0;
  return { h: 50, html: pill(`<span style="display:inline-flex;transform:scale(${(1 + .14 * pu).toFixed(4)}) rotate(${(-8 * pu).toFixed(2)}deg)">${MK.cursor(17, T)}</span>`, bd_G, '+' + roll2(String(v(S.k - 1)), String(v(S.k)), S.l, .55)) };
};
W.p_linear = T => {
  const D = [1.0, 1.1, 1.3, 1.2, 1.4]; const F = bd_flow(T, D, -.5, .7); const { i, l, k } = F;
  const val = i === 4 ? roll2(String(6 + k), String(7 + k), l - .2, .6) : roll2(String(6 + k), String(6 + k), 9);
  return { h: 50, html: pill(bd_flowIcon(F, 18, T, .85), bd_INDL, val + '<span style="font-size:11px;margin-left:1px;opacity:.75">/12</span>') };
};
