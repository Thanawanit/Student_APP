// widgets/google.js: Gemini image generation, Perplexity answer, NotebookLM Audio Overview, and the Gemini / Perplexity pills.
// Every top-level name here starts with gg_.
const gg_B = '#4796E3', gg_V = '#9177C7', gg_R = '#D96570', gg_TL = '#20B8CD', gg_AM = '#F2B45A';
const gg_GRAD = `linear-gradient(90deg,${gg_B},${gg_V} 55%,${gg_R})`;
const gg_hx = (a, b, p) => '#' + [1, 3, 5].map(i => Math.round(mix(parseInt(a.substr(i, 2), 16), parseInt(b.substr(i, 2), 16), clamp(p))).toString(16).padStart(2, '0')).join('');
const gg_h = (i, s = 0) => { const x = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return x - Math.floor(x); };
const gg_f = (v, d = 3) => (+v).toFixed(d);
// Gemini gradient sampled at u (0 blue, .55 violet, 1 rose), and a gradient-filled glyph run (background-clip on the glyph's own box)
const gg_gc = u => u < .55 ? gg_hx(gg_B, gg_V, u / .55) : gg_hx(gg_V, gg_R, (u - .55) / .45);
const gg_gt = (a, b) => `background:linear-gradient(90deg,${gg_gc(a)},${gg_gc(b)});-webkit-background-clip:text;background-clip:text;color:transparent`;
// typed text: only typed characters are rendered so a caret can follow; each fades and rises in
const gg_type = (s, l, cps) => { if (l > s.length / cps + .2) return s; const n = Math.max(0, Math.min(s.length, Math.ceil(l * cps))); return typeIn(s.slice(0, n), l, cps, .14); };
// stepped value with a roll at each key: K = [[time, value], ...]
function gg_steps(l, K, fmt, dur = .5) {
  let i = 0; while (i < K.length - 1 && l >= K[i + 1][0]) i++;
  if (i === 0) return roll2(fmt(K[0][1]), fmt(K[0][1]), 9, dur);
  return roll2(fmt(K[i - 1][1]), fmt(K[i][1]), l - K[i][0], dur);
}
// mechanical odometer for a continuous value v >= 0: every reel only ever rolls forward, higher reels carry
// during the last unit of the reel below, leading digits grow in (width and opacity) as the number gains a digit
// grad: paint each reel with its slice of the Gemini gradient by place value (hundreds blue ... units violet-rose)
const gg_REEL = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map(d => `<b>${d}</b>`).join('');
const gg_GU = [[.45, .78], [.05, .45], [0, .18]];
const gg_REELG = gg_GU.map(([a, b]) => [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map(d => `<b style="${gg_gt(a, b)}">${d}</b>`).join(''));
function gg_odo(v, nd = 3, grad = false) {
  v = Math.max(0, v); let s = '';
  for (let p = nd - 1; p >= 0; p--) {
    const q = Math.pow(10, p), base = Math.floor(v / q), pos = base + clamp(v - base * q - (q - 1));
    const vis = p === 0 ? 1 : clamp(pos); if (vis <= .001) continue;
    s += `<span class="rc" style="${vis < 1 ? `max-width:${gg_f(vis * .62)}em;opacity:${gg_f(vis)};` : ''}"><span style="display:block;transform:translateY(${gg_f(-md(pos, 10) * 1.2)}em)">${grad ? gg_REELG[p] : gg_REEL}</span></span>`;
  }
  return `<span class="rl">${s}</span>`;
}
// stepped value that springs between keys K = [[time, value], ...], as a continuous number for gg_odo
function gg_kv(l, K, dur = .5) { let i = 0; while (i < K.length - 1 && l >= K[i + 1][0]) i++; return i === 0 ? K[0][1] : mix(K[i - 1][1], K[i][1], soft(clamp((l - K[i][0]) / dur))); }
// progress fill that keeps its gradient fixed to the track (wipe made of two opposite translates, never width)
const gg_wipe = (f, w, bg, h = 4, track = '#1F1F23') => `<div style="position:relative;width:${w}px;height:${h}px;border-radius:${h / 2}px;background:${track};overflow:hidden;flex:none"><div style="position:absolute;inset:0;border-radius:${h / 2}px;overflow:hidden;transform:translateX(${gg_f((clamp(f) - 1) * w)}px)"><div style="position:absolute;inset:0;background:${bg};transform:translateX(${gg_f((1 - clamp(f)) * w)}px)"></div></div></div>`;
// caret that fades out instead of vanishing
const gg_car = (T, c, o) => o <= .001 ? '' : `<span style="opacity:${gg_f(o)}">${caret(T, c, 12)}</span>`;
// reveal for content that needs the card to have grown first: hidden until e reaches a, then fades and rises in
const gg_rv = (e, a) => ({ o: clamp((e - a) / .28), y: (1 - Math.min(1, e)) * 8 });
// ascending rolling value over a cycle; the last .8 s cross-fades back to the first value (never rolls backwards)
function gg_cyc(T, P, o, vals, dt, fmt, dur = .55, grad = false) {
  const l = md(T - o, P);
  const cur = gg_odo(gg_kv(l, vals.map((v, j) => [j * dt, v]), dur), 3, grad);
  const fo = soft(seg(l, P - .8, P)); if (fo <= 0) return cur;
  return `<span style="position:relative;display:inline-block"><span style="display:inline-block;opacity:${gg_f(clamp(1 - fo * 2))};transform:translateY(${gg_f(-fo * 8)}px)">${cur}</span><span style="position:absolute;right:0;top:0;opacity:${gg_f(clamp(fo * 2 - 1))};transform:translateY(${gg_f((1 - fo) * 8)}px)">${gg_odo(vals[0], 3, grad)}</span></span>`;
}

// ---------- brand marks (own simple glyphs)
// Gemini: a four-point sparkle, blue to violet to rose. o.rot extra rotation (deg), o.pop extra scale, o.mini twinkling companion
const gg_SPK = 'M12 1.4C12.35 7.9 16.1 11.65 22.6 12C16.1 12.35 12.35 16.1 12 22.6C11.65 16.1 7.9 12.35 1.4 12C7.9 11.65 11.65 7.9 12 1.4Z';
MK.gemini = (s = 16, T = 0, o = {}) => {
  const rot = (o.rot || 0) + Math.sin(T * .85) * 9, sc = (1 + .05 * Math.sin(T * 2.3)) * (o.pop || 1);
  const mi = o.mini === false ? 0 : Math.pow(Math.max(0, Math.sin(T * 1.9 + .6)), 3);
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none;overflow:visible"><defs><linearGradient id="gg_gm" gradientUnits="userSpaceOnUse" x1="3" y1="21" x2="21" y2="3"><stop offset="0" stop-color="${gg_B}"/><stop offset=".55" stop-color="${gg_V}"/><stop offset="1" stop-color="${gg_R}"/></linearGradient></defs><path d="${gg_SPK}" fill="url(#gg_gm)" transform="rotate(${gg_f(rot, 2)} 12 12) translate(12 12) scale(${gg_f(sc)}) translate(-12 -12)"/>${mi > .01 ? `<path d="${gg_SPK}" fill="${gg_R}" opacity="${gg_f(mi)}" transform="translate(20.2 3.4) scale(${gg_f(.27 * (.4 + .6 * mi))}) translate(-12 -12)"/>` : ''}</svg>`;
};
// Perplexity: an asterisk crossed by an open band (geometric, own drawing)
// rot: optional rotation in degrees (the glyph is symmetric under a half turn, so 180 deg spins land on the same pose)
MK.perplexity = (s = 16, T = 0, c = gg_TL, sw = 1.9, rot = 0) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" style="flex:none;${rot ? `transform:rotate(${gg_f(rot, 2)}deg)` : ''}"><path d="M12 2.8v18.4M5.2 4.4l6.8 6.1 6.8-6.1M5.2 19.6l6.8-6.1 6.8 6.1"/><rect x="3.6" y="8.9" width="16.8" height="6.2" rx="1.4"/></svg>`;
// NotebookLM: nested arches over a base (own drawing)
MK.notebooklm = (s = 16, T = 0, c = gg_AM, sw = 2) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${sw}" stroke-linecap="round" style="flex:none"><path d="M3.5 18.5V13a8.5 8.5 0 0117 0v5.5"/><path d="M8 18.5V13.5a4 4 0 018 0v5"/><circle cx="12" cy="17.6" r="1.5" fill="${c}" stroke="none"/></svg>`;

// ---------- gemini_image: Gemini creating "a glass lighthouse at dusk"
// the painted thumbnail (60 x 60): dusk sky, sun on the horizon, sea glints, a glass lighthouse with a sweeping beam
function gg_scene(T) {
  const st = [[7, 6, .55], [14, 11, .4], [29, 4.5, .6], [51, 7, .5], [37, 12, .35], [4, 18, .35], [57, 15, .4], [24, 9, .3]]
    .map(([x, y, r], i) => `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" opacity="${gg_f(.3 + .55 * (.5 + .5 * Math.sin(T * 2.1 + i * 1.9)), 2)}"/>`).join('');
  const ref = [0, 1, 2, 3, 4].map(i => { const y = 40.4 + i * 3.3, wv = 6.4 - i * 1.05, x = 43 + Math.sin(T * 1.7 + i * 1.3) * 1.1; return `<rect x="${gg_f(x - wv, 2)}" y="${y}" width="${gg_f(wv * 2, 2)}" height="1.1" rx=".55" fill="#FFD9B5" opacity="${gg_f(.8 - i * .13, 2)}"/>`; }).join('');
  const bm = -6 + Math.sin(T * .8) * 14;
  return `<svg width="60" height="60" viewBox="0 0 60 60" style="display:block"><defs>
<linearGradient id="gg_sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#171B4D"/><stop offset=".42" stop-color="#5546A8"/><stop offset=".76" stop-color="#D47399"/><stop offset="1" stop-color="#F8B98C"/></linearGradient>
<linearGradient id="gg_se" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7158A8"/><stop offset=".3" stop-color="#2E2B72"/><stop offset="1" stop-color="#0F1236"/></linearGradient>
<radialGradient id="gg_su"><stop offset="0" stop-color="#FFF4D8"/><stop offset=".22" stop-color="#FFD29C" stop-opacity=".95"/><stop offset="1" stop-color="#FF9B8A" stop-opacity="0"/></radialGradient>
<radialGradient id="gg_lp"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".22" stop-color="#E6F2FF" stop-opacity=".9"/><stop offset="1" stop-color="#9CC8FF" stop-opacity="0"/></radialGradient>
<linearGradient id="gg_bm" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#F3F8FF" stop-opacity=".7"/><stop offset="1" stop-color="#F3F8FF" stop-opacity="0"/></linearGradient>
<linearGradient id="gg_gl" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#EEF5FF" stop-opacity=".95"/><stop offset=".45" stop-color="#A9BCF2" stop-opacity=".55"/><stop offset="1" stop-color="#5B57B0" stop-opacity=".9"/></linearGradient></defs>
<rect width="60" height="39" fill="url(#gg_sk)"/>${st}<circle cx="43" cy="37" r="17" fill="url(#gg_su)"/><circle cx="43" cy="37.6" r="5" fill="#FFEBC9"/>
<rect y="38.6" width="60" height="21.4" fill="url(#gg_se)"/>${ref}
<g transform="rotate(${gg_f(bm, 2)} 20 17.3)"><path d="M20 16.6L68 8.5V26L20 18z" fill="url(#gg_bm)"/></g>
<path d="M0 60V47.5c5-3.2 11-4.4 17-3.8 5 .5 9.2 2.6 12.2 5.6 2.2 2.2 3.2 5 3.6 10.7z" fill="#0B0C26"/>
<path d="M16.9 45.2L18.5 20.6h3L23.1 45.2z" fill="url(#gg_gl)"/><path d="M17.4 38.2h5.2M17.8 31.2h4.4M18.2 25.4h3.6" stroke="#141542" stroke-opacity=".45" stroke-width="1"/>
<rect x="17.3" y="19.4" width="5.4" height="1.5" rx=".5" fill="#17184A"/><rect x="18.4" y="14.9" width="3.2" height="4.6" rx=".6" fill="#FFF7E8"/><path d="M17.7 15.3L20 11.6l2.3 3.7z" fill="#17184A"/>
<circle cx="20" cy="17.2" r="9.5" fill="url(#gg_lp)" opacity="${gg_f(.75 + .25 * Math.sin(T * 3.1), 2)}"/></svg>`;
}
// tile reveal order: a deterministic shuffle of the 6 x 6 grid (hash of the tile index), one per cycle
const gg_RK = [1, 2, 3].map(s => { const idx = [...Array(36)].map((_, i) => i).sort((a, b) => gg_h(a, s) - gg_h(b, s)); const r = []; idx.forEach((t, j) => r[t] = j); return r; });
const gg_PCT = [0, 6, 13, 21, 34, 47, 58, 64, 75, 88, 100];
W.gemini_image = (T, w) => {
  // P 11.4: type the prompt (0.2..1.5), generate (1.8..6.7), Done with a slow push-in, soft reset (10.1..11.1).
  // The status block never empties: while the prompt is typed it idles on a dim 0% and an empty bar.
  const P = 11.4, l = md(T, P), k = Math.floor(T / P), RK = gg_RK[md(k, 3)];
  const PR = 'a glass lighthouse at dusk', cps = 20, t0 = .2;
  const out = soft(seg(l, 10.1, 10.9));                  // prompt back to the placeholder
  const rs = soft(seg(l, 10.1, 10.7));                   // status: Done -> idle
  const gen = soft(seg(l, 1.65, 2.05));                  // status: idle -> live
  const g0 = 1.8, dt = .125, fd = .5;                    // tile reveal
  const rv = clamp((l - g0) / (35 * dt + fd));
  const dn = soft(seg(l, 6.6, 7.2)), dk = spring(clamp((l - 6.65) / .8));
  const push = io(seg(l, 6.65, 10.3));
  // percent keys, glide value for the bar (both back at 0 once hidden behind Done)
  const K = gg_PCT.map((v, j) => [j === 0 ? 0 : g0 + j * .45, v]);
  const fv = l < 9 ? kf(l, K.map(([t, v]) => [Math.max(t, g0), v / 100]), p => p) : 0;
  const pv = l < 9 ? gg_kv(l, K, .4) : 0;
  // covers: dark tiles with a travelling shimmer (also while idle); each fades out (with a soft glint) in shuffled order, then back in on reset
  const sh = l < 9 ? 1 - dn : soft(seg(l, 10.4, 11));
  const pos = md(l * 110 * 6 / P, 110) - 25;             // whole number of sweeps per cycle, so the wrap is seamless
  let cov = '';
  for (let i = 0; i < 36; i++) {
    const cx = (i % 6) * 10, cy = Math.floor(i / 6) * 10;
    const p = clamp((l - g0 - RK[i] * dt) / fd);
    const back = soft(clamp((l - 10.1 - RK[i] * .016) / .45));
    const o = Math.max(1 - smooth(p), back);
    if (o < .01) { cov += '<i></i>'; continue; }
    const band = Math.exp(-Math.pow((cx + cy) * .6 - pos, 2) / 220) * sh;
    const glint = Math.sin(p * Math.PI) * .55 * (1 - back);
    const c = gg_hx(gg_hx('#141418', '#2B2650', band), '#D9CCFF', glint);
    const sc = 1 - .12 * smooth(p) * (1 - back);
    cov += `<i style="width:10.6px;height:10.6px;background:${c};opacity:${gg_f(o)}${sc < .999 ? `;transform:scale(${gg_f(sc)})` : ''}"></i>`;
  }
  const blur = 3.2 * Math.pow(1 - rv, 1.4);
  const typed = gg_type(PR, l - t0, cps);
  const ph = clamp((t0 - l) / .15) + clamp(out * 2 - 1), qo = clamp(1 - out * 2);   // placeholder "Describe an image" / typed prompt (no blank gap)
  const carO = l > 9 ? soft(seg(l, 10.85, 11.2)) : 1 - soft(seg(l, 1.55, 1.85));
  const idle = '<span style="color:#6E6E76">New image</span>';
  const lab = [idle, shimmer('Generating', T, '#6E6E76', '#FFFFFF'), shimmer('Adding details', T, '#6E6E76', '#FFFFFF'), 'Created', idle];
  const lx = kf(l, [[0, 0], [1.65, 0], [2.1, 1], [3.95, 1], [4.45, 2], [6.55, 2], [7.05, 3], [10.1, 3], [10.6, 4], [P, 4]]);
  // hero: dim idle 0% -> live % -> Done -> back to dim 0% (one driver per handover, so it never blanks or doubles)
  const pctO = l < 9 ? mix(.32, 1, gen) * clamp(1 - dn * 2) : .32 * clamp(rs * 2 - 1);
  const pctY = l < 9 ? -dn * 8 : (1 - rs) * 8;
  const dnO = l < 9 ? clamp(dn * 2 - 1) : clamp(1 - rs * 2), dnY = l < 9 ? (1 - dn) * 8 : -rs * 8;
  const barO = l < 9 ? clamp(1 - dn * 2) : clamp(rs * 2 - 1);
  const iconO = l > 9 ? soft(seg(l, 10.7, 11.1)) : 1 - soft(seg(l, 1.6, 1.95));
  const mk = MK.gemini(16, T, { rot: 540 * ease3(seg(l, 1.7, 6.7)), pop: 1 + .22 * Math.sin(Math.PI * clamp((l - 6.6) / .7)) });
  return { h: 114, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:8px;height:16px">${mk}<div style="position:relative;flex:1;height:16px;font-size:12px;font-weight:600;line-height:16px">
<div style="position:absolute;left:3px;top:0;color:#5A5A62;font-weight:500;opacity:${gg_f(clamp(ph))}">Describe an image</div>
<div style="position:absolute;left:0;top:0;opacity:${gg_f(qo)}">${typed}${gg_car(T, '#FFFFFF', carO)}</div></div></div>
<div style="position:absolute;left:16px;top:40px;width:60px;height:60px;border-radius:13px;overflow:hidden;background:#141418">
<div style="position:absolute;inset:0;transform-origin:34% 40%;transform:scale(${gg_f(1 + .12 * push, 4)});filter:blur(${gg_f(blur, 2)}px)">${gg_scene(T)}</div><div style="position:absolute;inset:0;display:grid;grid-template-columns:repeat(6,10px);grid-template-rows:repeat(6,10px)">${cov}</div>
<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${gg_f(iconO)}">${ico('img', '#3A3A42', 20, 1.8)}</div>
<i style="position:absolute;inset:0;border-radius:13px;box-shadow:inset 0 0 0 .6px rgba(255,255,255,.12)"></i></div>
<div style="position:absolute;left:88px;right:16px;top:40px;height:60px">
 <div class="m" style="position:relative;height:13px;line-height:13px">${xstack(lab, lx, 7)}</div>
 <div style="position:absolute;left:0;right:0;top:15px;height:28px;font-size:22px;font-weight:600;letter-spacing:-.6px;line-height:28px">
  ${pctO > .001 ? `<div style="position:absolute;left:0;top:0;opacity:${gg_f(pctO)};transform:translateY(${gg_f(pctY)}px)">${gg_odo(pv, 3, true)}<span style="font-size:14px;margin-left:1px;${gg_gt(.78, 1)}">%</span></div>` : ''}
  ${dnO > .001 ? `<div class="row" style="position:absolute;left:0;top:0;height:28px;gap:7px;opacity:${gg_f(dnO)};transform:translateY(${gg_f(dnY)}px)"><div style="width:20px;height:20px;border-radius:50%;background:${gg_GRAD};display:flex;align-items:center;justify-content:center;transform:scale(${gg_f(.6 + .4 * dk)})">${tick(clamp((l - 6.8) / .45), '#08080C', 12, 3.4)}</div><span>Done</span></div>` : ''}
 </div>
 ${barO > .001 ? `<div style="position:absolute;left:0;top:49px;opacity:${gg_f(barO)}">${gg_wipe(fv, 132, gg_GRAD, 4)}</div>` : ''}
 ${dnO > .001 ? `<div class="m" style="position:absolute;left:0;top:45px;font-size:9.5px;opacity:${gg_f(dnO)};transform:translateY(${gg_f(dnY * .6)}px)">1024 × 1024 · Saved</div>` : ''}
</div></div>` };
};

// ---------- perplexity: query, Pro Search steps, citations, a streamed answer
const gg_PQ = ['how solid-state batteries work', 'why do cats knead blankets', 'best ramen spots in Lisbon'];
// font features without tabular figures for copy with a hyphen (Inter's tabular hyphen is too wide)
const gg_PROP = "font-feature-settings:'cv11','ss01'";
const gg_FAV = ['#F2F2F4', '#FF8A3D', '#5B8CFF', '#3DDC97'];
// answer skeleton: per line [width, words as [x, w]], line start time, duration
const gg_AL = [[190, [[0, 26], [30, 40], [74, 18], [96, 34], [134, 24], [162, 28]], 5.35, 1.15, 1],
               [176, [[0, 34], [38, 22], [64, 44], [112, 26], [142, 34]], 6.5, 1.05, 2],
               [118, [[0, 30], [34, 40], [78, 26], [108, 10]], 7.55, .7, 3]];
const gg_ring = (s, c, tr, rot, frac) => { const r = (s - 2.4) / 2, C = 2 * Math.PI * r; return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" style="position:absolute;inset:0;transform:rotate(${gg_f(rot, 2)}deg)"><circle cx="${s / 2}" cy="${s / 2}" r="${r}" stroke="${tr}" stroke-width="1.6" fill="none"/>${frac > 0 ? `<circle cx="${s / 2}" cy="${s / 2}" r="${r}" stroke="${c}" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-dasharray="${gg_f(C * frac)} ${gg_f(C)}"/>` : ''}</svg>`; };
W.perplexity = (T, w) => {
  const A = gg_TL, P = 12, l = md(T, P), k = Math.floor(T / P), Q = gg_PQ[md(k, 3)];
  const out = soft(seg(l, 10.8, 11.6)), vis = 1 - out;
  // two springy expands: the sources row when the search starts, the answer when it starts streaming
  const e1 = spring(clamp((l - 1.75) / .9)) - spring(clamp((l - 10.95) / .9));
  const e = spring(clamp((l - 4.95) / .9)) - spring(clamp((l - 10.8) / .9));
  const h = 68 + 28 * e1 + 42 * e;
  const t0 = .3, cps = 21;
  const typed = gg_type(Q, l - t0, cps);
  const ph = clamp((t0 - l) / .15) + clamp(out * 2.2 - 1.2), qo = clamp(1 - out * 2.2);
  // steps: [start, done]
  const S = [[1.75, 3.4], [3.4, 5.0], [5.0, 8.5]], NM = ['Searching', 'Reading', 'Answering'];
  // once the row has faded out (11.6 s) it is reset to pending, then fades back in before the cycle wraps
  const lS = l >= 11.6 ? l - P : l, sO = l >= 11.6 ? soft(seg(l, 11.62, 12)) : vis;
  const steps = S.map(([a, b], i) => {
    const act = soft(seg(lS, a - .15, a + .2)) * (1 - soft(seg(lS, b, b + .25)));
    const dn = soft(seg(lS, b, b + .3));
    const c = gg_hx(gg_hx('#4A4A50', '#FFFFFF', act), '#8E8E93', dn);
    return `<div class="row" style="gap:4px"><div style="position:relative;width:12px;height:12px;flex:none">
<div style="position:absolute;inset:0;opacity:${gg_f(1 - dn)}">${gg_ring(12, A, gg_hx('#2E2E33', gg_hx('#2E2E33', A, .3), act), T * 400, .3 * act)}</div>
<div style="position:absolute;inset:0;border-radius:50%;background:${A};opacity:${gg_f(dn)};transform:scale(${gg_f(.5 + .5 * spring(clamp((lS - b) / .6)))});display:flex;align-items:center;justify-content:center">${tick(clamp((lS - b - .1) / .35), '#04161A', 9, 3.6)}</div></div>
<span style="font-size:9.5px;font-weight:500;color:${c}">${NM[i]}</span></div>`;
  }).join('');
  const chips = gg_FAV.map((fc, i) => {
    const t = 3.55 + i * .3, p = spring(clamp((l - t) / .65)), o = soft(clamp((l - t) / .22));
    return `<div class="row" style="height:18px;padding:0 6px 0 5px;gap:4px;border-radius:6px;background:#1A1A1E;opacity:${gg_f(o)};transform:scale(${gg_f(.45 + .55 * p)})"><i style="width:7px;height:7px;border-radius:2px;background:${fc}"></i><span style="font-size:9.5px;font-weight:600;color:#D4D4D8">${i + 1}</span></div>`;
  }).join('');
  const cnt_ = gg_steps(l, [[0, 0], [1.95, 1], [2.2, 3], [2.48, 4], [2.75, 6], [3.05, 7], [3.35, 8], [3.7, 9], [4.0, 10], [4.3, 11], [4.65, 12]], String, .45);
  // answer lines: a wipe made of two opposite translates, freshly streamed words glow teal then settle
  const ro = gg_rv(e, .78), r1 = gg_rv(e1, .62);
  const lines = gg_AL.map(([Lw, words, ts, du, cite], j) => {
    const f = clamp((l - ts) / du), y = j * 11;
    const ws = words.map(([x, ww]) => { const tw_ = ts + du * x / Lw; const c = gg_hx('#9BE7F1', '#3A3A40', clamp((l - tw_) / .7)); return `<i style="position:absolute;left:${x}px;top:0;width:${ww}px;height:5px;border-radius:2.5px;background:${c}"></i>`; }).join('');
    const ca = f > 0 && f < 1 ? 1 : f >= 1 && j === 2 ? 1 - soft(seg(l, 9, 9.6)) : 0;
    const ct = ts + du, cp = spring(clamp((l - ct) / .55));
    const cx = f * Lw + (j === 2 ? 14 * cp : 0);
    return `<div style="position:absolute;left:0;top:${y}px;width:${Lw}px;height:5px">
<div style="position:absolute;inset:0;overflow:hidden"><div style="position:absolute;inset:0;overflow:hidden;transform:translateX(${gg_f((f - 1) * Lw)}px)"><div style="position:absolute;inset:0;transform:translateX(${gg_f((1 - f) * Lw)}px)">${ws}</div></div></div>
<i style="position:absolute;left:0;top:-2.5px;width:1.8px;height:10px;border-radius:1px;background:${A};opacity:${gg_f(ca * (j === 2 && f >= 1 ? .35 + .65 * smooth(.5 + .5 * Math.cos(T * 5.6)) : 1))};transform:translateX(${gg_f(cx + 2)}px)"></i>
${l > ct ? `<div style="position:absolute;left:${Lw + 3}px;top:-2.5px;width:10px;height:10px;border-radius:50%;background:${rgba(A, .2)};color:${A};font-size:6.5px;font-weight:700;display:flex;align-items:center;justify-content:center;opacity:${gg_f(soft(clamp((l - ct) / .2)))};transform:scale(${gg_f(.3 + .7 * cp)})">${cite}</div>` : ''}</div>`;
  }).join('');
  return { h, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:7px;height:16px">${MK.perplexity(15, T, gg_TL, 1.9, 180 * S.reduce((a, [, b]) => a + spring(clamp((lS - b) / .8)), 0))}<div style="position:relative;flex:1;height:16px;font-size:12px;font-weight:600;line-height:16px">
<div style="position:absolute;left:3px;top:0;color:#5A5A62;font-weight:500;opacity:${gg_f(clamp(ph))}">Ask anything</div>
<div style="position:absolute;left:0;top:0;opacity:${gg_f(qo)};${gg_PROP}">${typed}${gg_car(T, A, 1 - soft(seg(l, t0 + Q.length / cps + .1, t0 + Q.length / cps + .45)))}</div></div></div>
<div class="row" style="margin-top:10px;gap:9px;height:13px;opacity:${gg_f(sO)}">${steps}</div>
<div class="row" style="margin-top:10px;gap:4px;height:18px;opacity:${gg_f(vis * r1.o)};transform:translateY(${gg_f(r1.y)}px)">${chips}<span class="sp"></span><span style="font-size:15px;font-weight:600;color:${A};letter-spacing:-.3px">${cnt_}</span><span class="m" style="margin-left:3px">sources</span></div>
<div style="position:absolute;left:16px;top:${gg_f(98)}px;width:204px;height:28px;opacity:${gg_f(ro.o * vis)};transform:translateY(${gg_f(ro.y)}px)">${lines}</div>
</div>` };
};

// ---------- notebooklm: Audio Overview, two hosts trading lines over a shared waveform
const gg_CAP = [['So octopuses have nine brains?', 'One central, plus one per arm.', 'Wait, so each arm thinks alone?'],
                ['Each arm can taste what it grabs.', 'That is honestly terrifying.', 'Right? Nature is wild.']];
const gg_SPKR = [[0, 1, 0], [1, 0, 1]];
W.notebooklm = (T, w) => {
  const A = gg_AM, P = 9.6, l = md(T, P), k = Math.floor(T / P);
  const cs = gg_CAP[md(k, 2)], sp = gg_SPKR[md(k, 2)], nsp = gg_SPKR[md(k + 1, 2)];
  // speaker turns: 0..3.1, 3.5..6.4, 6.8..9.6 (then the next cycle's first line)
  const x = kf(l, [[0, 0], [3.05, 0], [3.45, 1], [6.35, 1], [6.75, 2], [9.25, 2], [9.6, 3]]);
  const who = [sp[0], sp[1], sp[2], nsp[0]];
  const sB = kf(l, [[0, who[0]], [3.05, who[0]], [3.45, who[1]], [6.35, who[1]], [6.75, who[2]], [9.25, who[2]], [9.6, who[3]]]);
  // a short back-channel from the listener in the middle of each turn
  const bc = win(l, 4.6, 5.4, .2, .3) * .6 + win(l, 1.5, 2.2, .2, .3) * .5;
  const WA = clamp(Math.max(1 - sB, bc * sB)), WB = clamp(Math.max(sB, bc * (1 - sB)));
  const env = .6 + .4 * Math.abs(Math.sin(T * 6.3) * Math.sin(T * 2.1 + .7));
  const n = 31, x0 = 44, ww = 204 - 88, pitch = ww / (n - 1);
  let wv = '';
  for (let i = 0; i < n; i++) {
    const u = i / (n - 1);
    const act = WA * Math.exp(-u * 2.6) + WB * Math.exp(-(1 - u) * 2.6);
    const v = clamp(.12 + .88 * Math.abs(noise(T * 4.6 + i * .83)) * env);
    const hh = 2.6 + 19 * v * clamp(act);
    wv += `<i style="position:absolute;left:${gg_f(x0 + i * pitch - 1.2, 2)}px;top:50%;width:2.4px;height:${gg_f(hh, 2)}px;margin-top:${gg_f(-hh / 2, 2)}px;border-radius:2px;background:${gg_hx('#2A2A2E', A, clamp(act * 1.25))}"></i>`;
  }
  const host = (wt, left, g1, g2, letter) => {
    const rings = [0, 1].map(j => { const u = md(T * 1.05 + j * .5, 1); return `<i style="position:absolute;inset:0;border-radius:50%;box-shadow:0 0 0 1.5px ${A};opacity:${gg_f((1 - u) * .7 * wt)};transform:scale(${gg_f(1 + u * .55)})"></i>`; }).join('');
    return `<div style="position:absolute;${left ? 'left:0' : 'right:0'};top:2px;width:28px;height:28px">${rings}<i style="position:absolute;inset:-3px;border-radius:50%;box-shadow:0 0 0 1.6px ${rgba(A, .9)};opacity:${gg_f(wt)}"></i><div style="position:absolute;inset:0;opacity:${gg_f(.5 + .5 * wt)}">${av(letter, g1, g2, 28, '#1A1206')}</div></div>`;
  };
  const caps = [cs[0], cs[1], cs[2], gg_CAP[md(k + 1, 2)][0]].map((c, i) => `<div style="text-align:${who[i] ? 'right' : 'left'}">${c}</div>`);
  const now = 252 + T, f = .365 + T * .006;
  return { h: 144, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${tile(MK.notebooklm(17, T), rgba(A, .15))}<div style="line-height:1.25"><div style="font-size:13px;font-weight:600">Audio Overview</div><div class="m">Deep dive · 12 sources</div></div><span class="sp"></span><div style="width:28px;height:28px;border-radius:50%;background:#1C1C20;display:flex;align-items:center;justify-content:center">${ico('pause', '#FFFFFF', 12)}</div></div>
<div style="position:absolute;left:16px;right:16px;top:54px;height:32px">${host(WA, 1, '#FFE2AE', '#E8963A', 'M')}<div style="position:absolute;inset:0">${wv}</div>${host(WB, 0, '#F6D2C0', '#C9785F', 'J')}</div>
<div style="position:absolute;left:16px;right:16px;top:94px;height:14px;font-size:10.5px;font-weight:500;color:#D8D8DC">${xstack(caps, x, 6)}</div>
<div class="row" style="position:absolute;left:16px;right:16px;top:119px;gap:9px"><div style="position:relative;flex:1;height:3px">${bar(f, 130, A, 3, '#232326')}<i style="position:absolute;left:0;top:-2.5px;width:8px;height:8px;border-radius:50%;background:#FFFFFF;transform:translateX(${gg_f(f * 130 - 4)}px)"></i></div><span style="font-size:9.5px;font-weight:600">${tickUp(now, mmss)}<span style="color:#8E8E93;font-weight:500"> / 11:30</span></span></div>
</div>` };
};

// ---------- pills
W.p_gemini = T => ({ h: 50, html: pill(MK.gemini(17, T), gg_B, gg_cyc(T, 9.6, .4, [12, 23, 31, 40, 52, 64, 71, 83, 92, 100], .82, String, .55, true) + `<span style="font-size:10.5px;margin-left:1px;${gg_gt(.78, 1)}">%</span>`) });
const gg_ppRot = T => { const l = md(T - 1.1, 8.4), i = Math.min(5, Math.floor(l / 1.25)); return 180 * (i + (i > 0 ? spring(clamp((l - i * 1.25) / .8)) - 1 : 0)); };
W.p_pplx = T => ({ h: 50, html: pill(MK.perplexity(16, T, gg_TL, 1.9, gg_ppRot(T)), gg_TL, gg_cyc(T, 8.4, 1.1, [4, 7, 9, 12, 15, 18], 1.25, String) + '<span style="font-size:10.5px;margin-left:3px">sources</span>') });
