// widgets/anthropic.js: Claude (chat app) and Claude Code. Every top-level name here starts with an_.
const an_A = '#D97757', an_A2 = '#E9A285', an_CR = '#F0EEE6', an_GR = '#3FB950', an_RD = '#F85149';
const an_MONO = "font-family:'JetBrains Mono',ui-monospace,monospace";

// ---------- brand mark: a warm starburst of 11 rounded, slightly uneven rays (own drawing)
// o.th 0..1 how much the rays breathe, o.rot rotation in degrees, o.c color
const an_RAY = [[0, 1], [31, .62], [66, .9], [97, .7], [129, .97], [163, .6], [196, .88], [227, .74], [260, 1], [291, .66], [326, .84]];
function an_burst(s, T, o) {
  o = o || {}; const th = o.th == null ? .3 : o.th, rot = o.rot == null ? T * 14 : o.rot, c = o.c || an_A;
  let d = '';
  for (let i = 0; i < an_RAY.length; i++) {
    const a = an_RAY[i][0] * Math.PI / 180, f = an_RAY[i][1];
    const L = (5.2 + 6.2 * f) * (1 + th * .085 * Math.sin(T * 3.3 + i * 2.17));
    const ux = Math.cos(a), uy = Math.sin(a), vx = -uy, vy = ux, bw = 1.3, tw = 1.12, r0 = .3, rt = L - tw;
    const p = (r, q) => `${(12 + ux * r + vx * q).toFixed(2)} ${(12 + uy * r + vy * q).toFixed(2)}`;
    d += `M${p(r0, bw)}L${p(rt, tw)}A${tw} ${tw} 0 0 0 ${p(rt, -tw)}L${p(r0, -bw)}Z`;
  }
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="overflow:visible;flex:none"><g transform="rotate(${rot.toFixed(2)} 12 12)"><path d="${d}" fill="${c}"/><circle cx="12" cy="12" r="1.9" fill="${c}"/></g></svg>`;
}
MK.claude = (s, T, o) => an_burst(s, T, o);

// ---------- helpers (an_ prefix)
// integer counter: from n0 it ticks +1 every 1/rate s starting at l0, stops at nmax; each tick rolls
function an_ctr(l, l0, rate, n0, nmax, fmt, dur = .45) {
  const n = Math.min(nmax, n0 + Math.max(0, Math.floor((l - l0) * rate)));
  if (n === n0) return roll2(fmt(n0), fmt(n0), 9, dur);
  return roll2(fmt(n - 1), fmt(n), l - (l0 + (n - n0) / rate), dur);
}
// color mix that returns #RRGGBB, so it can be nested
const an_hx = (a, b, p) => '#' + [1, 3, 5].map(i => Math.round(mix(parseInt(a.substr(i, 2), 16), parseInt(b.substr(i, 2), 16), clamp(p))).toString(16).padStart(2, '0')).join('');
// stepped value with a roll at each key: K = [[time, value], ...]
function an_steps(l, K, fmt, dur = .5) {
  let i = 0; while (i < K.length - 1 && l >= K[i + 1][0]) i++;
  if (i === 0) return roll2(fmt(K[0][1]), fmt(K[0][1]), 9, dur);
  return roll2(fmt(K[i - 1][1]), fmt(K[i][1]), l - K[i][0], dur);
}
// reset crossfade for a right-aligned value: a (old) rises out, b (new) rises in from below; never rolls backwards.
// Both layers share one grid cell aligned to the end, and the wrapper is always there, so nothing shifts at either end.
function an_xf(a, b, k, dy = 6) {
  const lay = (s, o, y) => o <= .001 ? '' : `<span style="grid-area:1/1;justify-self:end;opacity:${o.toFixed(3)};transform:translateY(${y.toFixed(2)}px)">${s}</span>`;
  const oa = k <= 0 ? 1 : clamp(1 - k * 2), ob = k >= 1 ? 1 : clamp(k * 2 - 1);
  return `<span style="display:inline-grid;vertical-align:top">${lay(a, oa, -clamp(k) * dy)}${lay(b, ob, (1 - clamp(k)) * dy)}</span>`;
}
// font features without tabular figures, for copy with a hyphen (Inter's tabular hyphen is too wide)
const an_PROP = "font-feature-settings:'cv11','ss01'";
// streamed text: only typed characters are rendered (so a caret can follow), each fades and rises in
const an_type = (s, l, cps) => { const n = Math.max(0, Math.min(s.length, Math.ceil(l * cps))); return typeIn(s.slice(0, n), l, cps, .14); };
// Claude Code style spinner: a small star whose rays swap length while it turns
function an_spin(T, s, c) {
  let d = '';
  for (let i = 0; i < 8; i++) {
    const a = (i * 45 + T * 110) * Math.PI / 180;
    const L = 3.4 + 4.6 * (.5 + .5 * Math.sin(T * 6.2 + (i % 2) * Math.PI + i * .35));
    d += `M${(12 + Math.cos(a) * 1.2).toFixed(2)} ${(12 + Math.sin(a) * 1.2).toFixed(2)}L${(12 + Math.cos(a) * L).toFixed(2)} ${(12 + Math.sin(a) * L).toFixed(2)}`;
  }
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24"><path d="${d}" stroke="${c}" stroke-width="2.6" stroke-linecap="round" fill="none"/></svg>`;
}

// ---------- Claude app: a message is sent, Claude thinks, streams an answer, then writes an artifact
W.claude_chat = (T, w) => {
  const A = an_A, P = 11; const { k, l } = st(T, P, 0);
  const e = morph(T, P, 6.55, 9.85); const h = mix(124, 164, e);
  const thOut = soft(seg(l, 3.45, 4.05)), R = soft(seg(l, 10.5, 10.95));
  const thinking = Math.max(1 - thOut, R);
  const rot = 10 * T + 160 * (k + io(clamp(l / 3.8)));
  const glow = thinking * (.55 + .45 * Math.sin(T * 3.6));
  const mark = `<div style="border-radius:9.6px;box-shadow:0 0 ${(4 + 8 * glow).toFixed(2)}px ${rgba(A, (.28 * thinking).toFixed(3))};flex:none">${tile(MK.claude(19, T, { th: .2 + .8 * thinking, rot }), rgba(A, (.15 + .06 * glow).toFixed(3)), 30)}</div>`;
  // subtitle: Thinking Ns (shimmer) -> Thought for 6s
  const sec = l > 8 ? roll2('0', '0', 9) : an_ctr(l, .3, 6 / 2.6, 0, 6, String);
  const sub = xstack([
    `${shimmer('Thinking', T, '#76767E', an_CR, .8, 3.5)}&nbsp;<span style="color:${an_A2}">${sec}s</span>`,
    `<span style="color:#8E8E93">Thought for 6s</span>`
  ], thOut * (1 - R), 6);
  // the prompt bubble: leaves with the old answer, the next one is sent with a spring
  let bO = 1, bY = 0, bS = 1;
  if (l >= 9.95 && l < 10.4) { const q = soft(seg(l, 9.95, 10.3)); bO = 1 - q; bY = -4 * q; }
  else if (l >= 10.4) { const q = spring(seg(l, 10.42, 10.98)); bO = soft(seg(l, 10.42, 10.7)); bY = (1 - q) * 8; bS = .82 + .18 * q; }
  const bubble = bO <= .001 ? '' : `<div class="row" style="position:absolute;right:16px;top:52px;height:20px;padding:0 9px;border-radius:10px 10px 4px 10px;background:#1C1C20;font-size:10.5px;font-weight:500;color:#E4E4E8;opacity:${bO.toFixed(3)};transform-origin:100% 100%;transform:translateY(${bY.toFixed(2)}px) scale(${bS.toFixed(4)})">Plan a rooftop launch for 40</div>`;
  // thinking summaries scroll upward while it thinks
  const TH = ['Sunset on Friday is 7:48 PM', 'Tacos beat a sit-down dinner', 'Sketching a run of show'];
  const tx = l < 6 ? kf(l, [[0, 0], [1.05, 0], [1.45, 1], [2.2, 1], [2.6, 2]]) : 0;
  const tO = l < 6 ? 1 - soft(seg(l, 3.3, 3.75)) : soft(seg(l, 10.55, 10.98));
  const sc = Math.max(0, tx - 1);
  const thoughts = TH.map((s, j) => {
    const L = j - sc; let o = j === 0 ? 1 : soft(clamp(tx - (j - 1)));
    if (L < 0) o *= clamp(1 + L * 1.6);
    if (o <= .002) return '';
    const rise = j === 0 ? (l < 6 ? 0 : (1 - soft(seg(l, 10.55, 10.98))) * 5) : (1 - soft(clamp(tx - (j - 1)))) * 5;
    const c = hexmix('#5C5C63', '#A9A9B0', clamp(j - (tx - 1)));
    return `<div style="position:absolute;left:10px;top:0;opacity:${o.toFixed(3)};transform:translateY(${(L * 15 + rise).toFixed(2)}px);color:${c};font-size:10.5px;font-weight:500;line-height:15px;${an_PROP}">${s}</div>`;
  }).join('');
  // the streamed answer
  const L1 = 'Friday, 7 PM on the roof. Tacos,', L2 = 'string lights and one short toast.';
  const t1 = 3.95, cps = 27, t2 = t1 + L1.length / cps + .1;
  const aO = 1 - soft(seg(l, 9.95, 10.35));
  const onL2 = l >= t2;
  const cO = soft(seg(l, t1 - .1, t1 + .1)) * (1 - soft(seg(l, 7.2, 7.6)));
  const crt = `<span style="opacity:${cO.toFixed(3)}">${caret(T, A, 11)}</span>`;
  const ans = l < t1 - .2 || aO <= 0 ? '' : `<div style="position:absolute;left:16px;right:16px;top:80px;font-size:11.5px;font-weight:500;line-height:15px;color:#F2F2F4;opacity:${aO.toFixed(3)}"><div>${an_type(L1, l - t1, cps)}${onL2 ? '' : crt}</div><div>${an_type(L2, l - t2, cps)}${onL2 ? crt : ''}</div></div>`;
  // artifact chip with a mini document whose lines fill in, then a check
  const cIn = soft(seg(l, 6.74, 7.04)), cOut = soft(seg(l, 9.5, 9.82)), cY = (1 - spring(seg(l, 6.74, 7.5))) * 5 + cOut * 3;
  const f = seg(l, 6.95, 8.3);
  const lines = [[3.2, 3, 11, A], [9.5, 1.8, 15, '#8C857A'], [13.5, 1.8, 13, '#8C857A'], [17.5, 1.8, 15, '#8C857A'], [21.5, 1.8, 9, '#8C857A']].map(([y, hh, ww, c], j) =>
    `<div style="position:absolute;left:4px;top:${y}px;width:${ww}px;height:${hh}px;border-radius:1px;background:rgba(60,50,40,.12);overflow:hidden"><div style="position:absolute;inset:0;background:${c};transform:translateX(${((soft(clamp(f * 5 - j)) - 1) * ww).toFixed(2)}px)"></div></div>`).join('');
  const ck = spring(seg(l, 8.35, 8.95)), ckO = soft(seg(l, 8.35, 8.6));
  const lab = xstack([`${shimmer('Writing artifact', T, '#5E5E66', '#C9C9CF', .7, 4)}`, 'Artifact · Document'], ckO, 5);
  const chipO = cIn * (1 - cOut);
  const chip = chipO <= .001 ? '' : `<div class="row" style="position:absolute;left:16px;right:16px;top:116px;height:36px;border-radius:11px;background:#111113;box-shadow:inset 0 0 0 .6px rgba(255,255,255,.07);padding:0 9px 0 5px;gap:9px;opacity:${chipO.toFixed(3)};transform:translateY(${cY.toFixed(2)}px)">
<div style="position:relative;width:22px;height:26px;border-radius:4px;background:${an_CR};flex:none">${lines}</div>
<div style="line-height:1.2;flex:1"><div class="m" style="position:relative;height:11px;font-size:9px">${lab}</div><div style="font-size:11.5px;font-weight:600">Launch plan</div></div>
<div style="position:relative;width:18px;height:18px"><div style="position:absolute;inset:0;opacity:${(1 - ckO).toFixed(3)}">${ring(f, 18, 2.4, A, '#26262A')}</div>
<div style="position:absolute;inset:0;border-radius:50%;background:${A};display:flex;align-items:center;justify-content:center;opacity:${ckO.toFixed(3)};transform:scale(${(.6 + .4 * ck).toFixed(3)})">${tick(clamp((l - 8.45) / .35), '#fff', 11, 3.4)}</div></div></div>`;
  return {
    h, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${mark}<div style="line-height:1.25;flex:1"><div style="font-size:13px;font-weight:600">Claude</div><div class="m" style="position:relative;height:13px">${sub}</div></div>${tag('Opus', an_A2, .12)}</div>
${bubble}
${tO > .002 ? `<div style="position:absolute;left:16px;right:16px;top:80px;height:30px;opacity:${tO.toFixed(3)}"><i style="position:absolute;left:0;top:2px;width:2px;height:26px;border-radius:1px;background:#2A2A2E"></i>${thoughts}</div>` : ''}
${ans}${chip}</div>`
  };
};

// ---------- Claude Code: agent working through a todo list in a terminal
W.claude_code = (T, w) => {
  const A = an_A, P = 12; const { l } = st(T, P, 0);
  const e = morph(T, P, 6.15, 10.95); const h = mix(136, 162, e);
  const R = soft(seg(l, 10.9, 11.5));
  const DT = [2.8, 5.9, 8.8];
  // tool call line
  const tf = (n, a) => `<b style="font-weight:700;color:#fff">${n}</b><span style="color:#8E8E93">&nbsp;&nbsp;${a}</span>`;
  const TL = [tf('Read', 'src/auth.ts'), tf('Grep', '"redirect"'), tf('Edit', 'src/auth.ts'), tf('Edit', 'session.ts'), tf('Bash', 'npm test'), tf('Done', '3 tasks · 14 tests')];
  TL.push(TL[0]);
  const tx = kf(l, [[0, 0], [1.3, 0], [1.65, 1], [2.95, 1], [3.3, 2], [4.5, 2], [4.85, 3], [6.0, 3], [6.35, 4], [8.9, 4], [9.25, 5], [11.0, 5], [11.45, 6]]);
  const done = soft(seg(l, 9.0, 9.4)) * (1 - soft(seg(l, 11.0, 11.4)));
  const spin = `<div style="position:absolute;left:0;top:1px;opacity:${(1 - done).toFixed(3)}">${an_spin(T, 12, A)}</div><div style="position:absolute;left:0;top:1px;width:12px;height:12px;border-radius:50%;background:${A};display:flex;align-items:center;justify-content:center;opacity:${done.toFixed(3)};transform:scale(${(.7 + .3 * done).toFixed(3)})">${tick(clamp((l - 9.05) / .35) * (1 - R), '#fff', 8, 3.6)}</div>`;
  // the session clock and the diff counters reset with a crossfade (a timer never rolls backwards)
  const z = s => roll2(s, s, 9);
  const clock = an_xf(an_ctr(l, .5, 1, 64, 73, mmss), z(mmss(64)), soft(seg(l, 10.9, 11.4)));
  const add = an_xf('+' + an_steps(l, [[0, 0], [3.45, 38], [3.95, 96], [4.95, 121], [5.5, 142]], String), '+' + z('0'), soft(seg(l, 10.95, 11.45)));
  const del = an_xf('−' + an_steps(l, [[0, 0], [3.75, 6], [4.4, 12], [5.2, 18]], String), '−' + z('0'), soft(seg(l, 11.05, 11.55)));
  // todo list with a highlight that slides to the active row
  const act = l < 10 ? kf(l, [[0, 0], [2.9, 0], [3.4, 1], [6.0, 1], [6.5, 2]], spring) : 0;
  const hlO = l < 10 ? 1 - soft(seg(l, 8.9, 9.3)) : soft(seg(l, 11.3, 11.9));
  const TD = ['Trace the redirect loop', 'Patch the session guard', 'Run the test suite'];
  const rows = TD.map((s, j) => {
    const d = soft(seg(l, DT[j], DT[j] + .3)) * (1 - R), tp = clamp((l - DT[j] - .1) / .32) * (1 - R);
    const pop = .82 + .18 * spring(seg(l, DT[j], DT[j] + .7));
    const on = clamp(1 - Math.abs(act - j)) * hlO;
    const strike = soft(seg(l, DT[j] + .15, DT[j] + .55)) * (1 - R);
    const tc = an_hx(an_hx('#8E8E93', '#FFFFFF', on), '#5E5E64', d);
    const bc = an_hx(an_hx('#3A3A3E', A, on * (.7 + .3 * Math.sin(T * 5) ** 2)), A, d);
    return `<div class="row" style="position:absolute;left:0;top:${j * 17}px;height:17px;gap:8px">
<div style="position:relative;width:12px;height:12px;border-radius:3.5px;box-shadow:inset 0 0 0 1.4px ${bc};flex:none"><div style="position:absolute;inset:0;border-radius:3.5px;background:${A};opacity:${d.toFixed(3)};transform:scale(${(d > 0 ? pop : .82).toFixed(3)});display:flex;align-items:center;justify-content:center">${tick(tp, '#fff', 9, 3.6)}</div></div>
<span style="position:relative;font-size:10.5px;font-weight:500;color:${tc}">${s}<i style="position:absolute;left:0;right:0;top:50%;height:1px;background:#5E5E64;transform-origin:0 50%;transform:scaleX(${strike.toFixed(3)})"></i></span></div>`;
  }).join('');
  // tests: segments fill green and the count rolls up
  const vc = l < 11.3 ? kf(l, [[6.45, 0], [8.55, 14]], x => x) : 0;
  const cells = [...Array(14)].map((_, i) => `<i style="flex:1;height:7px;border-radius:2px;background:${hexmix('#1F1F23', an_GR, clamp(vc - i))}"></i>`).join('');
  const tests = an_steps(l, [[0, 0], [6.9, 3], [7.35, 6], [7.8, 9], [8.25, 12], [8.55, 14], [11.2, 0]], String);
  const tO = clamp((e - .45) / .4);
  return {
    h, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${chip('term', A)}<div style="line-height:1.25;flex:1"><div style="font-size:13px;font-weight:600">Claude Code</div><div class="row m" style="gap:3px;font-size:9.5px;${an_MONO}">${ico('branch', '#8E8E93', 10, 2.2)}fix/auth-redirect</div></div>
<div style="${an_MONO};font-size:11px;font-weight:600;text-align:right"><div style="color:${an_GR};line-height:16px">${add}</div><div style="color:${an_RD};line-height:13px">${del}</div></div></div>
<div style="position:absolute;left:16px;right:16px;top:54px;height:14px;${an_MONO};font-size:10px">${spin}<div style="position:absolute;left:19px;right:30px;top:0;height:14px;line-height:14px">${xstack(TL, tx, 6)}</div><div class="m" style="position:absolute;right:0;top:0;line-height:14px;font-size:9.5px">${clock}</div></div>
<div style="position:absolute;left:16px;right:16px;top:73px;height:51px"><div style="position:absolute;left:-6px;right:-6px;top:0;height:17px;border-radius:6px;background:#141417;opacity:${hlO.toFixed(3)};transform:translateY(${(act * 17).toFixed(2)}px)"></div><div style="position:absolute;left:0;top:0">${rows}</div></div>
${tO > .001 ? `<div class="row" style="position:absolute;left:16px;right:16px;top:134px;height:12px;gap:8px;opacity:${tO.toFixed(3)};transform:translateY(${((1 - e) * 6).toFixed(2)}px)"><div class="row" style="flex:1;gap:2px">${cells}</div><span style="${an_MONO};font-size:10px;font-weight:600">${tests}/14 <span style="color:${an_GR}">passed</span></span></div>` : ''}
</div>`
  };
};

// ---------- pills
W.p_claude = T => ({ h: 50, html: pill(MK.claude(18, T, { th: .9, rot: T * 22 }), an_A, tickUp(12 + T, mmss)) });
const an_termIco = (T, c, s = 17) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex:none"><rect x="3" y="4.5" width="18" height="15" rx="3.5"/><path d="M7 9.5l3 2.5-3 2.5"/><path d="M12.5 15h4.5" opacity="${(.25 + .75 * smooth(.5 + .5 * Math.cos(T * Math.PI * 2 * .9) * 1.6)).toFixed(3)}"/></svg>`;
W.p_claude_code = T => {
  const A = an_A, l = md(T, 15);
  // 5..9 tasks roll up; the reset crossfades back to 5 instead of rolling down
  const v = an_xf(an_steps(l, [[0, 5], [2.6, 6], [5.2, 7], [7.8, 8], [10.4, 9]], String, .6), roll2('5', '5', 9), soft(seg(l, 14.1, 14.6)), 7);
  const d = soft(seg(l, 10.6, 11.0)) * (1 - soft(seg(l, 13.9, 14.3))), pop = spring(seg(l, 10.6, 11.3));
  const icon = `<div style="position:relative;width:17px;height:17px;flex:none"><div style="position:absolute;inset:0;opacity:${(1 - d).toFixed(3)}">${an_termIco(T, A)}</div><div style="position:absolute;inset:0;border-radius:50%;background:${A};display:flex;align-items:center;justify-content:center;opacity:${d.toFixed(3)};transform:scale(${(.6 + .4 * pop).toFixed(3)})">${tick(clamp((l - 10.7) / .35) * (1 - soft(seg(l, 13.9, 14.3))), '#fff', 11, 3.4)}</div></div>`;
  return { h: 50, html: pill(icon, A, v + `<span style="font-size:10.5px;margin-left:1px;opacity:.75">/9</span>`) };
};
