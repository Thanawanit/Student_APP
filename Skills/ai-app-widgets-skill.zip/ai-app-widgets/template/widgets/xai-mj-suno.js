// widgets/xai-mj-suno.js: Grok DeepSearch, a Midjourney job, a Suno song, and the p_grok / p_mj pills.
// Every top-level name in this file is prefixed xms_.
const xms_GA='#5AA9FF';                    // grok: one cool accent on monochrome
const xms_MA='#B39BFF';                    // midjourney: soft lilac
const xms_SA='#FF7A45',xms_SB='#FF4FA3';   // suno: warm orange to pink

const xms_hash=i=>{const s=Math.sin(i*127.1+311.7)*43758.5453;return s-Math.floor(s)};
// odometer through keyed values [[t,v],...] at local time l (rolls from the previous key's value)
function xms_rk(l,K,fmt,dur=.6){let i=0;while(i<K.length-1&&l>=K[i+1][0])i++;if(l<K[0][0]||i===0){const s=fmt(K[0][1]);return roll2(s,s,99)}return roll2(fmt(K[i-1][1]),fmt(K[i][1]),l-K[i][0],dur)}
// stepped continuous value: each key eases in over d seconds
const xms_step=(l,K,d=.55)=>{let v=K[0][1];for(let i=1;i<K.length;i++)v+=(K[i][1]-K[i-1][1])*soft(seg(l,K[i][0],K[i][0]+d));return v};
const xms_f=v=>(+v).toFixed(3);
// hex colour mix that returns #RRGGBB (so results can be mixed again)
const xms_hx=(a,b,p)=>{const pa=[1,3,5].map(i=>parseInt(a.substr(i,2),16)),pb=[1,3,5].map(i=>parseInt(b.substr(i,2),16));return '#'+pa.map((v,i)=>Math.round(mix(v,pb[i],clamp(p))).toString(16).padStart(2,'0')).join('')};

// ---------- brand marks (original simple glyphs)
// Grok: a ring cut where a bold diagonal slash crosses it
MK.grok=(s=16,T=0,c='#FFFFFF')=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" style="flex:none"><circle cx="12" cy="12" r="7.4" stroke="${c}" stroke-width="2.5" pathLength="360" stroke-dasharray="117 36 144 36 27 0"/><path d="M5.9 18.1L19.4 4.6" stroke="${c}" stroke-width="3.1" stroke-linecap="round"/></svg>`;
// Midjourney: a little sailboat, main sail, jib and hull
MK.midjourney=(s=16,T=0,c='#FFFFFF')=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none"><path d="M12.7 2.8c3.4 3.4 5.4 7.6 6 12.2h-6z" fill="${c}"/><path d="M11.1 6.3V15H5.7c1.2-3.4 3-6.4 5.4-8.7z" fill="${c}" opacity=".72"/><path d="M3.6 16.9h16.8c-.8 2.4-2.9 3.9-5.4 3.9H9c-2.5 0-4.6-1.5-5.4-3.9z" fill="${c}"/></svg>`;
// Suno: a warm gradient disc with a sound wave cut through it
MK.suno=(s=16,T=0)=>`<div style="width:${s}px;height:${s}px;border-radius:50%;background:linear-gradient(135deg,#FF8A3D,#FF4FA3);flex:none;display:flex;align-items:center;justify-content:center"><svg width="${(s*.72).toFixed(2)}" height="${(s*.72).toFixed(2)}" viewBox="0 0 24 24" fill="none"><path d="M2.5 12c2.3 0 2.3-5.5 4.7-5.5S9.6 17.5 12 17.5s2.4-11 4.8-11 2.4 5.5 4.7 5.5" stroke="#120607" stroke-width="2.7" stroke-linecap="round" stroke-linejoin="round"/></svg></div>`;

// =====================================================================================
// grok: Grok DeepSearch. Searching X -> Reading 48 threads -> Thinking -> answer typed, then soft reset.
const xms_GP=14;
const xms_GQ=[
 {q:'Vela Phone launch',n:2481,th:48,a:'Mostly hype. Battery is the gripe.',sd:1.3},
 {q:'Orbit Coffee drop',n:3126,th:36,a:'Loved the beans, hated the wait.',sd:4.6}];
const xms_GF=[.035,.1,.21,.35,.49,.62,.75,.86,.94,1];
const xms_GT=[.15,.55,.95,1.4,1.9,2.4,2.95,3.6,4.4,5.3];
// ticker speed (px/s) through the cycle; position is its integral so it never jumps
const xms_gv=l=>kf(l,[[0,64],[3,64],[3.9,22],[6.1,22],[7.2,0],[12.9,0],[13.6,64],[14,64]]);
const xms_gint=l=>{const n=Math.max(1,Math.ceil(l/.02)),h=l/n;let s=0;for(let i=0;i<n;i++)s+=xms_gv((i+.5)*h)*h;return s};
const xms_GC=xms_gint(xms_GP);
// tiny post rows in two lanes, lens at the centre lights them up as they pass
function xms_chips(pos,lens,rd){let s='';const PX=62,Wd=204,cx0=102;
 for(let r=0;r<2;r++){const off=r*31+7;const j0=Math.floor((pos-off-80)/PX),j1=Math.ceil((pos-off+Wd+10)/PX);
  for(let j=j0;j<=j1;j++){const x=j*PX+off-pos;const id=j*2+r;const w1=20+Math.round(xms_hash(id)*18),w2=9+Math.round(xms_hash(id+.37)*15);const cw=12+Math.max(w1,w2);
   const e=clamp(x/26)*clamp((Wd-x-cw)/26);if(e<=.002)continue;const cx=x+cw/2;
   const k=smooth(clamp(1-Math.abs(cx-cx0)/34))*lens;const rr=rd*smooth(clamp((cx0-cx)/28))*.42;const b=Math.max(k,rr);
   s+=`<g opacity="${xms_f(e)}" transform="translate(${x.toFixed(2)},${r*16})"><circle cx="4.5" cy="5.5" r="4.5" fill="${hexmix('#2C2C31','#E9E9EE',b)}"/><rect x="12" y="1.5" width="${w1}" height="3" rx="1.5" fill="${hexmix('#27272B','#FFFFFF',b)}"/><rect x="12" y="6.5" width="${w2}" height="3" rx="1.5" fill="${hexmix('#1F1F23','#8E8E93',b)}"/></g>`}}
 return s}
// mentions sparkline drawing itself left to right (f 0..1)
function xms_spark(f,sd,T,op){const Wd=204,H=27;if(op<=.002)return '';
 const fn=u=>clamp(.08+.42*Math.pow(u,1.7)+.12*noise(u*10+sd)+.36*Math.exp(-Math.pow((u-.8)/.07,2))+.07*Math.sin(T*2.3+u*11)*Math.pow(u,5),.04,.97);
 const P=u=>[u*Wd,H-2-fn(u)*(H-5)];const n=56;const m=Math.floor(f*n);let pts=[];for(let i=0;i<=m;i++)pts.push(P(i/n));if(f*n>m)pts.push(P(f));if(pts.length<2)pts.push(P(Math.max(f,.001)));
 const d='M'+pts.map(p=>p[0].toFixed(2)+' '+p[1].toFixed(2)).join('L');const L=pts[pts.length-1];const pu=.5+.5*Math.sin(T*4.2);
 return `<svg width="${Wd}" height="${H}" style="position:absolute;left:0;top:0;overflow:visible;opacity:${xms_f(op)}"><path d="M0 ${H-.5}H${Wd}" stroke="#2A2A2E" stroke-dasharray="1.5 3"/><path d="${d}L${L[0].toFixed(2)} ${H}L0 ${H}Z" fill="rgba(255,255,255,.07)"/><path d="${d}" stroke="#FFFFFF" stroke-width="1.6" fill="none" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${L[0].toFixed(2)}" cy="${L[1].toFixed(2)}" r="${(3.2+2.6*pu).toFixed(2)}" fill="${rgba(xms_GA,.22*(1-pu*.5))}"/><circle cx="${L[0].toFixed(2)}" cy="${L[1].toFixed(2)}" r="2.6" fill="${xms_GA}"/></svg>`}

W.grok=(T,w)=>{
 const P=xms_GP,k=Math.floor(T/P),l=T-k*P,Q=xms_GQ[md(k,2)],Qn=xms_GQ[md(k+1,2)];
 // 0 Searching X, 1 Reading threads, 2 Thinking, 3 Answered, 4 Searching again (same as 0)
 const x=kf(l,[[0,0],[3,0],[3.5,1],[6.1,1],[6.6,2],[8.6,2],[9.1,3],[12.9,3],[13.6,4]]);
 const e=morph(T,P,8.8,12.7);const h=mix(118,146,e);
 const tk=1-soft(seg(l,6.1,7))+soft(seg(l,12.9,13.6));
 const rd=clamp(1-Math.abs(x-1)*1.3);
 const pos=k*xms_GC+xms_gint(l);
 const sp=soft(seg(l,6.5,8.7)),so=1-soft(seg(l,12.6,13.15));
 const K=xms_GT.map((t,i)=>[t,Math.round(Q.n*xms_GF[i])]);K.push([12.95,Math.round(Qn.n*xms_GF[0])]);
 const ck=soft(seg(l,8.75,9.25));
 const it=[`Searching X&nbsp;&nbsp;${dots(T,'#8E8E93',3,2.5)}`,`Reading ${xms_rk(l,[[0,8],[3.45,17],[4.1,31],[4.8,Q.th]],String,.6)} threads`,shimmer('Thinking',T,'#6E6E76','#FFFFFF',.9),
  `<span style="display:inline-flex;align-items:center;gap:4px;color:#FFFFFF">${tick(ck,xms_GA,10,3.4)}Answered in 9s</span>`,`Searching X&nbsp;&nbsp;${dots(T,'#8E8E93',3,2.5)}`];
 const tl=l-9.15,ans=Q.a,nch=clamp(Math.ceil(tl*20),0,ans.length),tdone=ans.length/20;
 const R={o:clamp((e-.72)/.25),y:(1-e)*6};const qa=soft(seg(l,13,13.8));
 return {h,html:`<div class="in" style="padding:14px 16px">
<div class="row" style="gap:9px">${tile(MK.grok(17,T),'#1C1C20',30)}<div style="line-height:1.25;flex:1;min-width:0"><div class="row" style="gap:6px"><span style="font-size:13px;font-weight:600">Grok</span><span style="font-size:8.5px;font-weight:600;color:#C7C7CC;background:#1C1C20;border-radius:5px;padding:1.5px 5px;letter-spacing:.1px">DeepSearch</span></div><div class="m" data-xs style="position:relative;height:14px;font-size:10px">${xstack(it,x,7)}</div></div>
<div style="text-align:right;line-height:1.1"><div data-xh style="font-size:22px;font-weight:600;color:${xms_GA};letter-spacing:-.6px">${xms_rk(l,K,fmtC,.62)}</div><div class="m" style="font-size:9.5px">posts</div></div></div>
<div style="position:absolute;left:16px;top:56px;width:204px;height:27px">
 <div style="position:absolute;left:74px;top:-4px;width:56px;height:35px;opacity:${xms_f(tk*(.55+.45*rd))};background:linear-gradient(90deg,rgba(90,169,255,0),rgba(90,169,255,.09),rgba(90,169,255,0))"></div>
 <div style="position:absolute;left:101.25px;top:-4px;width:1.5px;height:35px;border-radius:1px;opacity:${xms_f(tk*.85)};background:linear-gradient(180deg,rgba(90,169,255,0),${xms_GA},rgba(90,169,255,0))"></div>
 ${tk>.002?`<svg width="204" height="27" style="position:absolute;left:0;top:0;opacity:${xms_f(tk)}">${xms_chips(pos,1,rd)}</svg>`:''}
 ${xms_spark(sp,Q.sd,T,so*clamp(sp*8))}
 <div class="m" style="position:absolute;left:0;top:-1px;font-size:9px;color:#6E6E76;opacity:${xms_f(so*soft(seg(l,6.9,7.5)))}">Mentions · 24h</div>
</div>
<div class="row" style="position:absolute;left:16px;right:16px;top:93px;gap:5px">${ico('search','#8E8E93',10,2.6)}<div style="position:relative;flex:1;height:13px;font-size:10px;font-weight:500;color:#C7C7CC;line-height:13px">${xstack([Q.q,Qn.q],qa,7)}</div><span class="m" style="font-size:9.5px">Last 24h</span></div>
<div class="row" style="position:absolute;left:16px;right:16px;top:116px;gap:7px;opacity:${xms_f(R.o)};transform:translateY(${xms_f(R.y)}px)"><i style="display:block;width:2px;height:15px;border-radius:1px;background:${xms_GA};flex:none"></i><span style="font-size:11px;font-weight:500;color:#FFFFFF">${typeIn(ans.slice(0,nch),tl,20)}<span style="opacity:${xms_f(clamp(tl/.3)*(1-soft(clamp((tl-tdone-.8)/.5))))}">${caret(T,xms_GA,11)}</span></span></div>
</div>`}};

// =====================================================================================
// midjourney: four previews resolve from blur as the job rolls to 100%, U1-U4 fade in, one springs up to upscale.
const xms_MP=12;
const xms_MJ=[
 {p:'chrome dunes at dusk, soft haze',u:2,c:[['#FF9A62','#7A3CFF','#1A1440','#FFE2A8'],['#3EE6C8','#3A66FF','#FF7AD9','#0E1030'],['#FFC7A1','#FF5E7A','#3B1E5E','#FFE9D6'],['#FFB38A','#6A7BFF','#1C1F3A','#C9D6FF']]},
 {p:'neon tide pools, film grain',u:1,c:[['#5CF2FF','#2B4BFF','#08122E','#FF7AB8'],['#FFD36B','#FF4F7B','#6C3CFF','#160A24'],['#7CF7B6','#1E8C8C','#0A1E2A','#E4FFF4'],['#FF8F6B','#B04BFF','#2A0F3A','#FFD8C2']]}];
// progress keys start right after the short Queued beat (the next prompt is typed during the previous reset)
const xms_MK=[[0,0],[.5,4],[1.15,19],[1.85,34],[2.6,47],[3.35,61],[4.1,73],[4.85,86],[5.5,90],[6.15,100]];
function xms_art(i,c,T){const s=Math.sin,z='rgba(0,0,0,0)';
 if(i===0)return `radial-gradient(circle at 50% ${(57+2*s(T*.7)).toFixed(2)}%,${c[3]} 0 17%,${z} 19%),repeating-linear-gradient(180deg,${z} 0 4px,rgba(0,0,0,.24) 4px 6px) 0 100%/100% 40% no-repeat,linear-gradient(180deg,${c[1]} 0%,${c[0]} 55%,${c[2]} 100%)`;
 if(i===1)return `radial-gradient(60% 50% at ${(30+8*s(T*.6)).toFixed(2)}% 32%,${c[0]},${z}),radial-gradient(55% 55% at 74% ${(68+8*s(T*.5+1)).toFixed(2)}%,${c[1]},${z}),radial-gradient(48% 42% at 72% 18%,${c[2]},${z}),${c[3]}`;
 if(i===2){const ph=-md(T*3.2,10);return `linear-gradient(160deg,${z} 35%,${c[2]} 100%),repeating-radial-gradient(circle at 34% 64%,${c[0]} ${ph.toFixed(2)}px,${c[1]} ${(ph+5).toFixed(2)}px,${c[0]} ${(ph+10).toFixed(2)}px)`}
 return `radial-gradient(130% 62% at ${(18+4*s(T*.5)).toFixed(2)}% 106%,${c[0]} 0 40%,${z} 41.5%),radial-gradient(130% 60% at 86% 114%,${c[1]} 0 45%,${z} 46.5%),radial-gradient(circle at 70% 30%,${c[3]} 0 9%,${z} 10.5%),linear-gradient(180deg,${c[2]},${c[3]} 140%)`}

W.midjourney=(T,w)=>{
 const P=xms_MP,k=Math.floor(T/P),l=T-k*P,J=xms_MJ[md(k,2)],Jn=xms_MJ[md(k+1,2)];
 const e=morph(T,P,6.2,10.55);const h=mix(130,156,e);
 const rs=soft(seg(l,10.75,11.6));            // reset driver
 const x=kf(l,[[0,0],[.25,0],[.65,1],[6.3,1],[6.8,2],[8.2,2],[8.7,3],[10.75,3],[11.4,4]]);
 const qd=`Queued&nbsp;&nbsp;${dots(T,'#8E8E93',3,2.5)}`;const it=[qd,shimmer('Imagining',T,'#6E6E76','#FFFFFF',.8),'Pick one',`Upscaling U${J.u+1}`,qd];
 const K=xms_MK.concat([[10.8,0]]);
 const cs=spring(seg(l,8.1,9))*(1-rs),hb=soft(seg(l,8.1,8.6))*(1-rs);
 const S=46,gp=(204-4*S)/3;
 // palette crossfades to the next job during the reset
 const pal=i=>J.c[i].map((a,j)=>hexmix(a,Jn.c[i][j],rs));
 let tiles='',btns='',bmx=0;
 for(let i=0;i<4;i++){const q=clamp(xms_step(l-i*.09,xms_MK,.6)/100)*(1-rs);const qe=smooth(q);
  const ch=i===J.u;const dim=ch?1:1-.5*cs;const sc=ch?1+.07*cs:1,ty=ch?-2.5*cs:0;
  const sw=ch&&cs>.01?(1.6*clamp(cs*1.4)).toFixed(2):0;
  const shp=seg(l,8.6,10.2),sx=-70+md(shp*2.2,1)*140,so=ch?Math.sin(Math.PI*clamp(md(shp*2.2,1)))*clamp((l-8.6)/.3)*(1-soft(seg(l,10,10.4))):0;
  tiles+=`<div style="position:absolute;left:${(i*(S+gp)).toFixed(2)}px;top:0;width:${S}px;height:${S}px;border-radius:9px;overflow:hidden;background:#131317;opacity:${xms_f(dim)};transform:translateY(${xms_f(ty)}px) scale(${(sc).toFixed(4)});box-shadow:0 0 0 ${sw}px ${xms_MA}"><div style="position:absolute;inset:0;background:${xms_art(i,pal(i),T)};opacity:${xms_f(.22+.78*qe+(1-qe)*.07*Math.sin(T*2.6+i*1.4))};filter:blur(${(9*Math.pow(1-qe,1.25)).toFixed(2)}px) saturate(${(.55+.45*qe).toFixed(3)});transform:scale(${(1.28-.28*qe).toFixed(4)})"></div>${(1-qe)>.03?`<div style="position:absolute;left:0;top:0;width:${S}px;height:${S}px;opacity:${xms_f(Math.pow(1-qe,2))};background:linear-gradient(100deg,rgba(255,255,255,0) 25%,rgba(255,255,255,.11) 50%,rgba(255,255,255,0) 75%);transform:translateX(${(md(T*110,330)-70-i*(S+gp)-S/2).toFixed(2)}px)"></div>`:''}${so>.002?`<div style="position:absolute;left:-20px;top:-20px;width:86px;height:86px;opacity:${xms_f(so)};background:linear-gradient(105deg,rgba(255,255,255,0) 38%,rgba(255,255,255,.38) 50%,rgba(255,255,255,0) 62%);transform:translateX(${sx.toFixed(2)}px)"></div>`:''}</div>`;
  const bo=soft(seg(l,6.4+i*.08,6.95+i*.08))*(1-soft(seg(l,10.28,10.68)));bmx=Math.max(bmx,bo);const hbi=ch?hb:0;const bs=ch?1+.08*Math.sin(Math.PI*clamp((l-8.1)/.45))*(l>8.1?1:0):1;
  const up=ch?ease3(seg(l,8.55,9.9)):0;const fl=ch?Math.sin(Math.PI*seg(l,9.85,10.3)):0;
  if(bo>.002)btns+=`<div class="row" style="position:absolute;left:${(i*(S+gp)).toFixed(2)}px;top:0;width:${S}px;height:19px;border-radius:7px;overflow:hidden;justify-content:center;background:${hexmix('#1C1C20','#2A2342',hbi)};color:${hexmix('#C7C7CC','#FFFFFF',hbi)};font-size:9.5px;font-weight:600;opacity:${xms_f(bo)};transform:translateY(${xms_f((1-bo)*5)}px) scale(${bs.toFixed(4)})">${up>0?`<i style="position:absolute;inset:0;background:${rgba(xms_MA,.62+.38*fl)};transform:translateX(${((up-1)*S).toFixed(3)}px)"></i>`:''}<span style="position:relative">U${i+1}</span></div>`}
 // prompt row: this job's prompt stays up; during the reset it fades and the next job's prompt types in,
 // finishing before the wrap so the new cycle starts with it already in place
 const po=1-soft(seg(l,10.6,10.95)),tn=l-11,pnx=Jn.p;
 const prm=(po>.002?`<span style="position:absolute;left:0;top:0;opacity:${xms_f(po)};transform:translateY(${xms_f(-4*(1-po))}px)">${typeIn(J.p,99,36)}</span>`:'')
  +(tn>0?`<span style="position:absolute;left:0;top:0">${typeIn(pnx,tn,36)}</span>`:'');
 return {h,html:`<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${tile(MK.midjourney(17,T),'#1C1C20',30)}<div style="line-height:1.25;flex:1"><div class="m">Midjourney · v7</div><div data-xs style="position:relative;height:17px;font-size:13px;font-weight:600">${xstack(it,x,8)}</div></div>
<div data-xh style="font-size:22px;font-weight:600;color:${xms_MA};letter-spacing:-.6px">${xms_rk(l,K,v=>v+'%',.6)}</div></div>
<div class="row" style="position:absolute;left:16px;right:16px;top:52px;height:12px;font-size:9.5px;font-weight:500;color:#8E8E93"><span style="color:#FFFFFF;font-weight:600">/imagine</span><div style="position:relative;flex:1;height:12px;margin-left:4px">${prm}</div></div>
<div style="position:absolute;left:16px;top:70px;width:204px;height:${S}px">${tiles}</div>
${bmx>.05?`<div style="position:absolute;left:16px;top:${S+77}px;width:204px;height:19px">${btns}</div>`:''}
</div>`}};

// =====================================================================================
// suno: two versions of a song stream in left to right, then Ready, then v1 plays with a playhead and equalizer.
const xms_SP=12,xms_SN=30;
const xms_SS=[
 {t:'Neon Harbor',g:['synthwave','female vocals'],c:[['#FF9A3D','#FF3D7F'],['#7A5CFF','#FF4FA3']],sd:[.3,2.9]},
 {t:'Paper Planets',g:['indie pop','male vocals'],c:[['#FFC247','#FF5E62'],['#3DD6FF','#7A5CFF']],sd:[5.2,7.7]}];
// percent keys start almost at once so the fresh song is never a still placeholder
const xms_SK=[[0,0],[.4,4],[1.05,16],[1.7,29],[2.35,42],[3,56],[3.65,70],[4.3,82],[4.9,95],[5.3,100]];
const xms_amp=(i,sd)=>{const env=.5+.5*smooth(i/7);return clamp((.3+.7*Math.abs(noise(i*.63+sd)))*env+.06*Math.sin(i*1.9+sd))};
// waveform: g(i) growth 0..1 per bar, glow near the writing front, played part filled up to px
function xms_wave(sd,F,px,rs,T,live){const n=xms_SN,pt=4.6,bw=2.4,H=22;let s='';
 for(let i=0;i<n;i++){const g=soft(clamp((F-i)/3))*(1-soft(clamp((rs*(n+8)-(n-1-i))/6)));const a=xms_amp(i,sd);
  const wob=live?1+.12*Math.sin(T*7+i*1.3)*clamp(1-Math.abs(i*pt-px)/22):1;const hh=2+g*a*(H-2)*wob;const y=(H-hh)/2;const xi=i*pt;
  const glow=clamp(1-(F-i-1)/5)*clamp(F-i);const base=hexmix('#3C3C43',xms_hx(xms_SA,xms_SB,i/n),glow*.9);
  s+=`<rect x="${xi.toFixed(1)}" y="${y.toFixed(2)}" width="${bw}" height="${hh.toFixed(2)}" rx="1.2" fill="${base}"/>`;
  const f=clamp((px-xi)/bw);if(f>0)s+=`<rect x="${xi.toFixed(1)}" y="${y.toFixed(2)}" width="${(bw*f).toFixed(3)}" height="${hh.toFixed(2)}" rx="${(1.2*Math.min(1,f*2)).toFixed(2)}" fill="${hexmix(xms_SA,xms_SB,i/n)}"/>`}
 return s}

W.suno=(T,w)=>{
 const P=xms_SP,k=Math.floor(T/P),l=T-k*P,S=xms_SS[md(k,2)],Sn=xms_SS[md(k+1,2)];
 const rs=soft(seg(l,11,11.8));
 const x=kf(l,[[0,0],[5.5,0],[6,1],[6.45,1],[6.95,2],[11,2],[11.6,3]]);
 const it=[shimmer('Creating',T,'#6E6E76','#FFFFFF',.9),`<span style="display:inline-flex;align-items:center;gap:4px">${tick(soft(seg(l,5.6,6.1)),xms_SA,10,3.4)}Ready</span>`,`<span style="color:#FFFFFF">Playing v1</span>`,shimmer('Creating',T,'#6E6E76','#FFFFFF',.9)];
 const rdy=spring(seg(l,5.7,6.5))*(1-rs),rdo=soft(seg(l,5.7,6.2))*(1-rs);
 const pl=soft(seg(l,6.35,6.85))*(1-soft(seg(l,10.9,11.5)));
 const ph=seg(l,6.6,11.1),px=138*.42*(ph*.9+.1*smooth(ph));
 const ta=soft(seg(l,11.1,11.8));
 const hx=kf(l,[[0,0],[5.95,0],[6.6,1],[10.8,1],[11.5,2]]);
 const t0=clamp(l-6.6,0,4.9),tn=Math.floor(t0);
 const K=xms_SK.concat([[10.45,0]]);
 const tg=g=>g.map(s=>`<span style="font-size:9px;font-weight:600;color:#A1A1A8;background:#1C1C20;border-radius:6px;padding:2px 6px">${s}</span>`).join('<span style="display:inline-block;width:5px"></span>');
 const rows=[0,1].map(v=>{const u=seg(l,.12+v*.35,4.75+v*.35),F=(xms_SN+4)*(.45*u+.55*smooth(u));const c=S.c[v].map((a,j)=>hexmix(a,Sn.c[v][j],ta));
  const fv=clamp(F/(xms_SN+4));const play=v===0?pl:0;const dim=v===1?1-.4*pl:1;
  const eq=play<=.002?'':[0,1,2].map(i=>{const q=.25+.75*Math.abs(Math.sin(T*(3.4+i*.9)+i*1.7)*Math.cos(T*(1.1+i*.4)+i));return `<i style="display:block;width:2.4px;height:${(3+q*9).toFixed(2)}px;border-radius:1.2px;background:#FFFFFF"></i>`}).join('');
  const spin=rdo>.998?'':`<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${xms_f(1-rdo)}">${ring(fv*(1-rs),18,2.4,xms_SA,'#2A2A2E')}</div>`;
  const btn=rdo<=.002?'':`<div style="position:absolute;inset:0;border-radius:50%;background:#1C1C20;opacity:${xms_f(rdo)};transform:scale(${(.6+.4*rdy).toFixed(4)})">${play>.002?`<div style="position:absolute;inset:0;border-radius:50%;background:linear-gradient(135deg,${xms_SA},${xms_SB});opacity:${xms_f(play)}"></div><div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${xms_f(play)}">${ico('pause','#FFFFFF',11)}</div>`:''}${play<.998?`<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${xms_f(1-play)};padding-left:1.5px">${ico('play','#FFFFFF',11)}</div>`:''}</div>`;
  return `<div class="row" style="position:absolute;left:16px;right:16px;top:${72+v*33}px;height:26px;gap:8px;opacity:${xms_f(dim)}">
<div style="position:relative;width:26px;height:26px;border-radius:7px;overflow:hidden;flex:none;background:linear-gradient(${(135+T*10+v*60).toFixed(1)}deg,${c[0]},${c[1]})"><i style="position:absolute;right:-6px;bottom:-6px;width:18px;height:18px;border-radius:50%;border:4px solid rgba(255,255,255,.22)"></i><div style="position:absolute;inset:0;background:rgba(5,5,6,.5);opacity:${xms_f((1-rdo)*.9+play*.6)}"></div><div class="row" style="position:absolute;inset:0;justify-content:center;align-items:flex-end;padding-bottom:6px;gap:2px;opacity:${xms_f(play)}">${eq}</div></div>
<div style="position:relative;width:138px;height:22px;flex:none"><svg width="138" height="22" style="position:absolute;left:0;top:0;overflow:visible">${xms_wave(S.sd[v],F,v===0?px*pl+(pl<1?0:0):-1,rs,T,play>.5)}${play>.002?`<rect x="${(px-.75).toFixed(3)}" y="-2" width="1.5" height="26" rx=".75" fill="#FFFFFF" opacity="${xms_f(play)}"/>`:''}</svg></div>
<span class="sp"></span><div style="position:relative;width:24px;height:24px;flex:none">${spin}${btn}</div></div>`}).join('');
 return {h:144,html:`<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${tile(MK.suno(18,T),rgba(xms_SA,.15),30)}<div style="line-height:1.25;flex:1"><div class="m" data-xs style="position:relative;height:13px">${xstack(it,x,7)}</div><div data-xs style="position:relative;height:17px;font-size:13px;font-weight:600">${xstack([S.t,Sn.t],ta,8)}</div></div>
<div data-xh style="position:relative;width:62px;height:27px;font-size:22px;font-weight:600;color:${xms_SA};letter-spacing:-.6px;text-align:right">${(()=>{const pc=xms_rk(l,K,v=>v+'%',.6);return xstack([pc,roll2(mmss(Math.max(0,tn-1)),mmss(tn),t0-tn,.45),pc],hx,10)})()}</div></div>
<div style="position:absolute;left:16px;right:16px;top:51px;height:16px">${xstack([S,Sn].map(o=>`<div class="row">${tg(o.g)}<span class="sp"></span><span class="m" style="font-size:9.5px">v4.5</span></div>`),ta,6)}</div>
${rows}
</div>`}};

// =====================================================================================
// pills
W.p_grok=T=>({h:50,html:pill(`<span style="display:inline-flex;transform:rotate(${(Math.sin(T*1.3)*10).toFixed(2)}deg)">${MK.grok(17,T)}</span>`,xms_GA,rollL(T,2.3,.7,[1.2,1.6,1.9,2.4,2.8,3.1],v=>v.toFixed(1)+'k')+'<span style="font-size:10.5px;margin-left:3px">posts</span>')});
W.p_mj=T=>{const V=[12,27,41,55,70,85,100],S=st2(T,1.5,.4),a=V[md(S.k-1,7)],b=V[md(S.k,7)];let val,hop=0;
 if(b>=a)val=roll2(a+'%',b+'%',S.l,.4);
 else{const q=soft(clamp(S.l/.55)),oo=clamp(1-q*2.2),on=clamp(q*2.2-1.2);hop=Math.sin(Math.PI*clamp(S.l/.5))*(S.l<.5?1:0);
  val=`<span style="position:relative;display:inline-block"><span style="display:inline-block;opacity:${xms_f(on)};transform:translateY(${xms_f((1-q)*7)}px)">${b}%</span>${oo>.001?`<span style="position:absolute;right:0;top:0;opacity:${xms_f(oo)};transform:translateY(${xms_f(-q*7)}px)">${a}%</span>`:''}</span>`}
 return {h:50,html:pill(`<span style="display:inline-flex;transform:translateY(${(Math.sin(T*1.7)*1.3-3*hop).toFixed(2)}px) rotate(${(Math.sin(T*1.7+.7)*5).toFixed(2)}deg)">${MK.midjourney(17,T)}</span>`,xms_MA,val)}};
