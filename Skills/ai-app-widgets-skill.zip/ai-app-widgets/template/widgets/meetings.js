// widgets/meetings.js: Notion AI Meeting Notes, Slack huddle, ElevenLabs text to speech. Every top-level name here starts with mtg_.
const mtg_RED = '#FF453A', mtg_GRN = '#2BAC76', mtg_LIL = '#CDBBFF';
const mtg_hx = (a, b, p) => '#' + [1, 3, 5].map(i => Math.round(mix(parseInt(a.substr(i, 2), 16), parseInt(b.substr(i, 2), 16), clamp(p))).toString(16).padStart(2, '0')).join('');
const mtg_f = (v, d = 3) => (+v).toFixed(d);
// layered text states: L = [[html, in 0..1, out 0..1], ...]. Incoming rises from below, outgoing leaves upward.
// The outgoing layer is gone (driver .45) before the incoming one starts (.55), so two labels never overlap.
const mtg_lay = (L, dy = 7, style = '') => L.map(([s, a, b]) => {
  const o = clamp(a * 2.2 - 1.2) * clamp(1 - b * 2.2); if (o <= .001) return '';
  return `<div style="position:absolute;left:0;top:0;right:0;opacity:${mtg_f(o)};transform:translateY(${mtg_f((1 - a) * dy - b * dy, 2)}px);white-space:nowrap;${style}">${s}</div>`;
}).join('');
// stepped value with a roll at each key: K = [[time, value], ...]
function mtg_steps(l, K, fmt, dur = .5) {
  let i = 0; while (i < K.length - 1 && l >= K[i + 1][0]) i++;
  if (i === 0) return roll2(fmt(K[0][1]), fmt(K[0][1]), 9, dur);
  return roll2(fmt(K[i - 1][1]), fmt(K[i][1]), l - K[i][0], dur);
}
// odometer clock that never shows a negative first roll
const mtg_tick = (x, fmt) => x < 1 ? roll2(fmt(0), fmt(0), 9) : tickUp(x, fmt);
// clock that starts at l0, counts 1 per 1/rate s and stops at max; the last tick still finishes its roll
function mtg_clk(l, l0, rate, max, fmt, dur = .45) {
  const x = (l - l0) * rate; if (x < 1) return roll2(fmt(0), fmt(0), 9, dur);
  const n = Math.min(max, Math.floor(x)); return roll2(fmt(n - 1), fmt(n), l - (l0 + n / rate), dur);
}
// one-shot press: 0 -> 1 -> 0 over [a, b]
const mtg_bump = (l, a, b) => Math.sin(Math.PI * seg(l, a, b));

// ---------- brand marks (own simple glyphs)
// Notion: a bold N in a white rounded square with a black inner outline
MK.notion = (s = 16, T = 0) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none"><rect x="2.2" y="2.2" width="19.6" height="19.6" rx="5" fill="#FFFFFF"/><rect x="4" y="4" width="16" height="16" rx="3.4" fill="none" stroke="#0B0B0C" stroke-width="1.5"/><path d="M8.6 16.4V7.6L15.4 16.4V7.6" fill="none" stroke="#0B0B0C" stroke-width="2.5" stroke-linejoin="miter" stroke-linecap="square"/></svg>`;
// Slack: a woven hash of four coloured rounded bars
MK.slack = (s = 16, T = 0) => {
  const bar = (d, c) => `<path d="${d}" stroke="#050506" stroke-width="5.4" stroke-linecap="round"/><path d="${d}" stroke="${c}" stroke-width="3.4" stroke-linecap="round"/>`;
  return `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" style="flex:none">${bar('M4.6 15H19.4', '#E01E5A')}${bar('M15 4.6V19.4', '#ECB22E')}${bar('M4.6 9H19.4', '#2EB67D')}${bar('M9 4.6V19.4', '#36C5F0')}<path d="M7 15H11" stroke="#050506" stroke-width="5.4"/><path d="M6.6 15H11.4" stroke="#E01E5A" stroke-width="3.4"/></svg>`;
};
// ElevenLabs: two upright bars
MK.eleven = (s = 16, T = 0, c = '#FFFFFF') => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" style="flex:none"><rect x="7" y="3.5" width="3.6" height="17" rx="1.3" fill="${c}"/><rect x="13.4" y="3.5" width="3.6" height="17" rx="1.3" fill="${c}"/></svg>`;

// ---------- Notion AI Meeting Notes: transcribing -> summarizing -> action items
const mtg_NT = [['Ship pricing page Fri', 'M', '#F2F2F4', '#A9A9B0'], ['Draft onboarding emails', 'L', '#F2F2F4', '#A9A9B0'], ['Book user tests Tue', 'A', '#F2F2F4', '#A9A9B0']];
W.notion = (T, w) => {
  const P = 12, { k, l } = st(T, P, 0);
  const e = spring(clamp((l - 6.25) / .9)) - spring(clamp((l - 10.82) / .9));
  const h = mix(112, 148, e);
  // recording state: dot pulses and the clock runs only while recording
  const rec = 1 - soft(seg(l, 4.4, 4.8)) + soft(seg(l, 11.2, 11.6));
  const secs = 1452 + k * 5.2 + Math.min(l, 4.6) + Math.max(0, l - 11.4);
  const pu = md(T * .85, 1);
  const dot = `<div style="position:relative;width:9px;height:9px;flex:none"><i style="position:absolute;inset:0;border-radius:50%;background:${mtg_RED};opacity:${mtg_f((1 - pu) * .45 * rec)};transform:scale(${mtg_f(1 + 1.3 * soft(pu))})"></i><i style="position:absolute;inset:0;border-radius:${mtg_f(mix(2.2, 4.5, rec), 2)}px;background:${mtg_hx('#6E6E76', mtg_RED, rec)};transform:scale(${mtg_f(mix(.86, 1, rec))})"></i></div>`;
  const clock = `<span style="font-size:15px;font-weight:600;letter-spacing:-.2px;color:${mtg_hx('#8E8E93', '#FFFFFF', rec)}">${tickUp(secs, mmss)}</span>`;
  // state weights
  const aB = soft(seg(l, 4.55, 5.0)), aC = soft(seg(l, 6.25, 6.7)), aR = soft(seg(l, 11.05, 11.5));
  const left = mtg_lay([
    [`<span style="color:#C7C7CC">Transcribing</span>&nbsp;&nbsp;${dots(T, '#6E6E76', 3, 2.5)}`, 1, aB],
    [shimmer('Summarizing', T, '#5A5A61', '#FFFFFF', .9, 4), aB, aC],
    [`<span style="color:#E5E5EA">Action items</span>`, aC, aR],
    [`<span style="color:#C7C7CC">Transcribing</span>&nbsp;&nbsp;${dots(T, '#6E6E76', 3, 2.5)}`, aR, 0]
  ], 6, 'font-size:10.5px;font-weight:600;display:flex;align-items:center;height:14px');
  // right side: who is talking / summary progress / tasks done
  const spk = ['Mara', 'Leo', 'Ava'];
  const sA = i => i === 0 ? 1 : soft(seg(l, i * 1.5 - .2, i * 1.5 + .2)), sO = i => i === 2 ? aB : soft(seg(l, (i + 1) * 1.5 - .2, (i + 1) * 1.5 + .2));
  const right = mtg_lay([
    ...spk.map((n, i) => [`${n}`, sA(i), sO(i)]),
    [mtg_steps(l, [[0, 0], [5.05, 18], [5.4, 46], [5.75, 73], [6.1, 100]], v => v + '%'), aB, aC],
    [`<span style="color:#FFFFFF;font-weight:600">${mtg_steps(l, [[0, 0], [8.95, 1], [9.75, 2]], String)}</span>/3 done`, aC, aR],
    ['Mara', aR, 0]
  ], 6, 'text-align:right;font-size:10.5px;font-weight:500;color:#8E8E93;height:14px');
  // live waveform: recorded bars scroll left, newest on the right
  const col = soft(seg(l, 4.45, 5.0)) * (1 - soft(seg(l, 11.25, 11.9)));
  const wO = 1 - soft(seg(l, 4.85, 5.25)) + soft(seg(l, 11.15, 11.5));
  let wv = '';
  if (wO > .002) {
    const sx = T * 17, n0 = Math.floor(sx / 5);
    for (let j = n0; j < n0 + 43; j++) {
      const x = j * 5 - sx; if (x < -3 || x > 204) continue;
      const v = (.12 + .88 * Math.abs(noise(j * .53))) * (.4 + .6 * smooth(.5 + .5 * Math.sin(j * .19 + 1.1)));
      const hh = 2.4 + v * 22 * (1 - col);
      const o = clamp(x / 26) * clamp((204 - x) / 5);
      wv += `<i style="position:absolute;left:0;top:50%;width:2.4px;height:${mtg_f(hh, 2)}px;margin-top:${mtg_f(-hh / 2, 2)}px;border-radius:2px;background:${mtg_hx('#3E3E44', '#FFFFFF', Math.pow(clamp(x / 204), 1.4))};transform:translateX(${mtg_f(x, 2)}px);opacity:${mtg_f(o)}"></i>`;
    }
  }
  const wave = wO <= .002 ? '' : `<div style="position:absolute;left:16px;right:16px;top:74px;height:26px;opacity:${mtg_f(clamp(wO))}">${wv}</div>`;
  // skeleton lines with a sweeping highlight while summarizing
  const kO = soft(seg(l, 4.95, 5.35)) * (1 - soft(seg(l, 6.2, 6.5)));
  const sw = md(T * 170, 330) - 70;
  const skl = (top, ww, d) => `<div style="position:absolute;left:0;top:${top}px;width:${ww}px;height:7px;border-radius:3.5px;background:#1C1C20;overflow:hidden;transform-origin:0 50%;transform:scaleX(${mtg_f(.08 + .92 * smooth(seg(l, 4.95 + d / 40, 5.75 + d / 40)))})"><i style="position:absolute;left:0;top:0;width:70px;height:7px;background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,.22),rgba(255,255,255,0));transform:translateX(${mtg_f(sw - d, 2)}px)"></i></div>`;
  const skel = kO <= .002 ? '' : `<div style="position:absolute;left:16px;right:16px;top:77px;height:22px;opacity:${mtg_f(kO)};transform:translateY(${mtg_f((1 - kO) * 3, 2)}px)">${skl(0, 204, 0)}${skl(13, 138, 18)}</div>`;
  // action items
  let items = '';
  mtg_NT.forEach(([s, L, c1, c2], i) => {
    const t0 = 6.35 + i * .42, tc = [8.95, 9.75, 99][i]; // items arrive quickly so the opened card is never a blank sheet
    const o = soft(seg(l, t0, t0 + .35)) * (1 - soft(seg(l, 10.6 + i * .06, 10.9 + i * .06)));
    if (o <= .002) return;
    const y = i * 21 + (1 - spring(seg(l, t0, t0 + .8))) * 7 - soft(seg(l, 10.6, 10.95)) * 4;
    const bs = .55 + .45 * spring(seg(l, t0, t0 + .7));
    const ck = soft(seg(l, tc, tc + .25)), cs = 1 - .14 * mtg_bump(l, tc - .05, tc + .3);
    const box = `<div style="position:relative;width:13px;height:13px;border-radius:4px;box-shadow:inset 0 0 0 1.4px ${mtg_hx('#5A5A61', '#FFFFFF', ck)};background:${mtg_hx('#050506', '#FFFFFF', ck)};transform:scale(${mtg_f(bs * cs)});flex:none;display:flex;align-items:center;justify-content:center">${ck > .01 ? tick(clamp((l - tc - .08) / .3), '#050506', 10, 3.6) : ''}</div>`;
    const txt = `<span style="position:relative;display:inline-block;color:${mtg_hx('#ECECEF', '#6E6E76', ck)}">${typeIn(s, l - t0 - .1, 34, .12)}<i style="position:absolute;left:0;right:0;top:52%;height:1.3px;border-radius:1px;background:#6E6E76;transform-origin:0 50%;transform:scaleX(${mtg_f(soft(seg(l, tc + .1, tc + .45)))})"></i></span>`;
    const as = spring(seg(l, t0 + .3, t0 + 1));
    items += `<div class="row" style="position:absolute;left:0;right:0;top:0;height:16px;gap:8px;opacity:${mtg_f(o)};transform:translateY(${mtg_f(y + 2, 2)}px)">${box}<span style="font-size:11px;font-weight:500">${txt}</span><span class="sp"></span><div style="transform:scale(${mtg_f(as)});opacity:${mtg_f(clamp(as * 2))}">${av(L, c1, c2, 16)}</div></div>`;
  });
  const list = items ? `<div style="position:absolute;left:16px;right:16px;top:72px;height:${mtg_f(Math.max(0, h - 82), 2)}px;overflow:hidden">${items}</div>` : '';
  return {
    h, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${tile(MK.notion(19, T), '#1A1A1D', 30)}<div style="line-height:1.25"><div class="m">Meeting notes</div><div style="font-size:13px;font-weight:600">Design sync</div></div><span class="sp"></span><div class="row" style="gap:7px">${dot}${clock}</div></div>
<div class="row" style="position:absolute;left:16px;right:16px;top:55px;height:14px"><div style="position:relative;flex:1;height:14px">${left}</div><div style="position:relative;width:76px;height:14px">${right}</div></div>
${wave}${skel}${list}</div>`
  };
};

// ---------- Slack huddle: speaking ring moves between people, toasts slide in, mute toggles
const mtg_PP = [['M', 'Mara', '#FFD8A8', '#FF8A65'], ['L', 'Leo', '#A8D8FF', '#5B8DEF'], ['A', 'Ava', '#E0CCFF', '#9A7BFF'], ['N', 'Noah', '#C4F1D6', '#46B98A']];
const mtg_SEQ = [0, 2, 1, 2, 0, 1];
const mtg_MSG = [[2, 'shipped it'], [1, 'deploy is green'], [0, 'changelog is live']];
W.slack = (T, w) => {
  const A = mtg_GRN;
  const SP = 2.6, { k, l } = st(T, SP, 0);
  const cur = mtg_SEQ[md(k, 6)], prv = mtg_SEQ[md(k - 1, 6)], q = soft(clamp(l / .5));
  const wt = i => (i === cur ? q : 0) + (i === prv ? 1 - q : 0);
  const dd = Math.min(l, SP - l);
  const amp = clamp(.55 + .42 * noise(T * 3.4 + 1.7)) * (1 - .6 * Math.exp(-Math.pow(dd / .32, 2)));
  // toast cycle
  const TP = 6.4, tk = st(T, TP, 0).k, e = morph(T, TP, 1.3, 4.7);
  const h = mix(98, 134, e);
  // mute cycle
  const ml = st(T, 12, 0).l;
  const mu = soft(seg(ml, 7.3, 7.6)) - soft(seg(ml, 10.6, 10.9));
  const mp = 1 - .12 * mtg_bump(ml, 7.15, 7.6) - .12 * mtg_bump(ml, 10.45, 10.9);
  const avs = mtg_PP.map(([L, n, c1, c2], i) => {
    const wi = wt(i), sc = 1 + .05 * wi * amp;
    const muted = i === 3 ? `<div style="position:absolute;right:-4px;bottom:-4px;width:14px;height:14px;border-radius:50%;background:#2A2A2E;box-shadow:0 0 0 2px #050506;display:flex;align-items:center;justify-content:center">${ico('micOff', '#C7C7CC', 8.5, 2.4)}</div>` : '';
    return `<div style="position:relative;width:26px;height:26px;flex:none">
<i style="position:absolute;inset:0;border-radius:50%;background:${rgba(A, .3)};opacity:${mtg_f(wi * (.2 + .8 * amp))};transform:scale(${mtg_f(1.18 + .42 * amp)})"></i>
<i style="position:absolute;inset:-3.5px;border-radius:50%;box-shadow:inset 0 0 0 2px ${A};opacity:${mtg_f(wi)};transform:scale(${mtg_f(1 + .045 * amp * wi)})"></i>
<div style="position:absolute;inset:0;transform:scale(${mtg_f(sc)})">${av(L, c1, c2, 26)}</div>${muted}</div>`;
  }).join('');
  const eq = `<span style="display:inline-flex;align-items:center;gap:1.6px;height:10px;margin-right:4px">${[0, 1, 2].map(i => { const v = clamp(.25 + .75 * amp * Math.abs(Math.sin(T * (5.2 + i * 1.3) + i * 1.9))); return `<i style="display:block;width:2px;height:9px;border-radius:1px;background:${A};transform:scaleY(${mtg_f(.3 + .7 * v)})"></i>`; }).join('')}</span>`;
  const nm = mtg_lay([[mtg_PP[prv][1], 1, q], [mtg_PP[cur][1], q, 0]], 6, 'color:#E5E5EA;font-weight:600');
  const btn = (inner, bg, s = 1) => `<div style="position:relative;width:26px;height:26px;border-radius:50%;background:${bg};flex:none;display:flex;align-items:center;justify-content:center;transform:scale(${mtg_f(s)})">${inner}</div>`;
  const mic = `<span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${mtg_f(1 - mu)}">${ico('mic', '#FFFFFF', 13, 2.2)}</span><span style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${mtg_f(mu)}">${ico('micOff', '#050506', 13, 2.2)}</span>`;
  const leave = `<span style="display:inline-flex;transform:rotate(135deg)">${ico('phone', '#FFFFFF', 12)}</span>`;
  const [ai, msg] = mtg_MSG[md(tk, 3)], pp = mtg_PP[ai];
  // the toast only shows once the card is nearly open, so its text is never seen cut by the growing mask
  const tO = clamp((e - .72) * 3.6);
  const toast = tO <= .002 ? '' : `<div style="position:absolute;left:16px;right:16px;top:92px;height:${mtg_f(Math.max(0, h - 100), 2)}px;overflow:hidden"><div class="row" style="position:absolute;left:0;right:0;top:2px;height:28px;border-radius:14px;background:#141416;box-shadow:inset 0 0 0 .6px rgba(255,255,255,.06);padding:0 10px 0 5px;gap:7px;opacity:${mtg_f(tO)};transform:translateY(${mtg_f((1 - e) * 14, 2)}px)">${av(pp[0], pp[2], pp[3], 18)}<span style="font-size:11px;font-weight:600">${pp[1]}</span><span style="font-size:11px;font-weight:500;color:#B9B9BF;margin-left:-3px">${msg}</span><span class="sp"></span><span class="m" style="font-size:9.5px">now</span></div></div>`;
  return {
    h, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${tile(MK.slack(18, T), '#1A1A1D', 30)}<div style="line-height:1.25"><div style="font-size:13px;font-weight:600">#launch-week</div><div class="m" style="display:flex;align-items:center">Huddle&nbsp;·&nbsp;${eq}<span style="position:relative;display:inline-block;width:40px;height:13px">${nm}</span></div></div><span class="sp"></span><span style="font-size:15px;font-weight:600;color:${A}">${tickUp(760 + T, mmss)}</span></div>
<div class="row" style="position:absolute;left:16px;right:16px;top:57px;height:26px"><div class="row" style="gap:8px">${avs}</div><span class="sp"></span><div class="row" style="gap:7px">${btn(mic, mtg_hx('#1F1F23', '#FFFFFF', mu), mp)}${btn(leave, '#E5484D')}</div></div>
${toast}</div>`
  };
};

// ---------- ElevenLabs text to speech: generate (waveform renders, characters roll) -> speak (karaoke + playhead) -> ready
const mtg_L1 = 'The rain stopped, and the city', mtg_L2 = 'started humming a quiet tune.';
const mtg_TX = mtg_L1 + ' ' + mtg_L2, mtg_N = mtg_TX.length;
const mtg_WD = (() => { const r = []; let i = 0; for (const wd of mtg_TX.split(' ')) { r.push([i, i + wd.length]); i += wd.length + 1; } return r; })();
// characters counter keys: it rolls to the end of each word as the scan passes it (keys at least .3 s apart)
const mtg_CK = (() => { const K = [[0, 0]]; for (const [, b] of mtg_WD) { const t = .15 + (b + 4) / (mtg_N + 6) * 3.45; const close = K.length > 1 && t - K[K.length - 1][0] < .3; if (close && b < mtg_N) continue; if (close) K.pop(); K.push([t, b]); } K.push([11.25, 0]); return K; })();
const mtg_NB = 34;
const mtg_BV = [...Array(mtg_NB)].map((_, i) => clamp(.16 + .84 * Math.abs(noise(i * .71 + .4)) * (.5 + .5 * Math.pow(Math.sin(i * .37 + .6), 2)) + .12 * Math.sin(i * 1.9)));
const mtg_PAS = ['#A9C7FF', '#C9B8FF', '#F3B6E4', '#FFD2AE'];
const mtg_pas = u => { u = clamp(u) * 3; const i = Math.min(2, Math.floor(u)); return mtg_hx(mtg_PAS[i], mtg_PAS[i + 1], u - i); };
const mtg_orb = (s, T, amp = 0) => `<div style="position:relative;width:${s}px;height:${s}px;border-radius:50%;overflow:hidden;flex:none;background:#DCD6F2;transform:scale(${mtg_f(1 + .07 * amp)})"><div style="position:absolute;left:50%;top:50%;width:${s * 1.7}px;height:${s * 1.7}px;margin:${-s * .85}px 0 0 ${-s * .85}px;border-radius:50%;background:conic-gradient(from 0deg,#A9C7FF,#CDB6FF,#F6B2DA,#FFD3AE,#B6EEDC,#A9C7FF);filter:blur(${mtg_f(s * .13, 2)}px);transform:rotate(${mtg_f(T * 55)}deg)"></div><div style="position:absolute;left:50%;top:50%;width:${s * .9}px;height:${s * .9}px;margin:${-s * .45}px 0 0 ${-s * .45}px;border-radius:50%;background:radial-gradient(circle at 30% 30%,rgba(255,255,255,.8),rgba(255,255,255,0) 60%);transform:rotate(${mtg_f(-T * 80)}deg) translateX(${mtg_f(s * .08, 2)}px)"></div><div style="position:absolute;inset:0;border-radius:50%;box-shadow:inset 0 0 ${mtg_f(s * .2, 2)}px rgba(255,255,255,.55)"></div></div>`;
W.eleven = (T, w) => {
  const P = 12, { l } = st(T, P, 0);
  const g = seg(l, .15, 3.6);                                 // generation progress (steady)
  const gOn = 1 - soft(seg(l, 3.7, 4.1));
  const p = seg(l, 4.45, 10.25);                               // playback progress
  const pOn = soft(seg(l, 4.2, 4.5)) * (1 - soft(seg(l, 10.3, 10.7)));
  const fR = soft(seg(l, 11.15, 11.7));                        // reset
  const aS = soft(seg(l, 3.95, 4.35)), aD = soft(seg(l, 10.25, 10.65)), aR = soft(seg(l, 11.2, 11.65));
  const amp = pOn * clamp(.5 + .5 * noise(T * 4.3)) * (1 - p * 0) ;
  // header status
  const status = mtg_lay([
    [shimmer('Generating', T, '#6E6E76', '#FFFFFF', .9, 4), 1, aS],
    [`<span style="color:#E5E5EA">Speaking</span>`, aS, aD],
    [`Saved to history`, aD, aR],
    [shimmer('Generating', T, '#6E6E76', '#FFFFFF', .9, 4), aR, 0]
  ], 6, 'font-size:10.5px;font-weight:500;color:#8E8E93');
  // play button: progress ring while generating, pause while speaking, play when ready
  const bW = 1 - aS + aR;
  const bs = 1 - .12 * mtg_bump(l, 3.85, 4.3) - .12 * mtg_bump(l, 10.15, 10.6);
  const rg = l < 10 ? g : 0;
  const button = `<div style="position:relative;width:28px;height:28px;border-radius:50%;background:${mtg_hx('#1C1C20', '#FFFFFF', 1 - clamp(bW))};flex:none;transform:scale(${mtg_f(bs)})">
<div style="position:absolute;inset:0;opacity:${mtg_f(clamp(bW))}">${ring(rg, 28, 2.2, '#FFFFFF', '#2E2E33')}<i style="position:absolute;left:10px;top:10px;width:8px;height:8px;border-radius:2px;background:#FFFFFF"></i></div>
<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:${mtg_f(aS * (1 - aD))}">${ico('pause', '#050506', 12)}</div>
<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding-left:1.5px;opacity:${mtg_f(aD * (1 - aR))}">${ico('play', '#050506', 12)}</div></div>`;
  // karaoke text: a lilac scan while generating, spoken words turn white, the current word gets a soft highlight
  const sc = g * (mtg_N + 6) - 3, cpos = p * (mtg_N + 1) - .5;
  const chars = (from, to) => { let s = ''; for (let i = from; i < to; i++) { const ch = mtg_TX[i]; const scan = gOn * Math.exp(-Math.pow((sc - i) / 2.6, 2)); const spk = clamp(cpos - i + .5) * (1 - fR) * (pOn > 0 || l > 4 ? 1 : 0); s += `<span style="color:${mtg_hx(mtg_hx('#4E4E55', mtg_LIL, scan), '#F4F4F6', spk)}">${ch}</span>`; } return s; };
  const words = (lo, hi) => mtg_WD.filter(([a]) => a >= lo && a < hi).map(([a, b]) => {
    const hw = smooth(clamp((cpos - a + 1.2) / 1.6)) * (1 - smooth(clamp((cpos - b + .2) / 1.6))) * pOn;
    const hl = hw > .005 ? `background:${rgba(mtg_LIL, mtg_f(.2 * hw))};box-shadow:0 0 0 2px ${rgba(mtg_LIL, mtg_f(.2 * hw))};` : '';
    return `<span style="border-radius:3px;${hl}">${chars(a, b)}</span>`;
  }).join(' ');
  const text = `<div style="position:absolute;left:16px;right:16px;top:53px;font-size:11.5px;font-weight:500;line-height:16px"><div>${words(0, mtg_L1.length)}</div><div>${words(mtg_L1.length + 1, mtg_N)}</div></div>`;
  // waveform: bars rise left to right as audio renders, then fill white under the playhead
  const bp = 204 / mtg_NB, gh = g * (mtg_NB + 4) - 2, ph = p * mtg_NB;
  let bars = '';
  for (let i = 0; i < mtg_NB; i++) {
    const v = mtg_BV[i], hh = 4 + 20 * v;
    const gq = spring(clamp((gh - i) / 3)) * (1 - soft(seg(l, 11.1 + (mtg_NB - 1 - i) * .008, 11.5 + (mtg_NB - 1 - i) * .008)));
    const head = gOn * Math.exp(-Math.pow((gh - i - 1) / 2.2, 2));
    const pl = clamp(ph - i + .5) * pOn + clamp(ph - i + .5) * (1 - pOn) * (l > 10 ? 1 - fR : 0);
    const near = pOn * Math.exp(-Math.pow((ph - i - .5) / 1.4, 2));
    const c = mtg_hx(mtg_hx(mtg_hx('#26262A', '#3A3A40', clamp(gq)), mtg_pas(i / mtg_NB), head * .95), '#F4F4F6', pl);
    bars += `<i style="position:absolute;left:${mtg_f(i * bp + (bp - 3) / 2, 2)}px;top:${mtg_f(12 - hh / 2, 2)}px;width:3px;height:${mtg_f(hh, 2)}px;border-radius:1.5px;background:${c};transform:scaleY(${mtg_f(mix(3 / hh, 1, gq) * (1 + .22 * near * amp))})"></i>`;
  }
  const play = pOn <= .002 ? '' : `<div style="position:absolute;left:0;top:-3px;width:2px;height:30px;border-radius:1px;background:#FFFFFF;opacity:${mtg_f(pOn)};transform:translateX(${mtg_f(p * 204 - 1, 2)}px)"><i style="position:absolute;left:-2px;top:-2px;width:6px;height:6px;border-radius:50%;background:#FFFFFF"></i></div>`;
  const wave = `<div style="position:absolute;left:16px;right:16px;top:93px;height:24px">${bars}${play}</div>`;
  // meta: clip time and characters
  // the clip clock rewinds 0:06 -> 0:00 through 5,4,3.. (roll2 would take the short way up through 0:09)
  const tm = l < 11.25 ? mtg_clk(l, 4.45, 6 / 5.8, 6, mmss) : roll(mmss(6), mmss(0), l - 11.25, .55);
  const nc = mtg_steps(l, mtg_CK, String);
  return {
    h: 148, html: `<div class="in" style="padding:14px 16px">
<div class="row" style="gap:10px">${mtg_orb(30, T, amp)}<div style="line-height:1.25;flex:1"><div style="font-size:13px;font-weight:600">Aria</div><div style="position:relative;height:13px">${status}</div></div>${button}</div>
${text}${wave}
<div class="row m" style="position:absolute;left:16px;right:16px;top:124px;font-size:9.5px"><span style="color:#FFFFFF;font-weight:600">${tm}</span>&nbsp;/ 0:06<span class="sp"></span><span style="display:inline-flex;margin-right:4px;opacity:.9">${MK.eleven(10, T, '#8E8E93')}</span><span style="color:#FFFFFF;font-weight:600">${nc}</span>&nbsp;chars</div></div>`
  };
};

// ---------- pills
W.p_notion = T => {
  const pu = md(T * .85, 1);
  const dot = `<div style="position:relative;width:10px;height:10px;flex:none"><i style="position:absolute;inset:0;border-radius:50%;background:${mtg_RED};opacity:${mtg_f((1 - pu) * .45)};transform:scale(${mtg_f(1 + 1.3 * soft(pu))})"></i><i style="position:absolute;inset:0;border-radius:50%;background:${mtg_RED}"></i></div>`;
  return { h: 50, html: pill(dot, mtg_RED, tickUp(1452 + T, mmss)) };
};
W.p_slack = T => {
  const a = clamp(.5 + .45 * noise(T * 3.4 + 1.7));
  const ic = `<div style="position:relative;width:17px;height:17px;flex:none"><i style="position:absolute;inset:-5px;border-radius:50%;background:${rgba(mtg_GRN, .2)};opacity:${mtg_f(.3 + .7 * a)};transform:scale(${mtg_f(.75 + .25 * a)})"></i><span style="position:relative">${ico('headphones', mtg_GRN, 17, 2.2)}</span></div>`;
  return { h: 50, html: pill(ic, mtg_GRN, tickUp(760 + T, mmss)) };
};
W.p_eleven = T => {
  const bars = [0, 1, 2, 3, 4].map(i => {
    const v = clamp(.3 + .7 * Math.abs(Math.sin(T * (3.3 + i * .55) + i * 1.4) * Math.cos(T * (1.1 + i * .3) + i)));
    return `<i style="display:block;width:2.6px;height:${mtg_f(4 + v * 13, 2)}px;border-radius:2px;background:${mtg_pas(i / 4)}"></i>`;
  }).join('');
  return { h: 50, html: pill(`<div class="row" style="gap:2.4px;height:18px">${bars}</div>`, mtg_LIL, tickUp(42 + T, mmss)) };
};
