// kit.js: shared drawing helpers for every widget. Loaded after core.js, before widgets/*.js.
// Everything here is a pure function of its arguments. Colors passed to rgba/hexmix must be #RRGGBB.
const G=(d,c,s=16,sw=2)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
const P_={
pause:'<rect x="6.5" y="5" width="3.6" height="14" rx="1.2" fill="currentColor" stroke="none"/><rect x="13.9" y="5" width="3.6" height="14" rx="1.2" fill="currentColor" stroke="none"/>',
play:'<path d="M7 4.8v14.4a1 1 0 001.5.86l11.4-7.2a1 1 0 000-1.72L8.5 3.94A1 1 0 007 4.8z" fill="currentColor" stroke="none"/>',
prev:'<path d="M18 5v14L8 12z" fill="currentColor" stroke="none"/><rect x="5" y="5" width="2.4" height="14" rx="1" fill="currentColor" stroke="none"/>',
next:'<path d="M6 5v14l10-7z" fill="currentColor" stroke="none"/><rect x="16.6" y="5" width="2.4" height="14" rx="1" fill="currentColor" stroke="none"/>',
mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M6 11a6 6 0 0012 0M12 17v4"/>',
micOff:'<path d="M9 9V6a3 3 0 015.8-1M15 11v.5a3 3 0 01-4.6 2.5M6 11a6 6 0 009.3 5M18 11a6 6 0 01-.4 2.2M12 17v4M4 4l16 16"/>',
phone:'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a1 1 0 01-1 1A16 16 0 014 5a1 1 0 011-1z" fill="currentColor" stroke="none"/>',
x:'<path d="M6 6l12 12M18 6L6 18"/>',
check:'<path d="M5 12.5l4.5 4.5L19 7.5"/>',
search:'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
globe:'<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.6 2.6 2.6 14.4 0 17M12 3.5c-2.6 2.6-2.6 14.4 0 17"/>',
doc:'<path d="M7 3.5h7l4 4V20a.5.5 0 01-.5.5h-10A.5.5 0 017 20z"/><path d="M14 3.5V8h4M9.5 12.5h6M9.5 16h6"/>',
file:'<path d="M7 3.5h7l4 4V20a.5.5 0 01-.5.5h-10A.5.5 0 017 20z"/><path d="M14 3.5V8h4"/>',
code:'<path d="M9 7l-5 5 5 5M15 7l5 5-5 5"/>',
term:'<rect x="3" y="4.5" width="18" height="15" rx="3"/><path d="M7 9.5l3 2.5-3 2.5M12.5 15h4.5"/>',
branch:'<circle cx="6.5" cy="5.5" r="2"/><circle cx="6.5" cy="18.5" r="2"/><circle cx="17.5" cy="8.5" r="2"/><path d="M6.5 7.5v9M17.5 10.5c0 4-5 3-9.5 6.5"/>',
img:'<rect x="3.5" y="4.5" width="17" height="15" rx="3"/><circle cx="9" cy="10" r="1.8"/><path d="M4 17l5-4.5 4 3.5 3-2.5 4.5 4"/>',
note:'<path d="M9 18V6l10-2v12"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="16.5" cy="16" r="2.5"/>',
wave:'<path d="M3 12h2M7 8v8M11 5v14M15 9v6M19 11v2"/>',
spark:'<path d="M12 3c.6 4.6 3.4 7.4 8 8-4.6.6-7.4 3.4-8 8-.6-4.6-3.4-7.4-8-8 4.6-.6 7.4-3.4 8-8z" fill="currentColor" stroke="none"/>',
bolt:'<path d="M13 2L4 14h7l-1 8 9-12h-7z" fill="currentColor" stroke="none"/>',
clock:'<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
user:'<circle cx="12" cy="8.5" r="3.5"/><path d="M5 20c.8-3.6 3.6-5.5 7-5.5s6.2 1.9 7 5.5"/>',
users:'<circle cx="9" cy="9" r="3.2"/><path d="M3.5 19c.6-3.2 2.8-5 5.5-5s4.9 1.8 5.5 5"/><circle cx="16.5" cy="8" r="2.6"/><path d="M15.5 13.6c2.6-.2 4.6 1.4 5 4.4"/>',
hash:'<path d="M9 4L7 20M17 4l-2 16M4.5 9h15M3.5 15h15"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
arrowUp:'<path d="M12 19V5M6 11l6-6 6 6"/>',
cursor:'<path d="M5 3.5l13 6.2-5.6 1.7-1.8 5.6z" fill="currentColor" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/>',
heart:'<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0112 7.4 4.3 4.3 0 0119.5 10c0 5.4-7.5 10-7.5 10z" fill="currentColor" stroke="none"/>',
headphones:'<path d="M4 15v-3a8 8 0 0116 0v3"/><rect x="3.5" y="14" width="4" height="6" rx="1.5"/><rect x="16.5" y="14" width="4" height="6" rx="1.5"/>'
};
const ico=(n,c,s=16,sw=2)=>`<span style="color:${c};display:inline-flex">${G(P_[n],c,s,sw)}</span>`;
const rgba=(h,a)=>{const v=[1,3,5].map(i=>parseInt(h.substr(i,2),16));return `rgba(${v.join(',')},${a})`};
// rounded square icon tile: accent at 15% alpha behind an icon or any inner html
const chip=(n,c,s=30)=>`<div style="width:${s}px;height:${s}px;border-radius:${s*.32}px;background:${rgba(c,.15)};display:flex;align-items:center;justify-content:center;flex:none">${ico(n,c,s*.55)}</div>`;
const tile=(inner,bg,s=30,r)=>`<div style="width:${s}px;height:${s}px;border-radius:${r==null?s*.32:r}px;background:${bg};display:flex;align-items:center;justify-content:center;flex:none;overflow:hidden;position:relative">${inner}</div>`;
// morph: 0 compact ... 1 expanded, springy. P second cycle, opens at a, closes at b.
const morph=(T,P,a=1.2,b=4.4)=>{const {l}=st(T,P,0);return spring(clamp((l-a)/.9))-spring(clamp((l-b)/.9))};
// a fade/rise driver for content that only shows while expanded (e = morph value)
const reveal=e=>({o:clamp(e*1.7-.5),y:(1-e)*8});
const smooth=p=>{p=clamp(p);return p*p*(3-2*p)};
// cycle of steps. durs = seconds per step, o = offset. Returns i (step index), l (seconds into step), p (0..1 in step), P (cycle length), n (steps)
function phases(T,durs,o=0){const P=durs.reduce((a,b)=>a+b,0);let t=md(T-o,P);let i=0;for(;i<durs.length-1&&t>=durs[i];i++)t-=durs[i];return {i,l:t,p:clamp(t/durs[i]),P,n:durs.length}}
// crossfade from the previous state to state i (wraps around). k 0..1, e.g. spring(clamp(l/.7)). Old slides up and out, new rises in.
const xswap=(items,i,k,dy=9,style='')=>{const n=items.length,a=items[md(i-1,n)],b=items[md(i,n)];const lay=(s,o,y)=>o<=.001?'':`<div style="position:absolute;left:0;top:0;right:0;opacity:${o.toFixed(3)};transform:translateY(${y.toFixed(3)}px);white-space:nowrap;${style}">${s}</div>`;return lay(a,clamp(1-k*1.6),-dy*k)+lay(b,clamp(k*1.6-.6),dy*(1-k))};
// stacked text states crossfaded by a continuous position x (0..n-1). dy = slide distance. Never swaps at a threshold.
const xstack=(items,x,dy=9,style='')=>items.map((s,i)=>{const o=clamp(1-Math.abs(x-i)*2.2);if(o<=0.001)return '';return `<div style="position:absolute;left:0;top:0;right:0;opacity:${o.toFixed(3)};transform:translateY(${((x-i)*-dy).toFixed(3)}px);white-space:nowrap;${style}">${s}</div>`}).join('');
// "Thinking" shimmer: a soft highlight sweeps through the letters. base/hi are #RRGGBB.
const shimmer=(s,T,base='#6E6E76',hi='#FFFFFF',speed=.75,width=4.5)=>{const ch=[...s],n=ch.length;const cyc=n+width*2+4;const pos=md(T*speed*n*.9,cyc)-width;return ch.map((c,i)=>{const k=Math.max(0,1-Math.abs(i-pos)/width);return `<span style="color:${hexmix(base,hi,smooth(k))}">${c===' '?'&nbsp;':c}</span>`}).join('')};
// three typing dots
const dots=(T,c='#8E8E93',s=4,gap=3)=>`<span style="display:inline-flex;align-items:center;gap:${gap}px">${[0,1,2].map(i=>{const p=Math.max(0,Math.sin(T*Math.PI*2*1.1-i*.75));return `<i style="display:block;width:${s}px;height:${s}px;border-radius:50%;background:${c};opacity:${(.35+.65*p).toFixed(3)};transform:translateY(${(-p*2).toFixed(3)}px)"></i>`}).join('')}</span>`;
// gliding progress bar: a full width fill translated inside an overflow hidden track (never animate width)
const bar=(f,w,c,h=4,track='#1F1F23')=>`<div style="position:relative;width:${w}px;height:${h}px;border-radius:${h/2}px;background:${track};overflow:hidden;flex:none"><div style="position:absolute;inset:0;border-radius:${h/2}px;background:${c};transform:translateX(${((clamp(f)-1)*w).toFixed(3)}px)"></div></div>`;
// progress ring, f 0..1
const ring=(f,s,sw,c,track)=>{const r=(s-sw)/2,C=2*Math.PI*r;return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" style="transform:rotate(-90deg);flex:none"><circle cx="${s/2}" cy="${s/2}" r="${r}" stroke="${track||rgba(c,.2)}" stroke-width="${sw}" fill="none"/><circle cx="${s/2}" cy="${s/2}" r="${r}" stroke="${c}" stroke-width="${sw}" fill="none" stroke-linecap="round" stroke-dasharray="${(C*clamp(f)).toFixed(3)} ${C.toFixed(3)}" opacity="${clamp(f*40)}"/></svg>`};
// gradient avatar disc with a letter
const av=(letter,c1,c2,s=24,fg='#0B0B10')=>`<div style="width:${s}px;height:${s}px;border-radius:50%;background:linear-gradient(135deg,${c1},${c2});display:flex;align-items:center;justify-content:center;font-size:${(s*.42).toFixed(1)}px;font-weight:700;color:${fg};flex:none">${letter}</div>`;
// soft blinking caret (no hard on/off)
const caret=(T,c='#FFFFFF',h=12)=>`<i style="display:inline-block;width:1.6px;height:${h}px;border-radius:1px;background:${c};vertical-align:-2px;margin-left:1px;opacity:${(.15+.85*smooth(.5+.5*Math.cos(T*Math.PI*2*.9)*1.6)).toFixed(3)}"></i>`;
// animated check (p 0..1 draws the tick)
const tick=(p,c='#FFFFFF',s=10,sw=3.2)=>chkPath(p,c,s,sw);
// small status pill / tag
const tag=(txt,c,bgA=.14)=>`<span style="font-size:9.5px;font-weight:600;color:${c};background:${rgba(c,bgA)};border-radius:6px;padding:2px 7px;white-space:nowrap">${txt}</span>`;
// the narrow pill layout from the original: icon left, value right in accent
const pill=(icon,c,val,extra='')=>`<div class="in row" style="padding:0 15px;gap:8px">${icon}<span class="sp"></span>${extra}<span style="font-size:15px;font-weight:600;color:${c}">${val}</span></div>`;
// brand marks registry: widget files add MK.<brand>=(s,T)=>svg/html. Original simple glyphs only, never traced logos.
const MK={};
const W={};
