---
name: ai-app-widgets
description: >-
  Use when asked to make a silent, premium motion video of live widgets for popular AI and productivity apps
  (Claude, Claude Code, ChatGPT voice and deep research, Gemini, Perplexity, NotebookLM, Grok, Midjourney, Suno,
  Cursor, Linear, Figma, Notion, Slack, ElevenLabs): columns of black, rounded, phone style Live Activity cards
  on a dark graphite stage. Every card shows the app's signature moment on its own clock (thinking shimmer,
  streaming text, tool calls ticking off, a voice orb, images resolving, diffs rolling) with springy expands and
  rolling odometer digits, while the columns drift in alternating directions and the camera slowly pulls back.
  Blur in intro, no cuts. 1600x1200 (4:3), 16.5 s, 60 fps, rendered frame by frame. Plain HTML, CSS and JS with
  Playwright and ffmpeg. No framework. Also: the same widgets as Live Activities on iPhone lock screens, rendered in
  Blender (Cycles) as a flat lay of real phone models with a pull back camera.
---
# AI app widgets motion video

**What you get:** a 16.5 second, 1600x1200 video of about 28 live widgets for the AI and productivity apps people use
every day, all moving at once, rendered deterministically so every frame is identical on every run. A 1600x1200 H.264
file that plays well on X, LinkedIn and Instagram, and a light 1200x900 copy for a web page.

**Pick this when** you want the "this looks like a real product team made it" post about the tools of the moment:
lots of tiny, polished UI states, everything alive, buttery motion, no voiceover.

## Files
```
template/index.html        the scene: stage, column layout, camera, intro, draw(t). Widget lists WIDE and NARR.
template/core.js           easing and timing: spring, soft, expo, io, ease3, st/st2/tw, roll2 odometer, rollL, tickUp/tickDn, cnt, typeIn
template/kit.js            shared drawing: icons, chip/tile, morph, phases, xswap/xstack crossfades, shimmer, dots, bar, ring, av, caret, pill
template/widgets/*.js      the widgets, one file per app family: W.<id>(T, w) -> {h, html}, brand glyphs in MK
template/gallery.html      review sheet: every widget at chosen clock times, with an overflow detector
template/scripts/check.js  steps every widget through T = 0..29 at 120 steps a second: errors, NaN, height range, height snaps
template/scripts/gallery.js  gallery.html -> PNG, prints any card whose content spills over its edge
template/scripts/strip.js  a filmstrip of one widget across a transition, to catch pops
template/scripts/snap.js   stills of the full scene at chosen seconds
template/scripts/render.js parallel Playwright workers: frame i -> draw(i/fps) -> screenshot at 2x (2400x1800 PNG)
template/scripts/tiles.py  smoothness check: frame to frame difference on a 16x12 tile grid, flags spikes
template/scripts/encode.sh frames -> out/video.mp4 (1600x1200) + out/video_web.mp4 (1200x900)
template/phone/lockscreen.html  an iOS style lock screen (402x874 pt): clock, Dynamic Island compact activity, Live Activity stack at 1.5x
template/phone/phones.js        one entry per phone screen: island pill, widget stack, wallpaper tint, clock, time offset
template/phone/sheet.js         contact sheet of every lock screen at one moment
template/phone/render_screens.js  lock screen image sequences for Blender (30 fps, hero at 3x, the rest at 1.5x)
template/film/film.py           the Blender scene: phone field, drift, lights, camera pull back, depth of field, Cycles settings
template/film/decode-glb.mjs    strips meshopt compression from a phone GLB so Blender can import it
preview.jpg                a still from the reference render
```

## Quick start
```bash
cp -r template my-video && cd my-video           # never build inside the skill folder
npm i -D playwright && npx playwright install chromium   # or any Node setup where require('playwright') works
node scripts/check.js                              # every widget must print a check mark
node scripts/snap.js 0.5 4 9 16                    # look at the intro, the middle and the pull back
node scripts/render.js --fps 60 --seconds 16.5     # 990 frames, a few minutes on 4 cores
python3 scripts/tiles.py frames                    # optional (needs numpy and pillow): expect only small spikes from intentional fast moves
bash scripts/encode.sh frames out                  # out/video.mp4 + out/video_web.mp4
```
The scene uses Inter and JetBrains Mono. Install both locally before rendering so every frame uses the same fonts.

## The phone film (Blender)
The same widgets as Live Activities on real phones: a flat lay of iPhones on a graphite stage in columns that drift like the
flat video, each phone running its own lock screen, the camera starting tight on the hero phone's Live Activities and pulling
back and up while the depth of field opens. 1600x1200, 16.5 s, 30 fps, Cycles.

You bring the phone model: any GLB of a phone whose display is a separate mesh named `Front_Screen` with a 0 to 1 UV
(as most product models have). Check its licence. If it uses meshopt compression, decode it first. You also need a studio
HDRI (Poly Haven's studio_small_09 is CC0).
```bash
pip install bpy==5.0.1                              # Blender as a Python module (Python 3.11)
node film/decode-glb.mjs phone.glb phone-decoded.glb   # needs @gltf-transform/core, /extensions, meshoptimizer
node phone/sheet.js 6                                # every lock screen at t = 6 s
node phone/render_screens.js --workers 2             # film/screens/p0 ... p17
python film/film.py -- --glb phone-decoded.glb --hdri studio.hdr --screens film/screens --out film/frames --frames 1-495 --samples 12
ffmpeg -framerate 30 -i film/frames/%05d.png -c:v libx264 -crf 14 -preset slow -pix_fmt yuv420p -movflags +faststart phones.mp4
```
- The island cutout of the model sits at x 0.391 to 0.606 and y 0.0145 to 0.053 of the screen; `lockscreen.html` draws the
  compact activity around it (`ISL`). Measure your model's island and change `ISL` if it differs.
- Screens are emissive under a glossy cover glass (Principled: black base, roughness 0.035, emission = the screen image),
  view transform Standard so the widget colors stay exact.
- 12 samples with adaptive sampling and OpenImageDenoise is clean; about 25 s a frame at 1600x1200 on 4 CPU cores.
  `--frames` and resumable output let you split the range across processes or machines.
- Phones the camera never sees are culled before rendering.

## How the scene works
- **Stage:** 1200x900 CSS px, captured at device scale 2 and downscaled to 1600x1200 with Lanczos. Background #1D1D20 with a soft vignette.
- **Cards:** pure black (#050506), radius 30 (or h/2 for pills), a hairline inner highlight and a soft drop shadow. One accent color per app, used for the hero number, the icon tile (accent at 15% alpha) and fills.
- **Columns:** `CW` lists column widths (236 wide cards, 150 narrow pills), 18 px gaps, 16 px between cards. Each column is a shuffled, repeated list of widget ids so neighbours never match. Odd columns drift down, even columns drift up, 12 px per second.
- **Camera:** `ZOOM(t)` eases from 1.14 to 0.80 over the whole clip with a cubic in out, so the end reveals more columns.
- **Intro:** each card fades, un-blurs (9 px to 0) and springs from 0.9 to 1.0 scale, delayed by its distance from the center.
- **Per card clock:** `T = t + phase`, phase in 0 to 12 s, so repeated widgets never move in sync.
- **Morphing cards:** `morph(T,P,a,b)` returns 0 to 1 with a spring up at `a` and a spring down at `b` in a P second cycle. The card height mixes between compact and expanded and the column restacks, so cards below get pushed smoothly.
- **State machines:** `phases(T,[durations])` gives the current step of a cycle; `xswap` crossfades the previous state into the next one, so text never swaps at a threshold.

## Making your own version
1. Swap the copy inside each `W.<id>` (chats, prompts, file names, people). Keep people and data made up.
2. Add a widget: write `W.myThing=(T,w)=>({h:104,html:`...`})` in a widgets file, add the file to `index.html` and `gallery.html` if it is new, then add its id to `WIDE` or `NARR`. Everything must be a pure function of T. No Math.random, no Date, no CSS transitions or animations.
3. Numbers: use `roll2(from,to,secondsSinceChange)` or the wrappers `rollL` (list of values on a cycle), `tickUp` / `tickDn` (clocks), `cnt` (slow counters). Digits roll the short way, so 9 to 0 is one step.
4. Brand glyphs live in `MK`. They are simple original shapes that hint at each app by color and form, not the official logos. Keep it that way, or use marks you have the rights to.
5. Run `check.js`, look at `gallery.js` sheets and `strip.js` filmstrips, render, run `tiles.py`, fix anything that spikes, then encode.

## Gotchas
- **Pixel snapping is the big one.** Chrome snaps plain `left`/`top` and 2D translations to whole pixels, so slow drifts and scrolling bars step every few frames instead of gliding. Every card is placed with `translate3d(...) rotate(0.0002deg) scale(...)` and `will-change:transform`, and anything that moves inside a card (bars, waveforms, cursors, tickers, progress fills) moves with `transform`, never `left` or `width`. Progress fills are a full width bar inside an `overflow:hidden` track, translated left (`bar()`).
- Keep `T` bounded: every cycle runs on `phases` / `md`, so counters never drift into nonsense over the 29 seconds a card can live.
- Crossfade text states with continuous opacity from the same driver as the motion, never swap strings at a threshold.
- Use the from rest `spring` for anything that travels and `soft` for fades and resets.
- `white-space:nowrap` on everything; the inner width of a wide card is 204 px. `gallery.js` reports anything that spills.
- Mid roll digits are normal in any single frame; pick a thumbnail where the main numbers are settled.

## Known limits
- Silent by design. Rendering is CPU bound, roughly 0.2 s per frame per worker at 2400x1800.
- The frame folder is about 1 to 2 GB for 16.5 s at 60 fps. Delete it after encoding.
- A design concept: the apps' names appear, but nothing here is affiliated with or endorsed by them.
